# API REST v1

Route Handlers Node.js. Respuestas `{data: ...}`; errores `{error:{code,message,request_id}}`, cabecera X-Request-Id. Cache-Control private,no-store. Sesión Supabase por cookies y comprobación de permisos activos por recurso/ubicación. Mutaciones requieren Origin exacto igual a APP_URL. UUID estables, fechas ISO, decimales como strings.

| Método/ruta                          | Datos                                                        | Permiso/resultado                                                                                                 |
| ------------------------------------ | ------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| GET /api/v1/acceso                   | —                                                            | Perfil activo, permisos efectivos y almacenes asignados.                                                          |
| GET /api/v1/catalogos/{resource}     | search, page                                                 | Catálogo autorizado paginado (25); almacenes por RLS.                                                             |
| POST /api/v1/catalogos/{resource}    | code, name, active + campos de recurso                       | Permiso manage del dominio; crea y audita.                                                                        |
| PATCH /api/v1/catalogos/{resource}   | id, lock_version, data completo                              | Edición optimista; 409 si versión cambió.                                                                         |
| GET /api/v1/unidades                 | —                                                            | Unidades y factores exactos.                                                                                      |
| GET /api/v1/usuarios                 | —                                                            | usuarios.manage; perfiles sin contraseña.                                                                         |
| POST /api/v1/usuarios                | email, full_name                                             | Invitación Auth; requiere service_role solo servidor. Cuenta inactiva hasta asignación.                           |
| PATCH /api/v1/usuarios               | id, lock_version, active, roles[], warehouses[], overrides[] | Concede/revoca accesos; sin edición propia.                                                                       |
| GET /api/v1/roles                    | —                                                            | Lista de roles/versiones.                                                                                         |
| POST /api/v1/roles                   | code, name                                                   | Crea rol sin permisos.                                                                                            |
| PATCH /api/v1/roles                  | id, lock_version, permissions[]                              | Cambia permisos; no rol propio.                                                                                   |
| GET /api/v1/precios                  | —                                                            | costos.read; últimos 500 registros.                                                                               |
| POST /api/v1/precios                 | presentation_id, amount, effective_date, source              | insumos.manage + costos.read; conserva historial.                                                                 |
| POST /api/v1/minimos                 | item_id, warehouse_id, minimum_stock                         | insumos.manage en almacén asignado.                                                                               |
| POST /api/v1/aperturas               | warehouse_id, lines[{item_id,quantity,value}]                | inventario.opening + costos.read; exige cabecera UUID Idempotency-Key. Una apertura por almacén.                  |
| GET /api/v1/existencias              | warehouse_id                                                 | inventario.read en almacén; importes solo con costos.read. Lectura básica del motor F1; Kardex/UI completa en F3. |
| GET /api/v1/importaciones/plantilla  | resource                                                     | Descarga XLSX por catálogo permitido.                                                                             |
| POST /api/v1/importaciones/preview   | multipart resource/file                                      | 5 MB, 1.000 filas, 20 columnas y 20 MB expandido; devuelve filas/errores/job_id.                                  |
| POST /api/v1/importaciones/confirmar | job_id                                                       | Revalida permisos; transacción/idempotencia por job.                                                              |

Recursos de catálogo: insumos, proveedores, categorias, sucursales, almacenes, presentaciones. Campos específicos se definen en `modules/catalogos/config.ts` y se validan también por constraints/funciones SQL. Catálogos globales no contienen stock; existencias siempre requieren almacén.

Auth (fuera del API de negocio): POST /api/auth/login, logout, recover, password; GET /auth/confirm con token_hash/type recovery o invite; GET /auth/callback con code PKCE. Redirecciones fijas, sin next externo. Password requiere sesión Auth válida y mínimo 12 caracteres. Recuperación no revela si el correo existe en el mensaje de éxito.

Códigos: 401 sesión ausente, 403 sin permiso/origen inválido, 404 recurso no disponible, 409 duplicado/conflicto, 413 límite, 415 contenido, 422 validación/regla, 429 límite Auth por instancia, 503 servicio/configuración no disponible.

No existe endpoint genérico para alterar saldos ni API POS aún. Idempotency-Key se conserva para reintentos de la misma apertura; cambiando datos debe generarse una nueva clave. El hash y la operación se registran atómicamente.
