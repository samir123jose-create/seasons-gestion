# Arquitectura

Monolito modular Next.js App Router. UI de servidor y componentes cliente separados de reglas, repositorios, validaciones y autorización. Las API REST `/api/v1` usan Route Handlers y Zod. Las mutaciones llaman funciones PostgreSQL únicas, con control de permisos dentro de la transacción. No hay cálculos autoritativos de inventario en React.

## Dominios

- `modules/usuarios`: identidad, permisos efectivos, control de ámbito, cuenta activa.
- `modules/insumos/domain`: conversiones decimales exactas con BigInt.
- `modules/catalogos`: contrato reutilizable de formularios, validadores y repositorios para insumos/proveedores/ubicaciones. No comparte cálculos de costos entre pantallas; nombres de tabla/mutación están en una lista fija.
- `modules/importaciones`: lectura de Excel, límites comprimidos/expandidos, validación y previsualización. Confirmación atómica en SQL.
- `lib/supabase`: adaptadores server-only. Cliente de usuario para operaciones; cliente administrativo solo para invitaciones y script de provisión.
- `supabase/migrations`: modelo y motor de inventario para próximos módulos.

Las carpetas de dominios futuros se implementarán con sus fases; no se presentan páginas ficticias de recetas, producción o reportes. `/admin` es una experiencia de gestión limitada por permisos, no una autorización por el nombre del rol. Inicio operativo comparte la base en esta entrega; recetas/solicitudes móviles llegan en F2/F3.

## Seguridad

`proxy.ts` renueva sesión; los casos de uso verifican usuario contra Auth y permisos activos en PostgreSQL. No se confía en un JWT con permisos históricos. RLS protege lecturas; se revocan escrituras directas a tablas de aplicación. RPC con SECURITY DEFINER fija search_path vacío, usa nombres cualificados, valida identidad activa, permisos, referencias y estado, y no permite ejecución anon/PUBLIC.

Costos y auditoría completa viven en `app_private`. Las funciones de lectura filtran columnas sensibles; RLS de filas sola no basta para ocultar costos. Los DTO usan strings para decimales, y SQL calcula los importes críticos. Las ubicaciones siempre se intersectan con asignaciones.

Los formularios que escriben usan comprobación de Origin exacto contra APP_URL. Los enlaces Auth usan destino fijo; no hay redirect arbitrario. Cookies SameSite=Lax, Secure en producción; no se hace caché pública de sesiones/datos. Se usa la gestión de cookies recomendada de @supabase/ssr; no prometer HttpOnly con un cliente SSR que requiere lectura de sesión en navegador.

El límite de Auth en memoria es una barrera por acción/IP e instancia, no una garantía distribuida. Se confía en x-forwarded-for únicamente en Vercel o cuando el operador configura un proxy que lo sobrescribe; cerrar sesión no se bloquea por ese límite. Configurar límites de Supabase Auth, políticas del host y monitoreo antes de uso real. Tipos/tamaños de archivos se limitan; el ZIP se valida y se verifica decompression real con límite antes de ExcelJS.

## Decisiones técnicas

- Node 24 y TypeScript 5.9.3: el conjunto de typescript-eslint consultado soporta `<6.1`; no se toma TypeScript 7 solo por ser la etiqueta latest.
- ESLint 10 con plugins oficiales Next, TypeScript y hooks, en vez de eslint-config-next, cuyos plugins de import/React/a11y consultados solo declaraban ESLint <=9. No se fuerza una resolución incompatible.
- Build con Webpack, soportado por Next. Turbopack no pudo abrir un puerto temporal en el entorno. `experimental.useTypeScriptCli=false` usa el compilador API disponible de TS5.9; las comprobaciones de tipos permanecen activas y se ejecuta tsc por separado. La ruta CLI de Next16.4 falló al interpretar --showConfig en este entorno.
- ExcelJS es requisito del pedido. Override localizado de uuid a 11.1.1 corrige GHSA-w5hq-g745-h8pq; se prueba escritura/lectura de plantillas e importaciones con ese override.
- `pg` se usa exclusivamente como adaptador de integración aislada, no como acceso directo a PostgreSQL desde el frontend/serverless.
- No se añaden ORM, Redis, microservicios ni proveedores alternativos.

## Portabilidad

SQL, código y archivos exportables; no se integra código con Vercel. Auth/Storage se acceden por adaptadores; migrar esos proveedores exige migrar usuarios/objetos/configuración, no solo SQL. GitHub remoto del proyecto está configurado; no se efectuó push ni despliegue.
