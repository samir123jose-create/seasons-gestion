# Reglas operativas

## Confirmadas por el usuario

- Promedio ponderado móvil por insumo/almacén.
- Stock negativo bloqueado. Dos consumos simultáneos no pueden usar la misma disponibilidad.
- Moneda BOB; cantidades 6 decimales, costos unitarios 10, importes internos 6; dinero visible 2.
- Redondeo al más cercano, empate alejándose de cero (PostgreSQL NUMERIC).

Promedio de entrada = (valor previo + valor de entrada) / (cantidad previa + entrada), redondeado a 10 decimales. Salidas valorizadas al promedio del instante de confirmación; el costo histórico permanece. La salida que deja cantidad cero toma todo el valor remanente para evitar residuos. Otros residuos materiales por importes submicromonetarios requieren regla validada; la operación no puede dejar valor negativo.

## Invariantes entregadas

Las tres ubicaciones iniciales no contienen existencias/precios de ejemplo. El administrador abre una vez cada almacén con insumos/cantidades/valores históricos revisados. No se carga stock directamente en tabla de saldos.

Cambiar precio de referencia no registra compra ni revaloriza movimientos. Presentaciones conservan dimensión, contenido y proveedor para trazabilidad: cambio de contenido requiere nueva presentación. Unidad base del insumo es inmutable.

Permisos por acción, rol y persona; denegación explícita prevalece. Cuenta inactiva no opera aunque su JWT anterior siga vigente. Para evitar bloqueo de acceso, no se permite modificar permisos propios ni un rol propio desde la UI/RPC. Las asignaciones operativas del resto del equipo se realizan explícitamente.

Importaciones son creación, no actualización masiva: duplicados se muestran y deben resolverse en el archivo/catálogo antes de confirmar. No se mezcla automáticamente información existente. La plantilla de insumos usa códigos de categorías y unidades (g, ml, unidad); el servidor los resuelve a UUID y valida referencias vigentes.

## Pendientes

Rendimientos y porciones reales; tratamiento de impuestos, fletes, descuentos/costos indirectos; lotes obligatorios; aprobación de solicitudes/conteos; frecuencia/canales de aviso; compatibilidad de lotes con nuevas recetas; RPO/RTO/retención; responsables y permisos por persona. No se implementan valores fiscales o políticas de fases futuras por inferencia.

## Alcance de consumos

Esta entrega prepara el motor, no un formulario de producción. Recetas teóricas no mueven inventario; la fabricación futura consumirá materias primas y dará entrada a salida real atómicamente. Utilizar una preparación almacenada descontará esa preparación, sin volver a descontar sus ingredientes. Transferencias no serán consumo/gasto. Sin POS no se atribuyen ventas ni se presenta consumo real diario completo.
