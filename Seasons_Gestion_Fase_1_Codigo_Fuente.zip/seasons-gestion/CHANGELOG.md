# Historial

## 0.1.0 — Fase 1, implementación local

- Aprobación de Fase0 v1.1 y confirmación de valoración, stock y precisión registradas.
- Next.js App Router, React, TypeScript estricto, Tailwind, Lucide y estructura modular.
- Auth SSR, recuperación, cambio de contraseña, cierre de sesión y accesos vigentes en servidor/SQL.
- Usuarios, roles configurables, permisos individuales y ubicaciones asignadas; revocación/desactivación efectiva.
- Catálogos persistentes, unidades/conversiones, presentaciones inmutables e historial de precios.
- Importación Excel con plantillas, códigos de unidad/categoría, previsualización, límites y transacción.
- Motor privado de inventario, apertura auditada, promedio ponderado móvil, idempotencia y concurrencia.
- Migraciones SQL, RLS/grants, bucket privado y documentación de instalación/recuperación.
- PWA base, interfaz responsive, estados de formulario y navegación por teclado.
- Vitest, React Testing Library, PostgreSQL aislado, Playwright y harness Auth/PostgREST reales locales.
- CI GitHub Actions preparado. No publicación ni push realizados.

La evidencia y lo pendiente se registran en docs/FASE_1_RESULTADOS.md; esta versión no declara fases futuras terminadas.
