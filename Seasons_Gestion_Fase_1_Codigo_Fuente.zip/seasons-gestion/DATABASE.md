# Modelo de datos de Fase 1

Las tres migraciones versionadas implementan identidad, ubicaciones, catálogos, importaciones y núcleo de inventario. Se aplican sobre un proyecto Supabase de desarrollo con auth.users, roles anon/authenticated/service_role y storage.buckets existentes.

## Tablas

Identidad: profiles (Auth 1:1), roles, permissions, user_roles, role_permissions, user_permission_overrides, user_warehouse_access. Profiles nuevos son inactivos; nunca almacenan contraseñas.

Ubicaciones: branches, warehouses. Warehouse tiene branch opcional para depósito independiente. Las asignaciones se hacen por almacén; no se obtiene acceso cruzado por pertenecer a una sucursal.

Catálogos: units, item_categories, suppliers, items, purchase_presentations, item_location_policies. Units describe dimensión/factor; items solo admite unidades base de factor 1. Una presentación convierte contenido a la dimensión base de su artículo. Código único normalizado y estado activo en lugar de borrado.

Privadas: item_price_history (precio, fuente, fecha, cantidad base y costo unitario snapshot), audit_logs, inventory_operations, inventory_movements, stock_balances, inventory_opening_documents. Apertura única por almacén y valor conocido. No se siembran precios o existencias.

Importación: import_jobs guarda autor, catálogo, filas revisadas, estado preview/confirmed y fechas. Confirmación de todas las filas en una transacción; fallo o duplicado concurrente no deja filas parciales. El ID del job es la clave de reintento.

## Tipos, exactitud y controles

UUID PK/FK; TIMESTAMPTZ; cantidades NUMERIC(20,6), valores NUMERIC(24,6), costos NUMERIC(24,10), factores NUMERIC(24,12). Rechazo de NaN y entradas con precisión mayor que la aceptada. Unidades de conteo enteras. Cotizaciones de cero son explícitas, no sustituyen precio desconocido.

DTO de unidades/presentaciones y RPC de stock/precios devuelven strings decimales. Los saldos son proyecciones reconstruibles del Kardex; nunca se editan en CRUD. Movimientos confirmados y precios históricos son append-only para clientes.

lock_version en catálogos/perfiles/roles evita pérdida silenciosa de edición. Confirmaciones usan locks en orden de almacén/artículo y exclusión por actor/idempotencia; mismo payload devuelve misma operación y payload distinto se rechaza. Hash SHA-256 y registros quedan en la misma transacción.

`app_private.apply_inventory` es el puerto interno y NO tiene execute para anon/authenticated. API/RPC pública de F1 solo habilita apertura. Funciones de recepción/producción/transferencia con documentos fuente llegarán en sus fases; no existe API genérica para descontar stock arbitrariamente.

## RLS/grants y Storage

Lecturas públicas por permisos y ámbito; sin grants de insert/update/delete directos para tablas de la aplicación. Functions SECURITY DEFINER comprueban permisos explícitos con denegación individual prevalente. El acceso al esquema privado no concede acceso a sus tablas.

Bucket `seasons-assets` privado, 5 MB, imágenes JPEG/PNG/WebP y PDF. En F1 no hay uploader ni políticas de objetos de documentos aún: fotos/comprobantes se habilitan con su vínculo y política en F2/F3. Confirmar reglas en Storage real antes de aceptar AC1-13/16 completo. La metadata de bucket del harness E2E no sustituye servicio Storage.

## Diagrama principal

```mermaid
erDiagram
 AUTH_USERS ||--|| PROFILES : identifica
 PROFILES ||--o{ USER_ROLES : recibe
 ROLES ||--o{ USER_ROLES : asigna
 ROLES ||--o{ ROLE_PERMISSIONS : define
 PERMISSIONS ||--o{ ROLE_PERMISSIONS : concede
 PROFILES ||--o{ USER_PERMISSION_OVERRIDES : personaliza
 PROFILES ||--o{ USER_WAREHOUSE_ACCESS : delimita
 WAREHOUSES ||--o{ USER_WAREHOUSE_ACCESS : habilita
 BRANCHES o|--o{ WAREHOUSES : contiene
 ITEM_CATEGORIES ||--o{ ITEMS : clasifica
 UNITS ||--o{ ITEMS : mide
 ITEMS ||--o{ PURCHASE_PRESENTATIONS : presenta
 ITEMS ||--o{ STOCK_BALANCES : resume
 WAREHOUSES ||--o{ STOCK_BALANCES : localiza
 INVENTORY_OPERATIONS ||--|{ INVENTORY_MOVEMENTS : confirma
 ITEMS ||--o{ INVENTORY_MOVEMENTS : afecta
 WAREHOUSES ||--o{ INVENTORY_MOVEMENTS : registra
```

El modelo de recetas/versiones, compras, lotes, transferencias, conteos y calidad está en la planificación aprobada; sus migraciones se producirán con la fase correspondiente.
