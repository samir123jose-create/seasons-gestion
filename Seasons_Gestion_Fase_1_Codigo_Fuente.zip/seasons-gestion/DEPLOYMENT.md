# Ejecución, despliegue y recuperación

## Estado

Código preparado para Vercel + Supabase, sin publicación ni cambios de producción autorizados. No se conectó un proyecto remoto de Seasons. Hay pruebas locales reales en PostgreSQL y en GoTrue/PostgREST; no equivalen a certificar el plan contratado, SMTP, Storage o respaldos de un proyecto hosted.

## Ambientes y variables

Separar desarrollo/pruebas/producción en proyectos y bases. Aplicar migraciones solo al ambiente seleccionado; verificar host/ID antes de cada operación. Node 24 en CI y host. Configurar NEXT_PUBLIC_SUPABASE_URL y NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY por ambiente; SUPABASE_SERVICE_ROLE_KEY solo servidor, para invitaciones/bootstrap, sin copiarla a logs o bundles.

APP_URL es el origen exacto HTTPS del sitio (http://localhost:3000 durante desarrollo). Configurar Auth Site URL/redirect allowlist. Personalizar las plantillas Auth: el enlace de recuperación/invitación debe dirigirse a `/auth/confirm?token_hash={{ .TokenHash }}&type=recovery` o `type=invite`, con origen de la aplicación; alternativamente usar el flujo PKCE de `/auth/callback`. No usar URL proporcionada por cliente como redirect.

Habilitar proveedor de correo/SMTP, contraseña mínima 12 y límites/controles contra abuso en Supabase Auth. El límite en memoria de Next es por acción/IP e instancia y no sustituye protección distribuida. Vercel se detecta automáticamente; en otro proxy, habilitar TRUST_PROXY_HEADERS únicamente si sobrescribe x-forwarded-for. Cerrar sesión no está sujeto a este límite. Configurar políticas del host antes del acceso del equipo. Valorar MFA administrativo con el responsable del proyecto en una revisión posterior.

Bucket seasons-assets permanece privado. No habilitar lectura pública para hacer funcionar imágenes; los vínculos/ACL de cada documento llegan en F2/F3. Verificar límites de archivos y políticas del proyecto real antes de usarlo.

## Publicación posterior

Tras autorizarla, importar el repositorio en Vercel, seleccionar Node24, configurar variables, verificar build y ejecutar migraciones en Supabase del ambiente correspondiente. Configurar dominio/DNS/TLS. Crear primer administrador con script documentado; validar todas las pruebas de permisos contra ese proyecto antes de invitar al equipo. Una publicación requerirá autorización explícita distinta de la aprobación de la planificación.

## Respaldos

Inventario de recuperación: SQL (incluido app_private), usuarios/identidades Auth, objetos de Storage, configuración de Auth/SMTP/DNS, variables y políticas. Un dump SQL no respalda objetos binarios de Storage. No publicar backups ni ponerlos en Git.

Antes de uso real, acordar RPO/RTO, retención, responsables, cifrado y destinos de respaldo; verificar capacidades del plan contratado y límites de exportación de Auth. Documentar claves/rutas por mecanismo seguro, sin valores en documentación.

Ensayo aislado:

1. Generar dump y manifiesto de objetos desde el ambiente de prueba elegido.
2. Crear destino separado, con versión PostgreSQL compatible y roles/grants.
3. Restaurar datos/migraciones y objetos preservando rutas/metadata.
4. Verificar recuentos, FK, imágenes/comprobantes, permisos RLS/RPC, acceso Auth y conciliación de saldo con movimientos.
5. Registrar duración, punto de recuperación y evidencia; compararlos con objetivos aprobados.

Esta entrega incluye ensayo de restauración SQL aislada; la restauración de Storage y configuración del proveedor real sigue pendiente. No declarar AC1-16 completo solo por recuperar una tabla o un dump.

## Pruebas locales

Compose de tests usa solo puertos 127.0.0.1 y datos de prueba. Las claves/contraseñas fijas allí no se usan en ningún ambiente real. `scripts/prepare-e2e.mjs` genera claves locales ignoradas; el gateway reenvía a Auth/API reales. Detener el gateway y `docker compose -f tests/docker/compose.yml down -v` elimina únicamente ese harness. No usar la suite SQL contra un proyecto de producción: valida host localhost y base seasons_test.
