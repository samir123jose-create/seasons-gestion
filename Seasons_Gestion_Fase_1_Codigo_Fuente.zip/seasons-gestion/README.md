# Seasons Gestión

Aplicación empresarial Next.js para Seasons. Esta entrega implementa los fundamentos de Fase 1 aprobados, con catálogos, autenticación, permisos y motor transaccional de inventario. Recetas, producción completa, compras, solicitudes y dashboard analítico corresponden a fases posteriores.

## Requisitos

Node.js 24.15+ (rama 24), npm 11+, proyecto Supabase aislado para desarrollo. PostgreSQL 15+ (pruebas ejecutadas con PostgreSQL 17). Código TypeScript estricto; dependencias fijadas con package-lock.json.

## Instalación y configuración

```sh
npm ci
cp .env.example .env.local
```

Configurar en `.env.local` la URL y clave publishable del proyecto Supabase de DESARROLLO. `SUPABASE_SERVICE_ROLE_KEY` es solo servidor y se requiere para invitaciones/bootstrap; jamás anteponer NEXT_PUBLIC_. No compartir `.env.local`, claves ni volcados de datos.

1. Aplicar en orden los archivos de `supabase/migrations/` con Supabase CLI (`supabase db push` contra el proyecto de desarrollo) o SQL Editor, verificando la instancia elegida. No usar producción para esta preparación.
2. Configurar en Auth Site URL y redirect allowlist del dominio de desarrollo: `/auth/callback`, `/auth/confirm`, `/actualizar-clave`.
3. Configurar correo/SMTP, política de contraseñas (mínimo 12) y límites de Auth. El restablecimiento de clave depende del correo del proveedor.
4. Crear el usuario administrativo en Supabase Auth con contraseña segura; copiar su UUID a BOOTSTRAP_ADMIN_USER_ID. El script no crea cuentas ni envía correos.
5. Ejecutar `npm run bootstrap:admin`. Solo funciona antes de existir un administrador activo. Revisar ubicaciones y permisos. Los usuarios invitados empiezan inactivos hasta asignar rol/ubicaciones explícitamente.
6. Ejecutar `npm run dev`; visitar la URL impresa. Para producción local: `npm run build` y `npm start`.

Sin configuración se muestra la preparación del acceso, sin datos ficticios ni conexión simulada. `APP_URL` debe coincidir exactamente con el origen desde el que se usa la aplicación; controla CSRF y enlaces de Auth.

## Funciones entregadas

- Inicio/cierre de sesión y actualización/recuperación de contraseña con Supabase Auth.
- Usuarios invitados, activación/desactivación, cuatro roles iniciales, creación de roles y permisos individuales con concesión/denegación.
- Ubicaciones asignadas por almacén; sucursales y depósito central independiente.
- Insumos, proveedores, categorías, unidades base, presentaciones, historial de precios de referencia y mínimos.
- Importación Excel de catálogos con plantillas, previsualización, duplicados y confirmación transaccional/idempotente.
- Apertura auditada de inventario por almacén; núcleo privado de movimientos, promedio ponderado móvil, bloqueo de negativos, idempotencia y concurrencia.
- Interfaz móvil/escritorio, manifiesto PWA y pantalla pública sin conexión. Las operaciones requieren conexión; no se cachean datos sensibles.

## Verificación

```sh
npm run lint
npm run typecheck
npm test
npm run build
```

Integración SQL: iniciar PostgreSQL aislado `seasons_test` en localhost; la suite borra y recrea SOLO sus esquemas. Por seguridad rechaza otra base o un host remoto.

```sh
docker run --detach --name seasons-f1-postgres --env POSTGRES_PASSWORD=seasons-local-test --env POSTGRES_DB=seasons_test --publish 127.0.0.1:55432:5432 postgres:17-alpine
TEST_DATABASE_URL=postgresql://postgres:seasons-local-test@127.0.0.1:55432/seasons_test npm run test:integration
```

`tests/integration/setup.ts` adapta las identidades de Supabase a claims SQL para probar RLS en PostgreSQL real. Esta suite por sí sola NO prueba el proveedor Auth o Storage.

E2E sin configuración: `npm run build && npm run test:e2e`. Usa Chromium en `/usr/bin/chromium` o PLAYWRIGHT_CHROMIUM_PATH; en otros sistemas instalar navegador con `npx playwright install chromium` y configurar su ruta.

E2E con GoTrue y PostgREST REALES locales:

```sh
docker compose -f tests/docker/compose.yml up -d
node scripts/local-gateway.mjs
# En otra terminal, tras estar GoTrue saludable:
node scripts/prepare-e2e.mjs
node scripts/with-e2e-env.mjs build
node scripts/with-e2e-env.mjs test
```

El gateway solo reenvía a GoTrue/PostgREST: no sustituye autenticación o persistencia. Datos/cuentas y clave de firma del compose son EXCLUSIVAMENTE de prueba. `.env.e2e.local` se genera ignorado; no sobreescribe la configuración del usuario. Este harness no incluye el servicio Storage o envío de correo externo.

## Documentación

- [Arquitectura](ARCHITECTURE.md), [base de datos](DATABASE.md), [API](API.md), [reglas](BUSINESS_RULES.md).
- [Despliegue y recuperación](DEPLOYMENT.md), [cambios](CHANGELOG.md).
- [Aprobaciones](docs/APPROVAL.md), [plan aprobado](docs/Seasons_Gestion_Fase_0_Planificacion_v1.1.md), [estado de Fase 1](docs/FASE_1_RESULTADOS.md).

Para repetir E2E desde cero, usar `docker compose -f tests/docker/compose.yml down -v` sobre este harness de prueba y volver a iniciar/preparar. El ensayo SQL de recuperación se ejecuta con `node scripts/test-restore.mjs` mientras el harness está activo.

No se ha publicado el sistema ni conectado con datos reales de Seasons. La aceptación definitiva requiere validar el proyecto Supabase elegido, correo, recuperación de archivos/datos y políticas operativas aún pendientes.
