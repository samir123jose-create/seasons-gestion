# Registro de aprobación

El usuario aprobó expresamente la planificación v1.1: «apruebo la planificacion v1.1».

Esto autoriza el desarrollo de Fase 1 dentro de sus límites. Arquitectura, navegación, matriz y secuencia de trabajo se toman como aprobadas. Las políticas señaladas como pendientes siguen pendientes hasta confirmación específica; la aprobación general no se interpreta como valores tributarios, rendimientos, objetivos de respaldo ni permisos individuales ya acordados.

Se comenzó H1.1–H1.3 y se consultó la política de valoración, stock negativo, moneda y redondeo para H1.4. No se autorizó publicación, modificaciones de producción ni Fase 2. Las verificaciones locales usan datos identificados de prueba en base aislada.

Confirmación posterior del usuario: «Confirmo esas políticas», en respuesta a promedio ponderado móvil por artículo/almacén, bloqueo de stock negativo, BOB, cantidades con 6 decimales, costos unitarios con 10, presentación monetaria con 2 y empates alejándose de cero. Se autoriza implementar ese alcance de H1.4. Continúan pendientes los datos reales de apertura, rendimientos, tratamiento tributario, objetivos RPO/RTO y asignaciones operativas por persona.

La precedencia de denegaciones explícitas se implementa como parte del modelo de autorización de la arquitectura aprobada (sección 4.5). La asignación de permisos operativos a personas concretas se mantiene pendiente; no se infieren concesiones por cargo.
