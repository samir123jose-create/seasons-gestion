# Dependencias y revisión

Consulta de metadatos del registro npm y documentación oficial durante esta implementación; versiones exactas en package.json/package-lock.json. Node del entorno 24.19.0 cumple Next >=20.9, Supabase JS >=22, Vitest ^24 y jsdom >=24.15.

Fuentes oficiales consultadas:
- Next.js instalación: https://github.com/vercel/next.js/blob/canary/docs/01-app/01-getting-started/01-installation.mdx
- SSR Supabase: https://github.com/supabase/ssr/blob/main/README.md
- Imágenes/variables Auth/PostgREST: https://github.com/supabase/supabase/blob/master/docker/docker-compose.yml
- Peer dependencies/engines: https://registry.npmjs.org/next/latest y metadatos equivalentes de paquetes fijados.

Se escogió TypeScript5.9 compatible con el rango declarado de typescript-eslint; las etiquetas latest por sí solas no establecen compatibilidad. ESLint10 usa plugins actuales compatibles directamente; no se fuerza peer dependency incompatible de eslint-config-next.

ExcelJS4.4 es requisito del usuario. Sus dependencias heredadas tienen avisos de deprecación; el override uuid11.1.1 corrige el advisory GHSA-w5hq-g745-h8pq (bounds de buffers v3/v5/v6). Se comprobaron creación/lectura de XLSX y rechazo de ZIP/celdas inválidas. No se interpreta un npm audit limpio como garantía de ausencia de vulnerabilidades.

No se instalaron todavía Recharts/PDF porque corresponden a F4; se revisarán compatibilidad y mantenimiento cuando se implemente ese alcance. pg, GoTrue y PostgREST del harness sirven para comprobar servicios reales aislados, no cambian el stack de producción aprobado.
