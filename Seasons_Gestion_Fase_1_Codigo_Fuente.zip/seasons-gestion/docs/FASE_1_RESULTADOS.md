# Seasons Gestión — resultados de Fase 1

Estado: implementación local revisable, pendiente de aceptación en el entorno real de Seasons. La aprobación v1.1 y la confirmación de valoración/stock/redondeo están en APPROVAL.md. No se ha publicado la aplicación, usado datos de producción ni comenzado Fase 2.

## Entregado

- Next.js App Router, React, TypeScript estricto, Tailwind, Lucide, configuración de calidad, lockfile y CI.
- Auth con cookies SSR, login/logout, recuperación por OTP/PKCE, cambio de contraseña y cuenta activa comprobada en cada operación.
- Usuarios, cuatro roles iniciales, creación/configuración de roles, concesiones/denegaciones individuales y asignación por almacén.
- Catálogos persistentes: sucursales, almacenes, proveedores, categorías, insumos, unidades y presentaciones. Leche 900 ml y conversiones kg/g/l/ml; bloqueo de dimensiones incompatibles.
- Presentaciones/unidades base protegidas contra cambios que alterarían historia; precios de referencia con fecha, fuente y costo unitario histórico.
- Mínimos por artículo/ubicación e importación Excel por plantillas, códigos de categorías/unidades, previsualización, errores/duplicados y confirmación atómica/idempotente.
- Apertura auditada única por almacén y motor privado: promedio ponderado móvil, bloqueo de negativos, exactitud decimal, locks e idempotencia.
- Interfaz en español para escritorio/móvil; corrección de diálogo fuera de viewport móvil y búsqueda literal de códigos/nombres con puntuación, estados de carga/error/éxito y PWA base sin cachear datos de usuarios.
- Diez pares principales de texto comprobados con contraste ≥4,5:1; no se declara auditoría WCAG completa.
- Documentación de instalación, arquitectura, modelo, API, reglas y preparación de despliegue/recuperación.

La precedencia de denegaciones se implementa según el modelo de autorización de la arquitectura aprobada. Los permisos operativos de personas concretas siguen requiriendo asignación explícita. Los roles de colaborador/deposito/sucursal no reciben stock/costos/conteos automáticamente.

## Verificación ejecutada

| Verificación | Resultado y límite |
|---|---|
| ESLint | Aprobado con ESLint10 y plugins compatibles, sin forzar peers. |
| TypeScript | Aprobado en modo estricto; también comprobado por compilación. |
| Vitest/RTL | 29 pruebas aprobadas: conversiones, cantidades, formato monetario exacto, Excel, HTTP y formularios. |
| PostgreSQL aislado | 22 pruebas aprobadas sobre PostgreSQL17 real: RLS/grants, revocación, versiones, precio histórico, rollback, concurrencia, promedio, saldos reconstruibles e importación. Adaptador SQL de claims, no simulación de base de datos. |
| Playwright con proveedor | 25 pruebas aprobadas en escritorio y móvil con GoTrue2.196/PostgREST14.17 reales y datos separados. Una repetición móvil de recuperación se omite deliberadamente; la recuperación por OTP/cambio de contraseña se ejecuta en escritorio. |
| Playwright sin configuración | 8 pruebas aprobadas de entrada, rutas protegidas, Origin y recursos PWA; no se finge conexión. |
| Bundle de navegador | Clave administrativa ausente en archivos JS de cliente; se usa server-only para clientes privilegiados. |
| Compilación | Aprobada con Next16.4/Webpack y comprobación de tipos activa. |
| Restauración SQL | Ensayo aislado aprobado: datos, identidades Auth, saldos, auditoría y RLS coinciden; duración observada 1,16 s en dataset de prueba. No es objetivo RTO de producción ni prueba de restauración de objetos Storage. |
| Dependencias de producción | npm audit reportó 0 vulnerabilidades tras override uuid11.1.1 de ExcelJS. No equivale a garantía permanente o ausencia de avisos de deprecación transitorios. |

No se afirma que el workflow de GitHub Actions haya corrido en GitHub: está preparado y sus comandos se ejecutaron localmente. No se afirma envío de correo externo: OTP se verificó con enlace generado por Auth real local. Storage en el harness contiene metadata de bucket; no se ejecutó servidor Storage ni recuperación de objetos reales.

## Criterios de Fase 1

| ID | Estado |
|---|---|
| AC1-01 | Proyecto instalado, tipos/build verificados; README y lockfile entregados. Repetir instalación en equipo de Seasons. |
| AC1-02 | Migraciones reconstruidas en PostgreSQL y con Auth/API reales locales. Aplicación al Supabase de desarrollo pendiente. |
| AC1-03 | Login/logout, OTP, cambio de contraseña y cuenta desactivada verificados. Entrega de correo externo pendiente de SMTP. |
| AC1-04 | Cuatro roles, permisos, ubicaciones y configuración entregados; asignaciones reales del equipo pendientes. |
| AC1-05 | Revocación/concesiones y ocultación de costos comprobadas en SQL/API; no solo botones. |
| AC1-06 | Acceso cruzado a almacenes bloqueado en API/RLS/RPC. |
| AC1-07 | Tres ubicaciones iniciales y alta de nuevos almacenes comprobadas. |
| AC1-08 | Persistencia/auditoría/versiones y desactivación de catálogos implementadas; sin borrado histórico. |
| AC1-09 | 900 ml ×2=1.800 ml, kg→g y rechazo de g→ml comprobados. Equivalencias específicas no aprobadas no se inventan. |
| AC1-10 | Presentación inmutable y precio/fuente/costo histórico separados y comprobados. |
| AC1-11 | Excel con previsualización, duplicados, errores, rollback y reintento comprobados. Datos iniciales reales/formatos de Seasons pendientes. |
| AC1-12 | Desktop/móvil y PWA base comprobados; no edición offline ni certificación WCAG completa. |
| AC1-13 | Clave administrativa aislada por server-only; permisos/grants probados. Validación de Storage/vistas/configuración en proveedor real pendiente. |
| AC1-14 | Motor/apertura/rollback/concurrencia/idempotencia verificados; no formulario completo de inventario/producción todavía. |
| AC1-15 | NUMERIC, BigInt para conversiones/formato, precisión y redondeo confirmados y comprobados. |
| AC1-16 | Recuperación SQL aislada comprobada. RPO/RTO/retención y recuperación de objetos/configuración del proveedor real pendientes. |
| AC1-17 | Lint/tipos/pruebas/build ejecutados; fallos de herramientas y diálogo móvil corregidos; CI preparado. |
| AC1-18 | Documentación y .env.example entregados; matriz de avance por RF adjunta. |

## Límites que deben revisarse antes de cierre operativo

1. Conectar un proyecto Supabase de desarrollo de Seasons y validar las migraciones, grants, RLS y Auth con ese proveedor; no pegar claves en el chat/documentación.
2. Configurar SMTP/plantillas/redirect allowlist y probar invitación/recuperación por correo.
3. Acordar RPO/RTO/retención y ensayar recuperación de datos, objetos Storage y configuración. Las fotos/comprobantes se incorporan en F2/F3 con sus políticas de acceso; el bucket inicial permanece privado.
4. Revisar datos de catálogos/apertura y asignaciones por persona; fijar volúmenes/latencia/límites de archivo adecuados para el equipo.
5. Las listas de selección/equipo están limitadas a 1.000 entradas; precios muestra últimos 500, auditoría últimos 200, importación hasta 1.000 filas/5 MB/20 MB expandido. La base conserva la historia completa; paginación y formatos adicionales se revisarán al validar volumen.

Fase 1 no se declara aceptada en producción con estas dependencias pendientes. Se entregan código y evidencia local para revisión; Fase 2 requiere cerrar/verificar Fase 1 y autorización del usuario según el pedido.
