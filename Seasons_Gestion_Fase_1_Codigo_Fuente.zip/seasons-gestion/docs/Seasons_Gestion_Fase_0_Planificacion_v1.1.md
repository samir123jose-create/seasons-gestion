# Seasons Gestión — Fase 0: análisis y planificación
Versión de propuesta: 1.1 · Revisión: 12 de octubre de 2026 (America/La_Paz)
Estado: para revisión. No constituye autorización de programación, publicación ni cambios de producción.

## 1. Comprensión del proyecto y fuentes
Seasons Gestión será una aplicación empresarial para centralizar recetas y estándares, insumos, compras, producción, inventarios, distribución, conteos, gastos y calidad. Tendrá una base de datos común, inventarios independientes por ubicación y permisos por persona, acción y ubicación. Debe funcionar con datos reales, desde computadora y celular, ser instalable como PWA y conservar código y datos exportables.

Ubicaciones iniciales: depósito central, Seasons Mega Mall y Seasons Av. Murillo. Una sucursal puede tener varios almacenes. El depósito central no necesita ser tratado como punto de venta para existir como ubicación de inventario.

Fuentes leídas:
- D: Seasons Gestión — Documento maestro de requerimientos funcionales, versión 1.0, 9 de octubre de 2026. Se revisaron sus once secciones y todas sus tablas.
- P: pedido del usuario contenido en «Texto pegado.txt», prompt maestro de desarrollo, especificaciones técnicas 1.0, secciones 1–16.
- F: planificación Fase 0 v1.0 adjunta, tomada como propuesta previa, no como aprobación. Esta revisión conserva sus identificadores y corrige ambigüedades.

Las instrucciones de trabajo proceden de P. D y F son fuentes de requisitos y propuestas; sus frases de «próximo paso» no sustituyen el pedido ni acreditan autorización anterior. Se leyeron completamente los tres archivos; D fue extraído del DOCX incluyendo sus tablas.

Convenciones:
- Definido: requisito explícito en D o P. No convierte decisiones abiertas del documento en reglas aprobadas.
- Recomendado: propuesta de diseño, seguridad o implementación.
- Pendiente: regla que debe decidirse antes de implementar el flujo afectado.
- F0–F6: fases del prompt. La matriz identifica fase de entrega, no autorización para iniciarla.

El sistema registrará consumos reales de producción y otras salidas documentadas. Sin integrar el POS no deducirá ventas ni podrá afirmar el consumo real completo de cada día. El análisis de márgenes requiere un precio de venta explícito; no se inventarán ingresos, utilidad ni rentabilidad comercial.

### Diferencias entre fuentes y resolución propuesta
| ID | Diferencia o vacío | Propuesta sometida a aprobación |
|---|---|---|
| X01 | D4.2/D9 dejan fabricación real en V1 como decisión; P8.5/P13 la exigen en F2. | Incluir producción real en F2. Eliminar la opcionalidad únicamente después de aprobar este plan. |
| X02 | D9 pide dashboard básico en V1; P13 coloca dashboard y reportes en F4. | Seguir F1–F6 del prompt; F1–F3 pueden mostrar listas y alertas operativas, dashboard consolidado en F4. |
| X03 | Producción en F2 necesita stock y consumos; compras y pantallas de inventario se entregan en F3. | Preparar motor transaccional, movimientos, valoración y saldo inicial auditado como infraestructura compartida en F1/F2, sin adelantar la interfaz completa de F3. |
| X04 | D4.4 usa enviada/preparada; P8.8 usa pendiente/en preparación y añade cerrado. | Unificar estados internos; conservar etiquetas comprensibles. Separar solicitud, traslado y recepciones. |
| X05 | P8.11 incluye gastos en dashboard F4; gastos completos se entregan en F5. | Captura mínima de gastos en F4; ampliar gestión y análisis en F5. Mientras no haya datos, mostrar “sin datos”, nunca cero inventado. |
| X06 | D requiere importación Excel, alérgenos, utensilios, devoluciones y recuperación de respaldos; P no los detalla igual. | Conservar todos: importación progresiva F1/F2/F3; devoluciones F3; alérgenos/utensilios F2; recuperación F1 y antes de uso real. |
| X07 | “PWA” no especifica edición sin conexión. | Recomendar PWA instalable; operaciones críticas en línea. Lectura offline de recetas publicada se diseña aparte y requiere aprobación de reglas de vigencia y privacidad. |
| X08 | D menciona consumo estimado y P futuro consumo teórico por ventas. | No entregar integración POS en F1–F5; etiquetar consumo teórico solo cuando exista fuente válida y mapeo aprobado. |
| X09 | D4.2 pide recalcular dependientes al cambiar una subreceta; F propone fijar versiones. Son compatibles para precios, pero una nueva formulación cambia el estándar físico. | Recalcular estimaciones al cambiar precios de la misma formulación; una formulación nueva genera revisión y republicación explícita de dependientes. Confirmar A15 antes de F2. |

X01, X02, X03, X04, X05 y X09 se incluyen en la aprobación de alcance. No se implementará silenciosamente una de las dos interpretaciones.

## 2. Matriz de requisitos funcionales
Cada ID es estable. «Definido» identifica una necesidad explícita; la columna de estado señala por separado políticas o ampliaciones pendientes. Todas las filas siguen sin implementar. La aceptación de una fila se verificará junto con permisos, validación, persistencia y auditoría aplicables. “Base” refiere a infraestructura compartida aprobable mediante X03.

| ID | Requisito y resultado verificable | Fuente | Fase | Dependencia principal | Estado de definición |
|---|---|---|---|---|---|
| RF-001 | Inicio/cierre de sesión y recuperación de contraseña con sesiones reales. | D2; P8.1 | F1 | Supabase Auth | Definido |
| RF-002 | Crear/invitar, activar y desactivar usuarios; desactivado no opera con una sesión anterior. | D2; P8.1 | F1 | RF-001 | Definido |
| RF-003 | Administrar roles y permisos específicos sin codificar acceso por nombre del cargo. | D2; P8.1 | F1 | RF-002 | Definido |
| RF-004 | Asignar usuarios a una o varias sucursales y ámbitos de almacén. | D2; P8.1 | F1 | RF-003, RF-007 | Definido; ámbito de almacén propuesto |
| RF-005 | Conceder/revocar permisos individuales de stock, costos, conteos, recepción, ajustes y reportes. | D4.6; P8.1 | F1 | RF-003 | Definido; A01 pendiente |
| RF-006 | Historial de acciones sensibles con actor, fecha, motivo y entidad afectada. | D1/7; P8.1 | F1–F5 | Autorización | Definido |
| RF-007 | Registrar tres ubicaciones iniciales y agregar sucursales/subalmacenes sin rediseño. | D4.4; P3/8.1 | F1 | Ninguna | Definido |
| RF-008 | Catálogo de ingredientes, materiales, empaques y preparaciones, categorías y estado activo. | D4.3; P8.2 | F1/F2 | RF-009 | Definido |
| RF-009 | Unidades base, dimensiones y conversiones compatibles; bloquear g→ml sin equivalencia específica validada. | D4.3/7; P8.2 | F1 | Catálogo de unidades | Definido; A02 pendiente |
| RF-010 | Presentaciones comerciales y unidades de pedido distintas de la unidad base. | D4.3/5; P8.2 | F1 | RF-009 | Definido; equivalencias A02 pendientes |
| RF-011 | Proveedores, contactos y relación con insumos/presentaciones. | D4.3; P8.2 | F1 | RF-008 | Definido |
| RF-012 | Historial de precios con origen, vigencia y unidad; separar precio y costo valorizado. | D4.3/7; P8.2 | F1/F3 | RF-010, RF-035 | Definido; fuente y apertura A03/A12 pendientes |
| RF-013 | Stock mínimo configurable por artículo y ubicación. | D4.4; P8.2/8.6 | F1/F3 | RF-007, RF-008 | Definido; mínimo por ubicación propuesto |
| RF-014 | “Mis recetas”: catálogo completo, búsqueda por nombre/código/categoría, filtros y activos/inactivos. | D4.1/5/11; P8.3 | F2 | RF-008 | Definido |
| RF-015 | Editor: nombre, código, categoría, descripción, tamaño, rendimiento y sucursal aplicable. | D4.1; P8.3 | F2 | RF-014 | Definido |
| RF-016 | Ingredientes, subrecetas, cantidades, empaques y complementos definidos. | D4.1/4.2; P8.3/8.4 | F2 | RF-009 | Definido |
| RF-017 | Procedimiento numerado, utensilios, alérgenos, instrucciones especiales y controles de calidad. | D4.1; P8.3 | F2 | RF-015 | Definido |
| RF-018 | Fotografía de referencia/final, imágenes por paso y presentación. | D4.1; P8.3 | F2 | Almacenamiento seguro | Definido |
| RF-019 | Borrador, vista previa, publicación, vigencia y consulta de historial de versiones. | D4.1/11; P8.3 | F2 | RF-015–018 | Definido; A15 pendiente |
| RF-020 | Editar, duplicar y archivar sin eliminar versiones usadas en operaciones. | D4.1/11; P8.3 | F2 | RF-019 | Definido |
| RF-021 | Colaborador consulta versiones publicadas vigentes de su sucursal; costos/márgenes ocultos por defecto y expuestos solo con permiso explícito. | D2/4.1/11; P8.3 | F2 | RF-005, RF-019 | Definido; costos ocultos por defecto, concesión según A01 |
| RF-022 | Recetas compuestas multinivel y bloqueo de ciclos directos e indirectos. | D4.2/11; P8.4 | F2 | RF-016 | Definido |
| RF-023 | Costo estimado por unidad/porción con rendimiento útil, merma y costo de componentes, sin duplicación. | D4.2; P8.3/8.4 | F2 | Política de costo aprobada | Definido; fórmula y A03/A10 pendientes |
| RF-024 | Actualizar costo estimado de dependientes ante variaciones de precios, preservando costos históricos. | D4.2/7; P8.4/9 | F2/F3 | RF-012, RF-022 | Definido; interpretación X09/A15 pendiente |
| RF-025 | Ficha de preparación clara y responsive para uso móvil. | D4.1/5; P8.3 | F2 | RF-017–021 | Definido |
| RF-026 | Producción real: versión, ubicación, responsable, fecha y cantidad planificada. | D4.2/5; P8.5 | F2 | X01/X03 | Exigido por P; discrepancia X01/X03 pendiente |
| RF-027 | Registrar insumos reales, rendimiento obtenido, diferencias, pérdidas y observaciones. | D4.2; P8.5 | F2 | RF-026 | Definido; A02/A13 pendientes |
| RF-028 | Lote producido con unidad de salida, costo histórico y vencimiento cuando aplique. | D4.2; P8.5 | F2/F5 | Política de lotes | Definido; A08 pendiente |
| RF-029 | Confirmación atómica: consumir insumos y dar entrada a preparación; fallo no deja efectos parciales. | D7; P8.5 | F2 | Motor de inventario Base | Definido; infraestructura X03 pendiente |
| RF-030 | Existencias y Kardex por artículo/ubicación, con lote cuando aplique y fecha de corte. | D4.4/6; P8.6 | F3 | Motor Base | Definido; valoración A03 pendiente |
| RF-031 | Entradas/salidas justificadas y trazables; saldos no se editan directamente. | D4.4/7; P8.6 | F2/F3 | RF-006 | Definido |
| RF-032 | Correcciones mediante contramovimiento/ajuste auditado y permiso explícito. | D7; P8.6 | F3 | RF-031 | Definido; A13 pendiente |
| RF-033 | Reintentos/doble clic no duplican compras recibidas, producción, despachos o recepciones. | P8.6/11 | Base–F3 | Idempotencia transaccional | Definido |
| RF-034 | Política de stock insuficiente y operaciones simultáneas aplicada en base de datos. | D7; P11 | Base–F3 | Decisión A04 | Definido; política A04 pendiente |
| RF-035 | Compras: proveedor, fecha, destino, líneas, cantidades, precio, descuentos, adicionales y total. | D4.3; P8.9 | F3 | RF-009–012 | Definido; A10 pendiente |
| RF-036 | Comprobante/documentos, responsable y observaciones de compra. | D4.3; P8.9 | F3 | Storage | Definido |
| RF-037 | Recepción confirmada, incluso parcial: solo cantidad recibida incrementa stock. | D11; P8.9/11 | F3 | RF-035, RF-033 | Definido; recepción parcial de compras recomendada |
| RF-038 | Devoluciones de compra y retorno entre ubicaciones con efectos explícitos y auditados. | D4.4 | F3 | RF-030–037 | Devolución definida; flujo específico A13 pendiente |
| RF-039 | Carrito de solicitud por unidad de pedido, comentarios y ubicación destino. | D4.4/5; P8.8 | F3 | RF-010 | Definido |
| RF-040 | Bandejas: mis solicitudes, pendientes, aprobación/rechazo y seguimiento. | D2/4.4; P8.8 | F3 | RF-005, RF-039 | Definido |
| RF-041 | Estados y transiciones válidas de solicitud; cancelación y cierre controlados. | D4.4; P8.8 | F3 | Decisión A05 | Definido; estados X04/A05 pendientes |
| RF-042 | Preparación y despacho vinculados a solicitud o traslado autorizado. | D4.4; P8.8 | F3 | RF-041 | Definido |
| RF-043 | Transferencia origen→tránsito→destino; cantidades y valoración conservadas. | D4.4/11; P8.6/8.8 | F3 | Decisión A06 | Transferencia definida; tránsito recomendado A06 |
| RF-044 | Recepción parcial, conformidad, faltantes/sobrantes y resolución antes del cierre. | D4.4; P8.8 | F3 | RF-043 | Definido; reglas de diferencias A06 pendientes |
| RF-045 | Frecuencia de conteos por sucursal, almacén, grupo o ingrediente; cada N días, semanal, mensual o calendario. | D4.5; P8.7 | F3 | RF-007/008 | Definido; calendario A07 pendiente |
| RF-046 | Conteo programado/extraordinario: responsable, plazo, recordatorio y estado. | D4.5; P8.7 | F3 | RF-045 | Definido; canal y plazo A07/A16 pendientes |
| RF-047 | Stock teórico a corte, cantidad contada, diferencia, observación y revisión. | D4.5; P8.7 | F3 | Política de corte | Definido; corte A07 pendiente |
| RF-048 | Aprobar ajuste derivado de conteo; registrar conteo no modifica saldo por sí solo. | D4.5; P8.7 | F3 | Decisión A07 | Definido; aprobadores/umbral A07 pendientes |
| RF-049 | Mermas operativas con motivo, lote/artículo, ubicación, cantidad, autor y costo histórico. | D4.4/6; P8.6 | F3 | RF-030 | Definido |
| RF-050 | Alertas por mínimo, solicitudes y conteos vencidos, según permisos. | D4.4/4.5; P8.6/8.7 | F3/F4 | RF-013/040/046 | Definido |
| RF-051 | Gastos operativos separados de compras, traslados y consumo; sin doble desembolso. | D4.3/6; P8.9 | F4 mínimo/F5 | X05 | Definido; adelanto mínimo X05 pendiente |
| RF-052 | Formulario móvil de incidencia: sucursal, receta/versión/lote, descripción, criticidad y fotos. | D4.7; P8.10 | F5 | RF-018/028 | Definido |
| RF-053 | Clasificar, asignar responsable, registrar acciones correctivas y cerrar incidencias con historial. | D4.7; P8.10 | F5 | RF-052 | Definido |
| RF-054 | Lotes/vencimientos obligatorios por producto, alertas y tratamiento de vencidos configurable. | D4.2/4.4/10; P8.6/13 | F2/F3 básico; F5 avanzado | Decisión A08 | Definido; catálogo obligatorio A08 pendiente |
| RF-055 | Dashboard de compras, gastos, stock, mínimos, solicitudes y movimientos con fuentes identificadas. | D6/9; P8.11 | F4 | F2/F3/X05 | Definido |
| RF-056 | KPIs de mermas, producción, costos, precios, diferencias y cumplimiento de conteos. | D6; P8.11 | F4 | RF-026/047/049 | Definido |
| RF-057 | Filtros fecha/sucursal/almacén/categoría/artículo/usuario autorizado y comparación por sucursal. | D6; P8.11 | F4 | RF-004 | Definido |
| RF-058 | Indicador documenta fórmula, unidad, fuente, fecha de corte y tratamiento de ausencia de datos. | D6; P8.11 | F4 | Diccionario KPI | Definido; fórmulas de indicadores por aprobar |
| RF-059 | Reportes de compras/proveedor, catálogo/precios y costos, Kardex, stock y transferencias. | D6; P8.11 | F4 | RF-030/035 | Definido |
| RF-060 | Reportes de solicitudes, conteos, mermas y producción; incidencias al entrar F5. | D6; P8.11 | F4/F5 | Módulos respectivos | Definido |
| RF-061 | Exportar Excel/PDF con marca, periodo, ubicación, resumen, tablas, indicadores y gráficos pertinentes. | D6; P8.11 | F4 | RF-059/060 | Definido |
| RF-062 | Exportaciones respetan permisos de ubicación y costos, y coinciden con la consulta filtrada. | D2/6; P8.11 | F4 | RF-005/057 | Definido |
| RF-063 | Importar Excel: mapa de columnas/unidades, previsualización, errores y duplicados antes de confirmar. | D1/7 | F1 catálogos; F2 recetas; F3 saldos | Plantillas reales | Importación definida; fases y entidades de importación propuestas |
| RF-064 | Preparar API externa autenticada sin exponer tablas; versionar contratos. | D1/8; P5/13 | F1 estructura/F6 integración | API y autorización | Definido |
| RF-065 | Integrar POS: equivalencias productos, ventas/anulaciones/devoluciones y origen trazable. | D8/9; P13 | F6 | Capacidades POS | Integración futura definida; capacidades A14 pendientes |
| RF-066 | Consumo teórico por ventas separado de consumo registrado y conciliación con conteos. | D6/9; P8.11/13 | F6 | RF-065 | Definido; eventos y conciliación A14 pendientes |
| RF-067 | BI avanzado sin alterar hechos operativos ni costo histórico. | D9; P13 | F6 | RF-058/066 | Definido |
| RF-068 | Configuración de políticas, recordatorios, alertas y ámbitos operativos. | D3/5; P8.1/8.7 | F1/F3/F5 | Decisiones A | Definido; valores de políticas pendientes |
| RF-069 | Instalación PWA y experiencia móvil según alcance offline aprobado. | D1/8; P7 | F1 base/F2 | A09 | Definido; offline A09 pendiente |
| RF-070 | Configuración y evidencia de respaldo/recuperación de datos y archivos. | D7 | F1 y puesta en uso | A11 | Definido; objetivos A11 pendientes |

La matriz cubre los contenidos del documento y las ampliaciones del prompt. En implementación, cada RF se vinculará a archivos, endpoint, prueba y evidencia de aceptación. Ninguna funcionalidad diferida se declara terminada.

## 3. Requisitos no funcionales
| ID | Requisito | Verificación propuesta |
|---|---|---|
| RNF-001 | Stack obligatorio y TypeScript estricto; dependencias estables compatibles. | Registro de versiones/Node.js, revisión oficial, lockfile, typecheck y build. |
| RNF-002 | Monolito modular; UI, casos de uso, dominio, repositorios y API separados. | Revisión de dependencias y ADR; sin reglas de cálculo en React. |
| RNF-003 | Autenticación segura y autorización por acción/recurso/ubicación. | Pruebas con usuarios de diferentes ámbitos y sesión desactivada. |
| RNF-004 | RLS y grants apropiados; protección también en vistas, RPC y Storage. | Intentos de acceso directo, cambio de identificador y filtrado de costos. |
| RNF-005 | Secretos solo en servidor; contraseñas en Auth. | .env.example sin secretos, revisión de bundle y configuración. |
| RNF-006 | Exactitud decimal y política de redondeo única. | Casos unitarios monetarios y comparación con PostgreSQL. |
| RNF-007 | Atomicidad, idempotencia y control de concurrencia. | Fallo intermedio, reintentos, doble envío y dos consumos simultáneos. |
| RNF-008 | Trazabilidad e historia inmutable de operaciones confirmadas. | Autor, fecha, origen, versión, costo y corrección conservados. |
| RNF-009 | Responsive/táctil; accesibilidad básica. | Teclado, foco, etiquetas, errores, contraste y viewport móvil. |
| RNF-010 | Estados de carga, vacío, error, confirmación y éxito. | Pruebas de componentes y E2E con fallos de red. |
| RNF-011 | Seguridad de archivos: tipo real, tamaño, ámbito y descarga. | Archivo inválido, acceso cruzado, URL expirada y carga incompleta. |
| RNF-012 | Ambientes separados y datos de ejemplo identificados. | CI con base aislada; no conectar pruebas destructivas a producción. |
| RNF-013 | Rendimiento con consultas paginadas, índices y SQL optimizado. | Planes de consulta y medición con volumen representativo aprobado. |
| RNF-014 | Recuperación de datos y archivos probada. | Restauración documentada en ambiente separado. |
| RNF-015 | Portabilidad del código, SQL, archivos y configuración. | Exportación/restauración y adaptadores documentados; sin dependencia innecesaria del host. |
| RNF-016 | API REST /api/v1, validación Zod y errores uniformes. | Contratos, límites, autenticación y pruebas de integración. |
| RNF-017 | Observabilidad sin filtrar credenciales ni información privada. | request_id, errores estructurados y eventos operativos auditados. |
| RNF-018 | Automatización CI y calidad de pruebas. | Lint, tipos, unitarias, integración, E2E del alcance y compilación. |
| RNF-019 | Documentación y migraciones versionadas. | README, ARCHITECTURE, DATABASE, API, BUSINESS_RULES, DEPLOYMENT, CHANGELOG. |
| RNF-020 | Identidad Seasons y componentes consistentes. | Marca Seasons, eslogan «Siente cada momento.», verde #009A77, coral #F1886F, fondos claros; contraste verificado. |

| RNF-021 | Dominio propio y configuración migrable, definidos en D8. | Procedimiento DNS/TLS y variables por ambiente; ejecución al autorizar publicación. |
| RNF-022 | Protección de endpoints y sesiones, definida en P10; controles específicos recomendados. | En F1: cookies seguras, comprobación de origen/CSRF donde aplique, límites en Auth/importaciones/exportaciones y ausencia de caché pública de datos privados. |

Recomendaciones cuantificables pendientes: objetivos táctiles de aproximadamente 44 px y WCAG 2.2 AA como referencia; establecer un volumen de prueba y objetivo de latencia antes de evaluar rendimiento. RPO, RTO, retención, usuarios simultáneos, tamaños máximos de archivos y volumen mensual deben acordarse. No se promete rendimiento o disponibilidad sin mediciones.

## 4. Arquitectura técnica propuesta
### 4.1 Stack y despliegue
Definido: Next.js App Router, React, TypeScript estricto, Tailwind, Lucide; Route Handlers /api/v1 y Zod; PostgreSQL/Supabase, Auth y Storage; Recharts, ExcelJS y PDF en servidor; Vitest, React Testing Library, Playwright; Git/GitHub, GitHub Actions y Vercel inicial.

Recomendado:
- Route Handlers y generación de archivos sobre runtime Node.js.
- Server Components para lectura que no necesita interacción; Client Components para formularios, acciones táctiles y gráficos. Ambos llaman a casos de uso protegidos.
- Repositorios con interfaces y adaptadores Supabase; cliente administrativo aislado para provisión de cuentas, nunca para todas las operaciones ordinarias.
- PDFKit como candidato para PDF de servidor. Validar compatibilidad, fuentes y render de gráficos antes de instalar. No está aprobado como dependencia definitiva.
- Persistir decimales exactos en SQL; enviarlos como cadenas decimales en API. Cálculos autoritativos en PostgreSQL. Si se necesita matemática decimal en TypeScript, proponer una única biblioteca decimal y su justificación antes de incorporarla.
- Cron del proveedor inicial para recordatorios/conteos, invocando un caso de uso autenticado e idempotente; adapter reemplazable y límites del plan verificados antes de configurarlo.
- Sin ORM, microservicios, colas, Redis o motor BI adicional inicialmente. Añadir únicamente ante necesidad comprobada.

Las versiones exactas se escogerán al iniciar F1, con verificación de documentación oficial, versiones compatibles de React/Next, Node.js y lockfile. En F0 no se han instalado paquetes.

### 4.2 Capas y contratos
Interfaz → controlador delgado → caso de uso y autorización → reglas de dominio → puerto de repositorio → adaptador SQL/Supabase.
- El controlador interpreta petición, valida con Zod y traduce errores.
- El caso de uso coordina permisos, reglas y transacción.
- Dominio conserva invariantes, cálculos y transiciones.
- Persistencia asegura atomicidad y restricciones que no deben poder saltarse.
- Lecturas desde servidor pueden llamar al mismo caso de uso sin hacer una petición HTTP al propio servidor.
- API pública expone DTO de negocio, no el esquema interno. Desacoplar frontend de tablas permite cambiar alojamiento y almacenamiento.

La recomendación de centralizar autorización cerca del acceso a datos se apoya en las guías oficiales de Next.js. Las credenciales privilegiadas y las vistas/funciones requieren controles adicionales a RLS; ocultar un menú no protege el recurso.

### 4.3 Transacciones y Supabase
No encadenar varios INSERT por HTTP y llamarlo “transacción”. Para confirmar producción, recepción o traslado se utilizará una única operación transaccional PostgreSQL a través de una función RPC versionada y probada.

Esquemas internos para datos sensibles y de costos; grants mínimos; sin escritura directa del navegador a saldos, movimientos, costos históricos o permisos.
- Lecturas y funciones con SECURITY INVOKER cuando los grants y RLS permiten el caso de uso.
- Si se requiere SECURITY DEFINER para realizar una mutación controlada sin conceder escritura directa, justificarla en un ADR. Revocar ejecución pública/anon, fijar search_path, referenciar esquemas explícitamente y comprobar auth.uid(), cuenta activa, permisos y ámbitos dentro de la función.
- El acceso directo a una RPC nunca debe saltarse autorización, validación, transición ni idempotencia. Cada función constituye otra superficie a probar.
- La API del POS será /api/v1; no se ofrecerá acceso externo a tablas de Supabase.
- RLS es de filas: separar columnas/entidades de costos y DTO de lectura de receta para que “puede leer receta” no equivalga a “puede leer costo”.

Revisar grants y owner de funciones; una función privilegiada puede eludir RLS. La clave administrativa no se usa como atajo para consultas de usuarios.

### 4.4 API y estructura
Propuesta de grupos de endpoints:
- /api/v1/usuarios, /roles, /permisos, /sucursales, /almacenes.
- /insumos, /unidades, /presentaciones, /proveedores, /precios.
- /recetas, /recetas/{id}/versiones, /versiones/{id}/publicar.
- /producciones, /producciones/{id}/confirmar.
- /compras, /compras/{id}/recepciones, /devoluciones.
- /existencias, /movimientos, /solicitudes, /transferencias y /recepciones.
- /politicas-conteo, /conteos, /ajustes, /mermas.
- /gastos, /incidencias, /indicadores, /reportes, /importaciones.

Convenciones recomendadas: IDs UUID; paginación; fechas ISO 8601; importes/cantidades como cadenas; errores con código, mensaje y request_id; versión de documento para edición concurrente; Idempotency-Key en confirmaciones; 401 sin sesión, 403 sin permiso, 409 para conflicto, validación con respuesta uniforme. No revelar existencia de recursos ajenos cuando el caso requiera respuesta 404.

Conservar la estructura del prompt. Dentro de cada módulo: domain, application, infrastructure, schemas, components y tests cuando corresponda. Agregar un módulo integraciones en F6 y un módulo importaciones para RF-063. Un servicio compartido de archivos puede vivir en lib. Esto organiza funciones ya exigidas, no añade negocio.

Route groups no generan prefijos de URL: usar /admin y /operacion explícitos bajo los grupos para evitar colisiones entre las páginas de inicio de administrador y colaborador.

### 4.5 Autorización
Modelo propuesto: permisos efectivos = concesiones de roles + concesiones individuales − denegaciones explícitas; siempre intersectado con sucursales/almacenes asignados y estado activo. La precedencia de denegaciones se debe aprobar (A01).

Validar cada operación y sus objetos relacionados: permiso de recibir en Murillo no habilita despacho desde depósito; traslado valida ambos ámbitos según acción. Revocaciones se consultan desde datos vigentes en cada petición sensible; no depender de permisos antiguos conservados en JWT o caché pública.

### 4.6 PWA y operaciones sin conexión
Recomendación inicial: instalable, responsive y con estados explícitos de conexión. Confirmaciones de compra, producción, traslado, recepción y ajustes requieren conexión y respuesta del servidor.
No cachear API administrativa, costos ni credenciales en service worker. Si posteriormente se aprueba lectura offline de recetas, definir duración, sucursal, usuario, versión y revocación; limpiar datos en cierre de sesión y advertir cuando no puede comprobarse vigencia.

### 4.7 Límite de los respaldos y entornos
El respaldo SQL no demuestra recuperación de fotografías/comprobantes, usuarios de Auth y configuración. El ensayo debe inventariar datos, objetos, políticas, configuración y dependencias de identidad. Restaurar en un ambiente aislado y verificar vínculos y sesiones según el mecanismo del proveedor. El plan contratado, retención y restauración puntual se verificarán antes de prometerlos. La recuperación de contraseñas y notificaciones exige configurar remitente/proveedor; su disponibilidad no se presume.

## 5. Mapa de módulos y navegación
Propuesta completa; se habilita gradualmente por fases y permisos.

| Perfil | Menús y submenús |
|---|---|
| Administrador | Inicio/Dashboard; Recetas y estándares (Mis recetas, Crear receta, Preparaciones base, Versiones); Producción (Nueva, Lotes, Historial); Insumos y compras (Catálogo, Unidades/presentaciones, Proveedores, Compras, Recepciones, Precios, Importar); Inventarios (Existencias, Kardex, Transferencias, Recepciones, Conteos, Mermas, Ajustes, Devoluciones, Alertas); Solicitudes (Bandeja, Aprobar, Preparar, Despachar); Gastos; Calidad (Incidencias, Acciones); Reportes; Configuración (Usuarios, Roles/permisos, Sucursales/almacenes, Políticas, Auditoría, Integraciones). |
| Encargado de depósito | Inicio operativo; Existencias/Kardex autorizado; Recibir compras; Solicitudes pendientes; Preparar/despachar; Transferencias y retornos; Conteos; Mermas/Incidencias; Producción si se le concede permiso; Perfil. Sin edición de fórmulas o costos por defecto. |
| Encargado de sucursal | Inicio de su ámbito; Recetas; Solicitar; Recepciones/conformidad; Stock si autorizado; Conteos/mermas si autorizado; Producción si autorizada; Incidencias; Perfil. |
| Colaborador | Inicio; Recetas (categorías, buscar, ficha y pasos); Solicitudes (Nueva, Mis solicitudes, seguimiento); Reportar incidencia; Perfil/sesión. Stock y conteos solo con concesión individual. |

Escritorio administrativo con barra lateral. Móvil colaborador con Inicio, Recetas, Solicitudes y Más; incidencias y perfil accesibles en Más. Selector de sucursal visible solo cuando hay más de una asignada. Opciones de fases no entregadas no simulan funcionalidad disponible.

Rutas propuestas: /admin/inicio, /admin/recetas, /admin/recetas/nueva, /admin/produccion, /admin/insumos, /admin/compras, /admin/inventarios, /admin/solicitudes, /admin/gastos, /admin/calidad, /admin/reportes, /admin/configuracion; /operacion/inicio, /operacion/recetas, /operacion/solicitudes, /operacion/recepciones y /operacion/incidencias según permiso.

## 6. Diagrama de módulos y dependencias
Las flechas representan dependencias de contratos, no orden de ejecución de pantallas. Flecha A→B significa “A utiliza un contrato público de B”; no acceso libre a sus tablas ni detalles internos.

~~~mermaid
flowchart TD
  CAT["Catálogos: insumos y ubicaciones"]
  REC["Recetas y costos"]
  INV["Inventario y valoración"]
  PRO["Producción"]
  COM["Compras y recepciones"]
  SOL["Solicitudes y distribución"]
  TRA["Transferencias"]
  CAL["Calidad"]
  REC --> CAT
  REC --> INV
  INV --> CAT
  PRO --> REC
  PRO --> INV
  COM --> INV
  COM --> CAT
  SOL --> CAT
  TRA --> SOL
  TRA --> INV
  CAL --> REC
  CAL --> PRO
~~~

Usuarios/permisos, archivos, auditoría y configuración son capacidades compartidas. Reportes consulta modelos de lectura autorizados de cada dominio; los módulos operativos no dependen de reportes. Gastos usa proveedores/ubicaciones y se vincula a compras solo para evitar doble desembolso. Transferencias puede originarse en solicitud o en autorización directa; no exige una solicitud ficticia.

Recetas/costos consulta un contrato de costos de referencia de Inventario/valoración; Inventario no consulta Recetas. Producción coordina ambos.

El motor de inventario recibe comandos de compra, producción y transferencias sin importar sus implementaciones. Cuando una operación toca más de un dominio, un caso de uso y una función SQL coordinan su transacción con contrato definido. No se crean dependencias circulares.

## 7. Modelo conceptual de base de datos
Propuesta normalizada. No se han generado ni ejecutado migraciones.

### 7.1 Entidades por dominio
| Dominio | Entidades propuestas | Relación/invariante principal |
|---|---|---|
| Identidad | auth.users; profiles; roles; permissions; user_roles; role_permissions; user_permission_overrides; user_location_access | Perfil 1:1 con Auth; permisos N:M; overrides y ámbitos explícitos. |
| Ubicaciones | branches; warehouses; warehouse_types | Sucursal 1:N almacenes; depósito independiente permitido. |
| Catálogos | item_categories; items; units; unit_conversions; purchase_presentations; item_specific_conversions; item_location_policies | Artículo con unidad base; mínimos y lote obligatorio por ubicación/producto. |
| Proveedores/precios | suppliers; supplier_items; item_price_history | Precio con presentación, origen y vigencia. |
| Recetas | recipe_categories; recipes; recipe_versions; recipe_location_applicability; recipe_components; recipe_steps; recipe_allergens; recipe_utensils; recipe_cost_snapshots | Identidad de receta separada de versión; componentes apuntan a insumo comprado o versión de subreceta. |
| Archivos | files; recipe_version_files; recipe_step_files; purchase_files; incident_files | Metadata común; vínculos específicos con FK, objetos privados. |
| Compras | purchases; purchase_lines; purchase_additional_costs; purchase_receipts; purchase_receipt_lines; purchase_returns; purchase_return_lines | Recibir parcial no modifica cantidad pedida; registrar factor/costo de la recepción. |
| Producción | production_orders; production_inputs; production_outputs; inventory_lots; production_variances | Cada lote producido refiere a una versión y valores reales; insumos seleccionados de lotes cuando aplica. |
| Inventario | inventory_operations; inventory_movements; inventory_cost_entries; stock_balances; stock_reservations; inventory_opening_documents; inventory_opening_lines | Operación 1:N movimientos; saldo materializado y reconstruible; reserva no es salida. |
| Solicitudes | supply_requests; supply_request_lines; request_status_history; request_approvals | Cantidad pedida/aprobada/preparada separadas. |
| Transferencias | transfers; transfer_lines; transfer_dispatches; dispatch_lines; transfer_receipts; transfer_receipt_lines; transfer_discrepancies | Una transferencia admite varios despachos/recepciones; origen, tránsito y destino trazables. |
| Conteos | count_policies; count_policy_scope; count_schedule_overrides; count_tasks; physical_counts; physical_count_lines; count_adjustment_approvals | Tarea programada y ejecución separadas; corte de stock y revisión conservados. |
| Mermas/ajustes | waste_records; waste_lines; stock_adjustments; stock_adjustment_lines | Documento fuente enlazado a operación de inventario, sin duplicar saldo. |
| Gastos | expense_categories; expenses; expense_allocations; expense_files | Compra de inventario no se duplica como gasto operativo. |
| Calidad | incidents; incident_actions; incident_status_history; incident_files | Incidencia vincula receta/version/lote/artículo y ubicación. |
| Soporte | settings; audit_logs; idempotency_records; import_jobs; import_rows; notification_events | Configuración versionada, auditoría, importación y reintentos. |
| Integración futura | external_connections; external_item_mappings; external_events; sales_imports; theoretical_consumption | Clave externa única, consumo teórico separado del Kardex real. |

Los nombres son propuestos; la división en tablas se cerrará en el diseño lógico de F1. Políticas de valoración, reservas, lotes y reglas de compra pueden cambiar algunas relaciones antes de implementar.

### 7.2 Relaciones principales
~~~mermaid
erDiagram
  PROFILES ||--o{ USER_ROLES : recibe
  ROLES ||--o{ USER_ROLES : asigna
  ROLES ||--o{ ROLE_PERMISSIONS : agrupa
  PERMISSIONS ||--o{ ROLE_PERMISSIONS : habilita
  PROFILES ||--o{ USER_LOCATION_ACCESS : tiene
  WAREHOUSES ||--o{ USER_LOCATION_ACCESS : delimita
  BRANCHES o|--o{ WAREHOUSES : contiene
~~~

~~~mermaid
erDiagram
  RECIPES ||--o{ RECIPE_VERSIONS : versiona
  RECIPE_VERSIONS ||--o{ RECIPE_COMPONENTS : contiene
  ITEMS o|--o{ RECIPE_COMPONENTS : ingrediente
  RECIPE_VERSIONS o|--o{ RECIPE_COMPONENTS : subreceta
  RECIPE_VERSIONS ||--o{ PRODUCTION_ORDERS : usada
  PRODUCTION_ORDERS ||--o{ PRODUCTION_OUTPUTS : genera
  ITEMS ||--o{ PRODUCTION_OUTPUTS : elaborado
  INVENTORY_LOTS ||--o{ PRODUCTION_OUTPUTS : identifica
~~~

Cada componente tiene exactamente una referencia: item comprado o versión de subreceta; CHECK de exclusividad y FK. La receta de preparación produce un artículo inventariable. La relación receta→artículo de salida se conserva en la versión. No convertir la preparación en un ingrediente comprado sin origen.

~~~mermaid
erDiagram
  INVENTORY_OPERATIONS ||--|{ INVENTORY_MOVEMENTS : registra
  ITEMS ||--o{ INVENTORY_MOVEMENTS : afecta
  WAREHOUSES ||--o{ INVENTORY_MOVEMENTS : localiza
  INVENTORY_LOTS o|--o{ INVENTORY_MOVEMENTS : identifica
  ITEMS ||--o{ STOCK_BALANCES : resume
  WAREHOUSES ||--o{ STOCK_BALANCES : guarda
  INVENTORY_MOVEMENTS ||--o{ INVENTORY_COST_ENTRIES : valora
  TRANSFERS ||--o{ TRANSFER_RECEIPTS : recibe
  TRANSFER_RECEIPTS ||--|{ TRANSFER_RECEIPT_LINES : detalla
  INVENTORY_OPERATIONS ||--o| TRANSFER_RECEIPTS : contabiliza
~~~

Inventario_lots también identifica lotes comprados cuando se requieren. La vinculación entre documentos y operación se hace con FK específico en el documento y restricciones; no confiar en un texto de “tipo/id” sin integridad referencial.

~~~mermaid
erDiagram
  SUPPLIERS ||--o{ PURCHASES : suministra
  PURCHASES ||--|{ PURCHASE_LINES : detalla
  PURCHASES ||--o{ PURCHASE_RECEIPTS : recibe
  PURCHASE_RECEIPTS ||--|{ PURCHASE_RECEIPT_LINES : contiene
  PURCHASE_LINES ||--o{ PURCHASE_RECEIPT_LINES : cumple
  ITEMS ||--o{ PURCHASE_LINES : identifica
  INVENTORY_OPERATIONS ||--o| PURCHASE_RECEIPTS : contabiliza
  SUPPLY_REQUESTS ||--|{ SUPPLY_REQUEST_LINES : solicita
  SUPPLY_REQUESTS o|--o{ TRANSFERS : origina
  TRANSFERS ||--|{ TRANSFER_LINES : detalla
  TRANSFER_LINES ||--o{ TRANSFER_RECEIPT_LINES : cumple
~~~

~~~mermaid
erDiagram
  COUNT_POLICIES ||--o{ COUNT_TASKS : programa
  COUNT_TASKS o|--o{ PHYSICAL_COUNTS : ejecuta
  PHYSICAL_COUNTS ||--|{ PHYSICAL_COUNT_LINES : mide
  PHYSICAL_COUNTS ||--o{ COUNT_ADJUSTMENT_APPROVALS : revisa
  PHYSICAL_COUNTS o|--o{ STOCK_ADJUSTMENTS : origina
  INVENTORY_OPERATIONS ||--o| STOCK_ADJUSTMENTS : contabiliza
  WAREHOUSES ||--o{ PHYSICAL_COUNTS : delimita
  RECIPE_VERSIONS o|--o{ INCIDENTS : afecta
  INVENTORY_LOTS o|--o{ INCIDENTS : afecta
  INCIDENTS ||--o{ INCIDENT_ACTIONS : corrige
~~~

Los diagramas muestran relaciones principales, no todas las FK del modelo lógico. Una recepción confirmada tiene una operación; una recepción aún en borrador no requiere movimientos. Las aprobaciones conservan decisiones de rechazo además de aprobación. La línea recibida identifica la línea comprada/transferida y la cantidad acumulada no puede superar lo autorizado sin un flujo de excepción aprobado. Conteos extraordinarios pueden carecer de tarea programada.

### 7.3 Tipos y restricciones
Recomendaciones:
- UUID estables; PK/FK; UNIQUE en códigos y numeración por ámbito; índices de almacén/artículo/fecha, estado y campos usados por RLS.
- TIMESTAMPTZ almacenado con instante y presentación en America/La_Paz; DATE para vencimiento cuando solo se conoce el día.
- Cantidades NUMERIC(20,6), costos unitarios NUMERIC(24,10), importes NUMERIC(24,6), factores NUMERIC(24,12). Precisiones finales se validan con valores reales.
- Rechazar NaN/infinito y valores fuera de rango. Cantidades de documentos positivas; conteo observado admite cero. Movimientos pueden tener cantidad con signo según tipo; no permitir valores negativos ingresados como pedido/producción.
- Unidades discretas pueden requerir enteros; g/ml admiten fracciones según política.
- operation_id e Idempotency-Key únicos por ámbito; guardar hash de payload para rechazar reutilización con contenido diferente.
- lock_version para edición concurrente; confirmaciones bloquean saldos/filas en orden estable.
- Versiones publicadas, movimientos confirmados y costos históricos no se modifican desde CRUD genérico.
- Índices y unicidad coherentes para saldos con lote nulo; no permitir duplicar saldo “sin lote”.
- Índices por unidad/dimensión no sustituyen validación semántica de conversiones.
- Auditoría con actor/instante/request_id/diferencias/motivo; acceso restringido y sin borrar evidencias al desactivar usuarios.

Stock_balances es una proyección transaccional, no la fuente de verdad. Debe poder reconciliarse con movimientos y valoración. Catálogos se desactivan; no se borran referencias históricas.

## 8. Reglas críticas propuestas
### 8.1 Unidades, rendimientos y recetas
Definido:
- Convertir presentación de compra a unidad base compatible.
- No asumir que 1 ml equivale a 1 g; equivalencia exige factor específico validado.
- Prohibir ciclos directos/indirectos. Recomendar bloqueo de publicación incompleta con reglas explícitas de campos obligatorios. Comprobar ciclos en el grafo de identidades y versiones, dentro de la transacción de publicación; dos publicaciones simultáneas no pueden introducir un ciclo.
- Colaborador ve versión publicada vigente de su ámbito; costos y márgenes están ocultos por defecto. Una concesión explícita, si se autoriza, se verifica también en API, archivos y persistencia.
- Conservar versiones y costo de operaciones pasadas.

Recomendado, sujeto a aprobación:
- Componentes publicados fijan la versión de subreceta. Nueva formulación de la base obliga a revisar y republicar recetas afectadas bajo la propuesta X09/A15. Los lotes ya almacenados retienen su versión real; la política de compatibilidad de lotes con una nueva formulación también debe acordarse. Variación de precio puede recalcular estimación actual de la formulación fija sin alterar el historial.
- Un cambio estructural crea borrador nuevo. Duplicar crea una nueva identidad; archivar detiene uso nuevo, no elimina producción previa.
- Vigencia inequívoca por receta/presentación/sucursal. Publicación comprueba que no hay solapamientos incompatibles.
- Registrar salida base en g, ml o unidad; porciones con equivalencia explícita y versionada. Cucharadas o bolas de helado no son unidades universales.
- Modelar masa y waffle base como etapas distintas si se almacenan o controlan de forma diferente. No asumir que ambas etapas tienen mismo rendimiento.
- Merma estándar y merma real no se suman dos veces. Rendimiento útil registrado ya excluye la pérdida; no volver a aplicarle porcentaje.
- No exigir conservar masa input/output con suma de ml+g: son dimensiones incompatibles y proceso puede cambiar masa/volumen.
- Pérdida operativa posterior a fabricación es evento separado de merma del lote; no volver a consumir ingredientes por la misma pérdida.

### 8.2 Costos
Definido: costo estimado actual separado del histórico; ausencia de precio no significa costo cero; cantidades/precios validados; valoración histórica conservada.

Fórmulas propuestas a validar, no políticas ya aprobadas:
- Cantidad base comprada = cantidad de presentaciones × contenido base de presentación.
- Costo unitario de recepción = costo atribuible de lo recibido / cantidad base efectivamente recibida.
- Costo estándar del lote = suma de cantidad base × costo de referencia de cada ingrediente o componente + empaques/otros costos aprobados.
- Costo estándar por unidad útil = costo estándar del lote / rendimiento útil estándar positivo.
- Costo histórico de producción = suma de costos registrados de los consumos reales + otros costos de fabricación aprobados.
- Costo por unidad útil real = costo histórico del lote / salida útil real positiva.

Recomendación: promedio ponderado móvil por artículo y almacén para valorar inventario; costo del despacho se conserva en tránsito; al recibir, su valor se agrega al promedio del destino, sin revalorarlo al costo actual del origen. El costo estimado de recetas utilizaría un costo de referencia identificado por ubicación y fecha, derivado de esta política. Definir fallback cuando la ubicación no tenga precio/costo, sin inventarlo.

Si se aprueba promedio (con cantidad anterior no negativa y denominador positivo):
nuevo promedio = (valor anterior + valor de entrada) / (cantidad anterior + cantidad entrada).
Si cantidad y valor iniciales son cero, el primer costo es valor de entrada / cantidad de entrada; un saldo residual por redondeo se resuelve con la política A10. Las salidas usan el promedio del instante confirmado. Lote identifica trazabilidad/vencimiento; promedio por almacén y costo específico de lote son políticas diferentes. Si se elige costo específico o FIFO, cambian consumos y capas de valoración; no mezclarlos.

Descuentos, flete, impuestos recuperables/no recuperables, costos laborales/energía, distribución de adicionales entre líneas y moneda se deciden antes de implementar cálculo. No se imputa alquiler como ingrediente por defecto.

Producción sin salida útil: no dividir entre cero. Flujo de lote fallido con consumos/pérdidas reales y autorización; no fingir entrada de producto. Operaciones con valor desconocido se bloquean o se señalan según política acordada.

### 8.3 Historial y precisión
Recomendación pendiente:
- Moneda operativa BOB y visualización “Bs”.
- Calcular internamente con al menos seis decimales y costo unitario diez.
- Mostrar dinero a dos decimales sin usar el valor mostrado para cálculos.
- Redondeo al más cercano, empate alejándose de cero; coherencia entre SQL y cualquier biblioteca decimal.
- Ajustar residuo de reparto de costos con regla determinista y auditada; preservar la suma del documento.

Guardar factor de conversión, precio/costo unitario, política/versión, cantidad, total y receta aplicada en cada operación. Cambiar presentación/precio hoy no cambia una compra o lote anterior.

### 8.4 Movimientos y concurrencia
Definido:
- La receta teórica no mueve inventario.
- Guardar compra/solicitud/conteo en borrador no mueve inventario.
- Confirmar recepción incrementa solo lo recibido.
- Confirmar producción consume stock de materias primas/preparaciones usadas y da entrada a la salida real en una sola transacción.
- Traslado no es consumo/gasto; conteo no ajusta por sí solo; correcciones conservan evidencia.

Propuestas:
- Bloquear stock negativo; no consumir disponible reservado a otra operación si se habilitan reservas.
- Usar saldos iniciales por documento de apertura auditado con cantidades y valoración aprobadas. No cargar cantidad directamente en tabla de saldos.
- Fijar corte de conteo. Para F3, ventana breve por artículo/almacén con bloqueo de movimientos durante el conteo o conciliación explícita; escoger una política antes de implementar.
- Solicitud aprobada puede reservar según A06; reserva no reduce existencia física.
- No registrar operaciones retroactivas que alteren valoración cerrada sin procedimiento de recalculo/corrección aprobado.
- Idempotencia, documento fuente, movimientos, valoración, proyección de saldo y auditoría se guardan en la misma transacción de confirmación.
- No usar transacción entre Storage y SQL como si fuera posible: carga temporal, asociación confirmada y limpieza de archivos huérfanos.

### 8.5 Transferencias y recepción
Modelo recomendado:
1. Borrador/aprobación/preparación: sin movimientos físicos; reserva opcional.
2. Despacho: salida del origen y entrada a ubicación lógica “en tránsito” con costo transportado.
3. Recepción: salida de tránsito y entrada de cantidad recibida al destino, atómicas.
4. Parcial: conservar remanente pendiente en tránsito; no ingresarlo automáticamente al destino.
5. Diferencias: reclamar, recibir posteriormente, retornar o reconocer pérdida con permiso. Sobrerrecepción no crea mercancía sin origen.
6. Cierre: sin remanentes inexplicados; devolver/cancelar movimientos confirmados mediante operación compensatoria.

Estados propuestos de solicitud: borrador, pendiente, aprobado, en preparación, despachado, recibido, cerrado; rechazado y cancelado según transición. Una solicitud con múltiples despachos/recepciones muestra avance por línea; recepción parcial es estado de avance del cumplimiento, no “recibido” total.

La ubicación de tránsito es técnica y no añade una sucursal física. Permite explicar stock que ya salió del depósito pero aún no fue recibido.

### 8.6 Casos de consumo que requieren precisión
- Costear teóricamente un producto final suma la porción de subreceta y sus agregados. Consumir físicamente un lote ya elaborado descuenta ese lote; no vuelve a descontar la leche/harina que ya se consumió al fabricarlo.
- Si una preparación se produce en el mismo proceso, deben existir operaciones de fabricación vinculadas, con salida y consumo trazables. No expandir silenciosamente una subreceta a materias primas al confirmar cualquier producto.
- FEFO (prioridad de vencimiento en selección física) y FIFO/promedio (valoración económica) son decisiones distintas. Elegir FEFO no autoriza cambiar a FIFO el costo.
- Rendimiento real cero puede representar producción fallida con consumos reales: requiere un flujo explícito de pérdida y permiso. No se elimina la evidencia de lo ocurrido por no haber producto útil.
- Devoluciones/contramovimientos con stock consumido después no se resuelven borrando la compra original. Validar disponibilidad, fechas, costo y autorización de corrección.

### 8.7 Reportes y KPIs
Definido: datos reales, filtros y permisos; distinguir compra, traslado, consumo registrado, teórico, merma, gasto y costos estimado/histórico.

Propuesta inicial de diccionario:
| Indicador | Definición | Fuente/corte |
|---|---|---|
| Compras registradas | Importe neto de documentos confirmados por fecha del documento. | Compras; mostrar devoluciones y criterio definido. |
| Entradas por compras | Cantidad/valor de recepciones confirmadas, sin unidades heterogéneas sumadas. | Movimientos compra por fecha de recepción. |
| Gastos operativos | Importes de gastos confirmados, excluidas compras capitalizadas y traslados. | Gastos/periodo. |
| Valor de stock | Suma de valoración a fecha de corte por ubicación según política aprobada. | Movimientos/costos históricos; no stock pasado × precio actual. |
| Stock bajo | Artículos cuya cantidad disponible o física cae bajo mínimo, criterio identificado. | Saldos y mínimos. |
| Solicitudes pendientes | Cantidad por estado de solicitudes abiertas. | Solicitudes/historial. |
| Producción | Salida útil y costo histórico de lotes confirmados. | Producción/fecha de confirmación. |
| Merma | Cantidad por artículo/unidad y costo histórico de pérdidas, separando producción y operación. | Variaciones/mermas sin doble conteo. |
| Diferencias de conteo | Observado − teórico al corte; valor según política. | Líneas de conteo. |
| Cumplimiento de conteos | Conteos completados a plazo / tareas programadas exigibles × 100. | Tareas; decidir cancelados y ausencia de denominador. |
| Variación de precio | (Precio comparable actual − anterior) / anterior × 100. | Historial normalizado; anterior cero → no calculable. |
| Costo estimado de receta | Costo por unidad útil con versión/fuente/fecha. | Costeo estándar; no sustituye costo histórico. |

No sumar g con ml/unidades en una tarjeta global. Si denominador es cero, mostrar “no calculable/sin datos”. Cancelados, devoluciones y corte deben documentarse. Comparación entre sucursales exige misma unidad, intervalo y métrica. PDF y Excel derivan de la misma consulta autorizada que dashboard.

## 9. Riesgos, decisiones y recursos pendientes
### 9.1 Decisiones de negocio
| ID | Decisión | Recomendación | Cuándo bloquea |
|---|---|---|---|
| A01 | Precedencia de permisos individuales y asignación inicial por cargo. | Denegación explícita prevalece; colaborador sin costos/stock por defecto; admin según permiso. | F1 |
| A02 | Unidad/rendimiento de masa, waffle base y helado; equivalencias de porciones. | Usar g/ml/unidad medible; equivalencia específica versionada. | F1 unidades/F2 recetas |
| A03 | Método de valoración y fuente para costo estimado por sucursal. | Promedio ponderado móvil por artículo/almacén; precios/históricos separados. | Motor Base/F2 |
| A04 | Stock negativo y valor desconocido. | Bloquear salidas insuficientes y confirmaciones sin valoración necesaria. | Motor Base/F2 |
| A05 | Aprobación de solicitudes. | Obligatoria inicialmente; permitir reglas posteriores explicitadas. | F3 |
| A06 | Reserva, momento del descuento y remanentes en tránsito. | Descontar origen al despacho, ingreso al destino al recibir; tránsito y parciales; reservas opcionales. | F3; esquema lógico en F1 |
| A07 | Responsables, frecuencia, hora/plazo, corte y aprobación de diferencias. | Calendario configurable; todos los ajustes aprobados inicialmente, sin umbral inventado. | F3 |
| A08 | Artículos que exigen lote/vencimiento y uso de vencidos. | Configurable por producto; habilitar desde producción y recepciones cuando aplique. | F2/F3; avanzado F5 |
| A09 | PWA offline. | Instalable con escrituras críticas en línea; offline de lectura posterior. | F1 base/F2 |
| A10 | Moneda, redondeo, descuentos, adicionales, tratamiento de impuestos y costos indirectos. | BOB; seis decimales internos, diez unitarios, dos visibles; política de costos directos explícita. | F1 esquema/F2/F3 |
| A11 | Respaldos, retención y objetivos de recuperación. | Cubrir PostgreSQL y objetos de Storage, restauración independiente ensayada. | F1/uso real |
| A12 | Datos iniciales e importación: archivos, duplicados y saldos/valor de apertura. | Ensayo y previsualización; confirmar por lote; datos ejemplo separados. | F1/F2/F3 |
| A13 | Correcciones retroactivas, devoluciones y lotes fallidos. | Flujo compensatorio auditado; no reescribir historia. | F2/F3 |
| A14 | POS, acceso, formato/API, códigos y fecha de integración. | Documentar adaptador tras obtener capacidades reales. | F6 |
| A15 | Vigencia, propagación de formulaciones y compatibilidad de lotes almacenados. | Una versión vigente por ámbito; precios recalculan estimación, formulaciones generan revisión/publicación explícita X09; lotes conservan fórmula real. | F2 |
| A16 | Canales de recordatorio, volúmenes y límites operativos. | Avisos en aplicación inicialmente; correo/push solo con canal y proveedor acordados. Definir concurrencia, latencia objetivo, tamaño/tipo de archivos y volumen de reportes. | F1 límites/seguridad; F3 avisos |
| A17 | País operativo, moneda y zona horaria empresarial. | BOB y America/La_Paz como propuesta; no inferir tratamiento tributario por el nombre de sucursales. | F1 formatos/esquema; F3 impuestos |

Puede aprobarse F1 sin resolver todas las políticas de F3–F6, pero A01/A02/A03/A04/A09/A10/A11/A12/A16/A17 y decisiones de infraestructura X deben estar resueltas en el alcance que afecte esquema y motor. Si se pospone A03, se puede autorizar explícitamente el subalcance H1.1–H1.3 (proyecto, Auth y catálogos), con precios de referencia documentados; el motor H1.4 y las operaciones que lo necesitan quedan explícitamente pendientes; no se declara F1 completa con motor funcional.

### 9.2 Riesgos y mitigaciones
| Riesgo | Efecto | Mitigación |
|---|---|---|
| Unidades imprecisas, bolas de helado sin medida o rendimientos no medidos. | Costo/inventario engañosos. | Validar medidas y fichas con Seasons antes de importar. |
| Producción adelantada sin stock/costo inicial. | Lotes sin consumo valorizado real. | Aprobar X03 y apertura auditada; pruebas con compra/saldo real de prueba. |
| HTTP múltiples o doble clic. | Descuentos/entradas duplicados. | RPC única, idempotencia, bloqueo y pruebas de fallo intermedio. |
| Costos visibles mediante endpoint, vista, archivo o RPC. | Fuga de información. | Separar datos sensibles y probar acceso directo a todas las superficies. |
| Conteos mientras se mueve stock. | Diferencias falsas. | Corte y ventana de control/conciliación aprobados. |
| Precio actual usado para recalcular pasado. | Reportes históricos incorrectos. | Snapshot, valoración histórica y política versionada. |
| Datos sin POS. | Confundir existencia registrada con consumo total diario. | Etiquetas de alcance y conciliación física. |
| Recordatorios dependen de proveedor/plan. | Conteos sin aviso. | Caso de uso portable, reintentos y configuración probada. |
| Dependencia de Supabase Auth/Storage. | Migración costosa. | Interfaces, SQL exportable, backup de archivos y procedimientos de migración. |
| Backup solo SQL. | Fotos/comprobantes perdidos. | Respaldo separado de objetos y prueba de reconstrucción de vínculos. |
| Reportes grandes en función serverless. | Timeout/memoria. | Paginación, límites explícitos; diferir procesado asíncrono si el volumen lo exige. |
| Scope completo sin aprobar reglas. | Retrabajo y supuestos críticos. | Hitos aprobados; registrar ADR y decisiones A. |

### 9.3 Recursos de implementación
Necesarios cuando corresponda: repositorio GitHub autorizado, proyecto Supabase de desarrollo/pruebas separado, acceso de configuración a Auth/Storage, datos de catálogos y fichas reales, valoración de apertura, configuración de remitente y enlaces de recuperación, cuenta Vercel y dominio si se aprueba publicar. Credenciales únicamente por mecanismo seguro y variables de entorno; no pegarlas en documentos ni respuestas.

No se ha verificado acceso a esos servicios ni se supone que estén conectados. La planificación no habilita desplegar ni escribir en producción. No se dan plazos en horas sin validar volumen, datos y acceso.

## 10. Plan por fases e hitos verificables
| Fase/hito | Entrega | Evidencia de cierre y dependencias |
|---|---|---|
| F0 · H0 | Matriz, arquitectura, mapa, modelo conceptual, reglas y decisiones. | Aprobación expresa del plan y correcciones X/A. Este documento constituye la propuesta. |
| F1 · H1.1 | Proyecto, layout responsive, estructura modular, documentación, .env.example, CI y ambientes. | Lint, tipos, build; dependencias verificadas; rutas distintas admin/operación. |
| F1 · H1.2 | SQL base versionado, Auth, usuarios/roles/permisos, ubicaciones y RLS/Storage. | Migración reproducible; pruebas de permiso/revocación/desactivación/acceso ajeno. |
| F1 · H1.3 | Proveedores, insumos, unidades/presentaciones, mínimos y importación de catálogos. | Caso 900 ml, conversión inválida, duplicados y persistencia. |
| F1 · H1.4 | Infraestructura Base aprobada: movimientos/saldos, idempotencia, exactitud y apertura auditada; respaldo/restauración. | Concurrencia/rollback y restauración aislada; RF-033/034/070. No interfaz completa F3. |
| F2 · H2.1 | Mis recetas, editor, estándares completos, imágenes, borrador/publicación/versiones. | Usuario móvil consulta solo vigente; edición conserva historia. |
| F2 · H2.2 | Recetas multinivel y costos. | Waffle con masa/helado sin ciclos ni doble costo; precio ausente y rendimiento cero. |
| F2 · H2.3 | Producción real y vista móvil. | Consumo+entrada atómicos; lote real y costo histórico; fallo/reintento no altera saldo. |
| F3 · H3.1 | Compras/recepciones, devoluciones, existencias y Kardex. | Compra borrador sin saldo; recepción parcial exacta; apertura real validada. |
| F3 · H3.2 | Solicitudes/aprobación/despacho/transferencias/recepciones. | Parcial, faltante, sobrante, retorno y stock en tránsito reconciliados. |
| F3 · H3.3 | Políticas/calendario/conteos, revisión/ajustes, mermas y alertas. | Murillo cada 2 días y Mega Mall otra frecuencia; sin ajuste automático; recordatorio idempotente. |
| F4 · H4.1 | Diccionario KPI, dashboard, filtros y gastos mínimos X05. | Cifras reconciliadas con documentos y movimientos; ausencia de datos explícita. |
| F4 · H4.2 | Excel/PDF, comparación por sucursal y reportes operativos. | Archivos descargables revisados; mismos filtros/cifras/permisos. |
| F5 · H5.1 | Gastos completos, incidencias/acciones y reportes de calidad. | Incidencia móvil con fotos y cierre; compra no duplica gasto. |
| F5 · H5.2 | Vencimientos/alertas avanzadas, KPIs y mejoras UX. | Casos vencimiento y permisos; integración sin regresión. |
| F6 · H6.1 | API POS, mapeo e importación/eventos externos. | Venta/anulación/reintento probados en ambiente seguro. |
| F6 · H6.2 | Consumo teórico, conciliación y BI avanzado. | Diferencia teórico/real explicable y trazabilidad hasta fuente externa. |

En cada fase: objetivo y archivos previstos; implementar únicamente alcance aprobado; pruebas y corrección; documentación; reporte de RF cubiertos, pendientes y limitaciones; autorización expresa para avanzar.

### Estrategia de pruebas
- Unitarias Vitest: unidades, redondeo, costeo, grafo de subrecetas, rendimientos, estados y permisos.
- Componentes React Testing Library: formularios críticos, estados, accesibilidad y ausencia de costos en vista colaborador.
- Integración en PostgreSQL/Supabase aislado: RLS, grants/RPC, FK/CHECK, idempotencia, stock simultáneo, parciales, rollback y valoración.
- Playwright: journeys por cargo y viewport, sesión/recuperación, recetas/publicación, producción/recepción/conteos y exportación según fase.
- Fixtures explícitamente de prueba; cantidades cero/negativas, precio faltante, versión usada, archivo inválido, fallo de conexión y edición concurrente.
- CI: lint, typecheck, unitarias/componentes, integración y build; E2E del alcance como check requerido. No sustituir integración real por mocks de saldo.
- Reporte distingue ejecutado/aprobado, fallo, omitido y bloqueado. No declarar pruebas pasadas sin ejecución.

## 11. Criterios de aceptación de Fase 1
| ID | Criterio verificable | Requisitos vinculados |
|---|---|---|
| AC1-01 | Ejecutar desde README en ambiente limpio; versiones compatibles y lockfile; TS estricto. | RNF-001/019 |
| AC1-02 | Migraciones reconstruyen esquema F1 y seeds separados de producción. | RNF-012/019 |
| AC1-03 | Login/logout/recuperación reales; sesión inválida o usuario desactivado no opera. | RF-001/002 |
| AC1-04 | Cuatro roles iniciales, permisos configurables y múltiples ubicaciones por usuario. | RF-003/004 |
| AC1-05 | Conceder/revocar ver stock/ver costos altera permiso efectivo en API y persistencia; no solo UI. El permiso completo de vista receta se verifica en F2. | RF-005; RNF-003/004 |
| AC1-06 | Usuario de Mega Mall no consulta/modifica recursos de Murillo cambiando UUID; se prueba acceso directo y RPC aplicable. | RF-004/005 |
| AC1-07 | Ubicaciones iniciales creadas; agregar almacén sin cambiar esquema; depósito válido sin punto de venta. | RF-007 |
| AC1-08 | Insumos/proveedores se guardan, consultan y desactivan con auditoría; referencias históricas se protegen. | RF-006/008/011 |
| AC1-09 | Leche en presentación 900 ml: dos envases → 1.800 ml; kg→g permitido; g→ml genérico rechazado. | RF-009/010 |
| AC1-10 | Cambiar una presentación no invalida historia; precios registran unidad, fecha y fuente, sin costo inventado. | RF-012 |
| AC1-11 | Importación de catálogos previsualiza errores y duplicados antes de confirmar; reintento no duplica. | RF-063 |
| AC1-12 | UI responsive con teclado, errores, vacíos y carga; PWA base acorde al alcance aprobado. | RF-069; RNF-009/010/020 |
| AC1-13 | Ninguna clave privilegiada en navegador; tablas/archivos/vistas/funciones protegidos por grants y controles adecuados. | RNF-004/005/011 |
| AC1-14 | Si X03 aprobado: apertura auditada y motor Base reconstruible, operación atómica y reintento idempotente; dos salidas simultáneas no generan saldo inválido. | RF-029/031/033/034 |
| AC1-15 | Cálculos decimales y política aprobada concordantes entre SQL y casos de prueba. | RNF-006 |
| AC1-16 | Respaldo de datos/archivos y recuperación probada en entorno separado; objetivos registrados. | RF-070; RNF-014 |
| AC1-17 | Lint, tipos, pruebas pertinentes de F1 y build ejecutados; errores corregidos; CI reproduce los checks. | RNF-018 |
| AC1-18 | README, ARCHITECTURE, DATABASE, API, BUSINESS_RULES, DEPLOYMENT, CHANGELOG y .env.example actualizados; RF pendientes identificados. | RNF-019 |

F1 no implica recetas ni solicitudes funcionales todavía. Su aceptación cubre fundamentos y Base únicamente si X03 se aprueba.

### 11.1 Casos mínimos de aceptación del motor compartido, si se aprueba X03
| ID | Escenario de prueba aislado | Resultado esperado |
|---|---|---|
| AT-01 | Apertura autorizada 10 unidades; dos salidas simultáneas de 7. | Con bloqueo de negativos aprobado, solo una salida confirma; saldo 3, sin movimientos parciales de la otra. |
| AT-02 | Una misma confirmación reenviada con la misma clave/payload. | Mismo resultado y una sola operación; misma clave con payload diferente se rechaza. |
| AT-03 | Fallo después de insertar consumo y antes de insertar salida elaborada. | Rollback total; no cambia el Kardex/saldo ni queda confirmación exitosa. |
| AT-04 | Presentación 900 ml, compra de dos envases. | Conversión exacta 1.800 ml; factor conservado en el documento. |
| AT-05 | Usuario sin costos consulta endpoint/tabla/vista/RPC/archivo aplicable. | No recibe importes unitarios/totales o indicadores que revelen costos. |
| AT-06 | Restauración aislada de SQL y objetos. | Filas, archivos, vínculos, políticas y controles de acceso verificados; duración y pérdida observadas registradas. |

Estos casos son especificaciones de prueba, no pruebas ejecutadas. F0 se valida por revisión de cobertura documental y coherencia de referencias. No corresponde ejecutar lint/build de una aplicación inexistente.

## 12. Documentación y aprobación solicitada
Documentación prevista al programar:
- README.md: instalación, scripts, datos de prueba.
- ARCHITECTURE.md y docs/adr/: capas, dependencias, RPC, seguridad, PDF y PWA.
- DATABASE.md: modelo lógico, restricciones, políticas y migraciones.
- API.md: DTO, endpoints, errores, scopes, idempotencia.
- BUSINESS_RULES.md: decisiones A, estados, valoración, corte y excepciones.
- DEPLOYMENT.md: ambientes, variables, Auth/Storage, backups y recuperación.
- CHANGELOG.md: entregas y cambios verificables.
- docs/REQUIREMENTS.md: matriz RF/RNF y evidencias.
- docs/KPI_DICTIONARY.md: definiciones y fuentes al entrar F4.

Para iniciar F1 se requiere:
1. Aprobar o corregir arquitectura, navegación, modelo conceptual y alcance X01–X09.
2. Resolver decisiones que afectan F1/motor: permisos, unidades iniciales, valoración, stock negativo, precisión/redondeo, PWA y recuperación.
3. Confirmar que el alcance siguiente es F1, sin publicación ni cambios de producción.
4. Registrar decisiones posteriores como pendientes con su fase bloqueada.

Esta aprobación se solicita porque P2.8 y P16 exigen esperar confirmación antes de comenzar, y P14.12 exige autorización por etapa. No se ha escrito código de aplicación, instalado dependencias, creado infraestructura remota, ejecutado migraciones ni publicado.

## 13. Referencias técnicas para verificar en F1
Los enlaces siguientes estaban citados en F v1.0. En esta revisión no se ha hecho una nueva consulta web ni validado versiones de dependencias. Deben verificarse en documentación oficial antes de instalar. No definen políticas comerciales de Seasons.
- Next.js — Authentication: https://nextjs.org/docs/app/guides/authentication
- Next.js — Data Security: https://nextjs.org/docs/app/guides/data-security
- Next.js — Route Handlers: https://nextjs.org/docs/app/getting-started/route-handlers
- Supabase — Database Functions: https://supabase.com/docs/guides/database/functions
- Supabase — Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
- PostgreSQL — Numeric Types: https://www.postgresql.org/docs/current/datatype-numeric.html


## 14. Registro de revisión v1.1 y cobertura
Cambios frente a F v1.0:
- Se separa el pedido P de las instrucciones contenidas en documentos de referencia D/F.
- Se añade estado de definición por RF y se conservan RF-001–RF-070, RNF-001–RNF-020 y AC1-01–AC1-18.
- Se registra X09/A15 para cambios de formulación y versiones de subrecetas; costo actual y costo histórico siguen separados.
- Se corrige la visibilidad de costos: ocultos por defecto para colaborador, con permiso explícito configurable según el pedido.
- Se completa la dependencia Recetas/costos → Inventario/valoración, los diagramas de compras, conteos y calidad, y los documentos de apertura.
- Se distinguen consumo físico de una preparación, costo teórico y selección FEFO frente a valoración.
- Se incorporan RNF-021/022 y A16/17 para dominio propio, controles de endpoints, canales/límites y contexto empresarial.
- Se retira la afirmación de consulta web vigente y se explicita el alcance real de las verificaciones.

Cobertura del documento maestro:
| Sección D | Cobertura en esta propuesta |
|---|---|
| D1 Objetivo y criterios | RF-006/063/064/069; RNF-002/008/015 |
| D2 Usuarios | RF-001–007/021; RNF-003–005 |
| D3 Navegación | Sección 5; RF-068 |
| D4.1 Recetas | RF-014–025; X09/A15 |
| D4.2 Composición/producción | RF-022–029; X01/X03; sección 8 |
| D4.3 Compras/gastos | RF-008–012/035–038/051 |
| D4.4 Inventario | RF-030–044/049/050/054 |
| D4.5 Conteos | RF-045–048/056; A07/A16 |
| D4.6 Visibilidad | RF-003–005; RNF-003/004 |
| D4.7 Incidencias | RF-052/053/060 |
| D5 Pantallas mínimas | Secciones 5 y 10; RF-014–029/039/045/055 |
| D6 Dashboard/reportes | RF-055–062/066; sección 8.7 |
| D7 Datos y reglas | Secciones 7/8; RF-031–034/063/070; RNF-006–008/012/014 |
| D8 Arquitectura | Sección 4; RF-064/069; RNF-001/002/015/016/021 |
| D9 Prioridades | Sección 10; X01/X02/X05; RF-065–067 |
| D10 Decisiones | Sección 9; A01–A17 |
| D11 Aceptación V1 | Secciones 10/11 y RF-014/019–024/037/043/045/005/021/030/062 |

Cobertura del pedido P: P1–3 se reflejan en alcance/fuentes, matriz y aprobación; P4–6 en arquitectura, capas y documentación; P7 en RNF-009/010/020; P8–9 en matriz, modelo y reglas; P10–11 en seguridad/estrategia de pruebas; P12 en sección 12; P13–15 en hitos y aceptación; P16 en las secciones 1–11.

No existe código de aplicación en esta entrega. Las recomendaciones y fases están pendientes de aprobación; ninguna fila equivale a funcionalidad terminada.
