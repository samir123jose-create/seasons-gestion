import js from '@eslint/js';
import { defineConfig, globalIgnores } from 'eslint/config';
import ts from 'typescript-eslint';
import next from '@next/eslint-plugin-next';
import hooks from 'eslint-plugin-react-hooks';
export default defineConfig([
  globalIgnores([
    '.next/**',
    'coverage/**',
    'playwright-report/**',
    'test-results/**',
    'next-env.d.ts',
    'supabase/.temp/**',
  ]),
  {
    files: ['**/*.ts', '**/*.tsx'],
    extends: [js.configs.recommended, ...ts.configs.recommended],
    plugins: { '@next/next': next, 'react-hooks': hooks },
    rules: {
      ...next.configs.recommended.rules,
      ...next.configs['core-web-vitals'].rules,
      ...hooks.configs.recommended.rules,
    },
  },
  {
    files: ['**/*.mjs', 'public/*.js'],
    languageOptions: {
      globals: {
        console: 'readonly',
        process: 'readonly',
        Buffer: 'readonly',
        self: 'readonly',
        caches: 'readonly',
        fetch: 'readonly',
        location: 'readonly',
      },
    },
  },
]);
