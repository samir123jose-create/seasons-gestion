import { createClient } from '@supabase/supabase-js';
const {
  NEXT_PUBLIC_SUPABASE_URL: url,
  SUPABASE_SERVICE_ROLE_KEY: key,
  BOOTSTRAP_ADMIN_USER_ID: id,
} = process.env;
if (!url || !key || !id)
  throw new Error('Configura URL, service_role (solo servidor) y BOOTSTRAP_ADMIN_USER_ID.');
const client = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
const { error } = await client.rpc('bootstrap_admin', { p_user: id });
if (error) {
  console.error('No se aprovisionó administrador', { code: error.code });
  process.exit(1);
}
console.log(
  'Administrador inicial activado. Revisa sus ubicaciones y mantén service_role fuera del navegador.',
);
