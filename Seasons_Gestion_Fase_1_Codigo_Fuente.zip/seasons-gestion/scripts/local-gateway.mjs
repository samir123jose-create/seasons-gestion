// PRUEBAS: reenvía a GoTrue y PostgREST reales. No simula sus respuestas.
import http from 'node:http';
const server = http.createServer((req, res) => {
  const auth = req.url.startsWith('/auth/v1/');
  const rest = req.url.startsWith('/rest/v1/');
  if (!auth && !rest) {
    res.writeHead(404);
    res.end();
    return;
  }
  const upstream = http.request(
    {
      hostname: '127.0.0.1',
      port: auth ? 54322 : 54323,
      path: req.url.replace(auth ? '/auth/v1' : '/rest/v1', ''),
      method: req.method,
      headers: req.headers,
    },
    (result) => {
      res.writeHead(result.statusCode || 502, result.headers);
      result.pipe(res);
    },
  );
  upstream.on('error', () => {
    res.writeHead(502);
    res.end('Local test service unavailable');
  });
  req.pipe(upstream);
});
server.listen(54321, '127.0.0.1', () =>
  console.log('Gateway local de pruebas en http://127.0.0.1:54321'),
);
