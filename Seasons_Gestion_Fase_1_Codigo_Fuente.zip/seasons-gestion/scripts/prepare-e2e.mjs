import { createHmac } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import pg from 'pg';
import fs from 'node:fs/promises';
const url = 'http://127.0.0.1:54321';
const secret = 'seasons-local-tests-only-jwt-secret-not-for-production';
function token(role) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(
    JSON.stringify({
      role,
      iss: 'supabase',
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 86400,
    }),
  ).toString('base64url');
  return `${header}.${payload}.${createHmac('sha256', secret).update(`${header}.${payload}`).digest('base64url')}`;
}
const anon = token('anon');
const service = token('service_role');
const admin = createClient(url, service, {
  auth: { persistSession: false, autoRefreshToken: false },
});
const db = new pg.Client({
  connectionString: 'postgresql://postgres:seasons-e2e-test@127.0.0.1:55433/seasons_e2e',
});
await db.connect();
if ((await db.query('select current_database() name')).rows[0].name !== 'seasons_e2e')
  throw new Error('Base de prueba requerida');
const health = await fetch(`${url}/auth/v1/health`);
if (!health.ok) throw new Error('GoTrue de prueba todavía no está disponible.');
await db.query(
  `create or replace function auth.uid() returns uuid language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb->>'sub')::uuid $$;grant execute on function auth.uid() to authenticated,anon,service_role;`,
);
const exists = (await db.query("select to_regclass('public.profiles') name")).rows[0].name;
if (!exists)
  for (const file of (await fs.readdir('supabase/migrations'))
    .filter((x) => x.endsWith('.sql'))
    .sort())
    await db.query(await fs.readFile(`supabase/migrations/${file}`, 'utf8'));
let data = (await admin.auth.admin.listUsers()).data?.users || [];
for (const [email, full_name] of [
  ['admin@seasons.test.invalid', 'Admin E2E'],
  ['worker@seasons.test.invalid', 'Colaborador E2E'],
]) {
  if (!data.some((x) => x.email === email)) {
    const r = await admin.auth.admin.createUser({
      email,
      password: 'Seasons-test-password-2026!',
      email_confirm: true,
      user_metadata: { full_name },
    });
    if (r.error) throw new Error(`No se creó cuenta de prueba: ${r.error.code}`);
  }
}
data = (await admin.auth.admin.listUsers()).data.users;
const first = data.find((x) => x.email === 'admin@seasons.test.invalid');
const worker = data.find((x) => x.email === 'worker@seasons.test.invalid');
const already = (await db.query('select active from public.profiles where id=$1', [first.id]))
  .rows[0]?.active;
if (!already) {
  await db.query("select set_config('request.jwt.claim.role','service_role',false)");
  await db.query('select public.bootstrap_admin($1)', [first.id]);
}
await db.query('update public.profiles set active=true where id=$1', [worker.id]);
await db.query(
  "insert into public.user_roles select $1,id from public.roles where code='colaborador' on conflict do nothing",
  [worker.id],
);
await db.query(
  "insert into public.user_warehouse_access select $1,id from public.warehouses where code='MEGA-MALL' on conflict do nothing",
  [worker.id],
);
await db.query(
  "insert into public.user_permission_overrides values($1,'catalogos.read','allow'),($1,'inventario.read','allow') on conflict do nothing",
  [worker.id],
);
await db.query("select pg_notify('pgrst','reload schema')");
await db.end();
await fs.writeFile(
  '.env.e2e.local',
  `NEXT_PUBLIC_SUPABASE_URL=${url}\nNEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=${anon}\nSUPABASE_SERVICE_ROLE_KEY=${service}\nAPP_URL=http://127.0.0.1:3000\nAPP_DATA_MODE=test\n`,
  { mode: 0o600 },
);
console.log(
  'Migraciones y cuentas de prueba preparadas. Configuración local en archivo ignorado; claves no mostradas.',
);
