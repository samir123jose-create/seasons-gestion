// Ensayo SQL exclusivamente contra el contenedor del harness E2E local.
import { spawnSync } from 'node:child_process';
const container = 'seasons-f1-e2e-db-1';
const source = 'seasons_e2e';
const destination = `seasons_restore_${Date.now()}`;
const cleanEnv = { ...process.env };
for (const k of [
  'DOCKER_HOST',
  'DOCKER_CONTEXT',
  'DOCKER_TLS',
  'DOCKER_TLS_VERIFY',
  'DOCKER_CERT_PATH',
])
  delete cleanEnv[k];
function run(args, input) {
  const r = spawnSync(
    'docker',
    ['--host=unix:///var/run/docker.sock', 'exec', ...(input ? ['-i'] : []), container, ...args],
    { env: cleanEnv, input, maxBuffer: 64 * 1024 * 1024 },
  );
  if (r.status !== 0)
    throw new Error(
      'Falló una operación del ensayo de recuperación local. Revisar servicio de prueba.',
    );
  return r.stdout;
}
function query(db, sql) {
  return run(['psql', '-U', 'postgres', '-d', db, '-At', '-v', 'ON_ERROR_STOP=1', '-c', sql])
    .toString()
    .trim();
}
const started = Date.now();
const dump = run(['pg_dump', '-U', 'postgres', '-Fc', source]);
query('postgres', `CREATE DATABASE ${destination}`);
try {
  run(['pg_restore', '--exit-on-error', '-U', 'postgres', '--dbname', destination], dump);
  const inventory = `select json_build_object('profiles',(select count(*) from public.profiles),'auth_users',(select count(*) from auth.users),'items',(select count(*) from public.items),'warehouses',(select count(*) from public.warehouses),'operations',(select count(*) from app_private.inventory_operations),'movements',(select count(*) from app_private.inventory_movements),'audit',(select count(*) from app_private.audit_logs),'auth_integrity',(select md5(string_agg(id::text||coalesce(encrypted_password,''),',' order by id)) from auth.users),'stock_integrity',(select md5(string_agg(warehouse_id::text||item_id::text||quantity::text||value::text,',' order by warehouse_id,item_id)) from app_private.stock_balances))::text`;
  if (query(source, inventory) !== query(destination, inventory))
    throw new Error('Restauración no coincide con datos/identidades/saldos.');
  // El subquery Auth requiere dueño: obtener solo UUID de prueba antes de cambiar rol.
  const worker = query(
    source,
    "select id from auth.users where email='worker@seasons.test.invalid'",
  );
  const rls = `begin;select set_config('request.jwt.claims','{"sub":"${worker}","role":"authenticated"}',true);set local role authenticated;select count(*) from public.warehouses;rollback;`;
  if (query(source, rls) !== query(destination, rls))
    throw new Error('RLS recuperada no coincide.');
  console.log(
    `Restauración SQL aislada verificada: datos, identidades, saldos, auditoría y RLS coinciden. Duración observada: ${((Date.now() - started) / 1000).toFixed(2)} s. No incluye objetos Storage.`,
  );
} finally {
  query('postgres', `DROP DATABASE ${destination}`);
}
