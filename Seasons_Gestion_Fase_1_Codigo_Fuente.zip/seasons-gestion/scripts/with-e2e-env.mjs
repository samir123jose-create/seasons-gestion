import { spawn } from 'node:child_process';
process.loadEnvFile('.env.e2e.local');
if (process.env.NEXT_PUBLIC_SUPABASE_URL !== 'http://127.0.0.1:54321')
  throw new Error('Este comando solo acepta el proveedor local de pruebas.');
const commands = {
  build: ['node_modules/next/dist/bin/next', 'build', '--webpack'],
  test: ['node_modules/@playwright/test/cli.js', 'test', ...process.argv.slice(3)],
  start: ['node_modules/next/dist/bin/next', 'start', '--port', '3000', '--hostname', '127.0.0.1'],
};
const args = commands[process.argv[2]];
if (!args) throw new Error('Usar build, test o start.');
const child = spawn(process.execPath, args, { stdio: 'inherit', env: process.env });
child.on('exit', (code) => process.exit(code ?? 1));
child.on('error', () => process.exit(1));
