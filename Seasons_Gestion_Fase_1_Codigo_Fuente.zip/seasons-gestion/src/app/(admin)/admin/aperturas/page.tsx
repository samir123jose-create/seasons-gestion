import { pageAccess } from '@/modules/usuarios/access';
import { lookupRows } from '@/modules/catalogos/repository';
import { OpeningForm } from '@/components/forms/operational-forms';
export default async function Openings() {
  const { db, access } = await pageAccess('inventario.opening');
  await pageAccess('costos.read');
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CONFIGURACIÓN INICIAL</div>
          <h1>Apertura de inventario</h1>
          <p>Registra existencias iniciales verificadas y su valoración histórica.</p>
        </div>
      </div>
      <div className="panel panel-pad">
        <OpeningForm items={await lookupRows(db, 'insumos')} warehouses={access.warehouses} />
      </div>
    </>
  );
}
