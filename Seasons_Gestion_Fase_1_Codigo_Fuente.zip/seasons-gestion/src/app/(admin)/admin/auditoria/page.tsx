import { pageAccess } from '@/modules/usuarios/access';
import { databaseError } from '@/lib/errors';
export default async function Audit() {
  const { db } = await pageAccess('usuarios.manage');
  const r = await db.rpc('audit_history');
  if (r.error) databaseError(r.error);
  const rows = r.data as {
    id: string;
    actor_id: string;
    action: string;
    entity: string;
    entity_id: string;
    created_at: string;
  }[];
  const actorIds = Array.from(new Set(rows.map((row) => row.actor_id).filter(Boolean)));
  const profiles = actorIds.length
    ? await db.from('profiles').select('id,full_name').in('id', actorIds)
    : { data: [], error: null };
  if (profiles.error) databaseError(profiles.error);
  const actorNames = new Map((profiles.data || []).map((p) => [p.id, p.full_name]));
  const actionNames: Record<string, string> = {
    create: 'Registro creado',
    update: 'Registro actualizado',
    'access.update': 'Accesos actualizados',
    'role.permissions': 'Permisos de rol actualizados',
    'role.create': 'Rol creado',
    'price.record': 'Precio registrado',
    'import.confirm': 'Importación confirmada',
    'inventory.confirm': 'Inventario confirmado',
    'minimum.set': 'Stock mínimo actualizado',
    bootstrap: 'Administrador inicial activado',
  };
  const entityNames: Record<string, string> = {
    usuarios: 'Equipo',
    roles: 'Roles',
    insumos: 'Insumos',
    proveedores: 'Proveedores',
    categorias: 'Categorías',
    sucursales: 'Sucursales',
    almacenes: 'Almacenes',
    presentaciones: 'Presentaciones',
    precios: 'Precios',
    importaciones: 'Importaciones',
    opening: 'Apertura de inventario',
  };
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">TRAZABILIDAD</div>
          <h1>Historial de acciones</h1>
          <p>
            Últimas 200 operaciones auditadas. Las correcciones conservan la evidencia anterior.
          </p>
        </div>
      </div>
      <section className="panel">
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Fecha (La Paz)</th>
                <th>Acción</th>
                <th>Módulo</th>
                <th>Responsable</th>
                <th>Referencia</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((x) => (
                <tr key={x.id}>
                  <td>
                    {new Date(x.created_at).toLocaleString('es-BO', { timeZone: 'America/La_Paz' })}
                  </td>
                  <td>{actionNames[x.action] || x.action}</td>
                  <td>{entityNames[x.entity] || x.entity}</td>
                  <td>{actorNames.get(x.actor_id) || x.actor_id}</td>
                  <td>{x.entity_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && (
            <div className="empty-state">
              <h3>Todavía no hay acciones registradas.</h3>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
