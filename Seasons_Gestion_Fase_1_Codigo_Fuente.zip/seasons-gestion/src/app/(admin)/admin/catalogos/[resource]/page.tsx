import { notFound, redirect } from 'next/navigation';
import { pageAccess } from '@/modules/usuarios/access';
import { resourceSchema, catalogConfig, type CatalogRow } from '@/modules/catalogos/config';
import { listCatalog, lookupRows } from '@/modules/catalogos/repository';
import { CatalogManager } from '@/components/forms/catalog-manager';
export default async function CatalogPage({ params }: { params: Promise<{ resource: string }> }) {
  const parsed = resourceSchema.safeParse((await params).resource);
  if (!parsed.success) notFound();
  const resource = parsed.data;
  const config = catalogConfig[resource];
  const { db, access } = await pageAccess();
  const canManage = access.permissions.includes(config.permission);
  if (!canManage && !access.permissions.includes('catalogos.read')) redirect('/sin-acceso');
  const lookups: Record<string, CatalogRow[]> = {};
  for (const name of new Set(config.fields.flatMap((f) => (f.lookup ? [f.lookup] : []))))
    lookups[name] = await lookupRows(db, name);
  if (resource === 'presentaciones' && !lookups.unidades)
    lookups.unidades = await lookupRows(db, 'unidades');
  return (
    <CatalogManager
      resource={resource}
      initial={await listCatalog(db, resource)}
      lookups={lookups}
      canManage={canManage}
    />
  );
}
