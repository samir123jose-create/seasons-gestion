import { pageAccess } from '@/modules/usuarios/access';
import { ImportManager } from '@/components/forms/operational-forms';
export default async function Imports() {
  await pageAccess('importaciones.manage');
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CATÁLOGOS</div>
          <h1>Importar desde Excel</h1>
          <p>Revisa cada fila antes de incorporar información al catálogo.</p>
        </div>
      </div>
      <ImportManager />
    </>
  );
}
