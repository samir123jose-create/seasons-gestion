import Link from 'next/link';
import { ArrowRight, Package, Truck, MapPin, Leaf, Users } from 'lucide-react';
import { pageAccess } from '@/modules/usuarios/access';
export default async function Home() {
  const { access } = await pageAccess();
  const cards = [
    {
      href: '/admin/catalogos/insumos',
      title: 'Insumos bien organizados',
      text: 'Mantén ingredientes, materiales y presentaciones en un catálogo común.',
      icon: Package,
      permission: 'insumos.manage',
      alternative: 'catalogos.read',
    },
    {
      href: '/admin/catalogos/proveedores',
      title: 'Proveedores a mano',
      text: 'Encuentra contactos y registra la información comercial de cada proveedor.',
      icon: Truck,
      permission: 'proveedores.manage',
      alternative: 'catalogos.read',
    },
    {
      href: '/admin/usuarios',
      title: 'Un equipo conectado',
      text: 'Asigna roles, accesos y ubicaciones para que cada persona tenga lo que necesita.',
      icon: Users,
      permission: 'usuarios.manage',
      alternative: '',
    },
  ].filter(
    (c) => access.permissions.includes(c.permission) || access.permissions.includes(c.alternative),
  );
  return (
    <>
      <section className="welcome">
        <div>
          <div className="eyebrow">TU ESPACIO SEASONS</div>
          <h1>
            Hola, {access.full_name.split(' ')[0]}.<br />
            Cada detalle cuenta.
          </h1>
          <p>
            Organiza la información que tu equipo necesita para trabajar con claridad, desde cada
            ubicación.
          </p>
          {cards[0] && (
            <Link className="button primary" href={cards[0].href}>
              Abrir catálogo <ArrowRight size={16} />
            </Link>
          )}
        </div>
        <Leaf className="welcome-symbol" strokeWidth={0.65} />
      </section>
      <div className="section-title">
        <h2>Empieza por lo esencial</h2>
        <span className="pill">Accesos de tu cuenta</span>
      </div>
      <div className="card-grid">
        {cards.map((c) => (
          <Link key={c.href} href={c.href} className="action-card">
            <div className="card-icon">
              <c.icon size={23} />
            </div>
            <h3>{c.title}</h3>
            <p>{c.text}</p>
            <div className="card-bottom">
              <span>Abrir sección</span>
              <ArrowRight size={15} />
            </div>
          </Link>
        ))}
      </div>
      {!cards.length && (
        <section className="panel panel-pad">
          <h3>Tu cuenta está lista.</h3>
          <p className="muted">
            El administrador puede habilitar los catálogos y las ubicaciones que necesitas. Las
            funciones operativas se incorporarán en las próximas entregas.
          </p>
        </section>
      )}
      <div className="info-grid">
        <section className="panel panel-pad">
          <h2>Tus ubicaciones</h2>
          <p className="small muted">Asignadas por el administrador.</p>
          <div className="location-list">
            {access.warehouses.map((w) => (
              <div className="location-item" key={w.id}>
                <div className="card-icon">
                  <MapPin size={20} />
                </div>
                <div>
                  <span>{w.name}</span>
                  <small>{w.code}</small>
                </div>
              </div>
            ))}
            {!access.warehouses.length && (
              <p className="muted small">Todavía no tienes ubicaciones asignadas.</p>
            )}
          </div>
        </section>
        <section className="panel panel-pad notice-card">
          <div className="eyebrow">UNA BASE COMPARTIDA</div>
          <h2>Datos claros, decisiones claras.</h2>
          <p>
            Registra la unidad base y la presentación de cada insumo antes de cargar precios o
            existencias iniciales.
          </p>
          <span className="small">Siente cada momento.</span>
        </section>
      </div>
    </>
  );
}
