import { pageAccess } from '@/modules/usuarios/access';
import { Shell } from '@/components/ui/shell';
export const dynamic = 'force-dynamic';
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { access } = await pageAccess();
  return (
    <Shell access={access} isTest={process.env.APP_DATA_MODE === 'test'}>
      {children}
    </Shell>
  );
}
