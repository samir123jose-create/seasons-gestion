export default function Loading() {
  return (
    <div role="status" aria-live="polite" className="panel panel-pad">
      <p className="muted">Cargando tu espacio de trabajo…</p>
    </div>
  );
}
