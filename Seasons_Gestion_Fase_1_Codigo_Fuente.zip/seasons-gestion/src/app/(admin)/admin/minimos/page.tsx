import { pageAccess } from '@/modules/usuarios/access';
import { lookupRows } from '@/modules/catalogos/repository';
import { MinimumForm } from '@/components/forms/operational-forms';
export default async function Minimums() {
  const { db, access } = await pageAccess('insumos.manage');
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CONFIGURACIÓN</div>
          <h1>Stock mínimo</h1>
          <p>Define una cantidad mínima por insumo y ubicación.</p>
        </div>
      </div>
      <div className="panel panel-pad">
        <MinimumForm items={await lookupRows(db, 'insumos')} warehouses={access.warehouses} />
      </div>
    </>
  );
}
