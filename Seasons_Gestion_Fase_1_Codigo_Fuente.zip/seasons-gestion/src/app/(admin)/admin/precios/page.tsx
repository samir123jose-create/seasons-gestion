import { pageAccess } from '@/modules/usuarios/access';
import { lookupRows } from '@/modules/catalogos/repository';
import { databaseError } from '@/lib/errors';
import { PriceManager } from '@/components/forms/operational-forms';
export default async function Prices() {
  const { db, access } = await pageAccess('costos.read');
  const r = await db.rpc('price_history');
  if (r.error) databaseError(r.error);
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CATÁLOGOS</div>
          <h1>Historial de precios</h1>
          <p>
            Precios de referencia con fuente y fecha, separados de compras y valoración de stock.
          </p>
        </div>
      </div>
      <PriceManager
        initial={r.data || []}
        presentations={await lookupRows(db, 'presentaciones')}
        canManage={access.permissions.includes('insumos.manage')}
      />
    </>
  );
}
