import { redirect } from 'next/navigation';
import { pageAccess } from '@/modules/usuarios/access';
import { lookupRows } from '@/modules/catalogos/repository';
export default async function Units() {
  const { db, access } = await pageAccess();
  if (
    !access.permissions.includes('catalogos.read') &&
    !access.permissions.includes('insumos.manage')
  )
    redirect('/sin-acceso');
  const units = await lookupRows(db, 'unidades');
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CATÁLOGOS</div>
          <h1>Unidades y conversiones</h1>
          <p>Las cantidades se registran en gramos, mililitros o unidades.</p>
        </div>
      </div>
      <div className="panel">
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Unidad</th>
                <th>Código</th>
                <th>Dimensión</th>
                <th>Factor a la unidad base</th>
              </tr>
            </thead>
            <tbody>
              {units.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.code}</td>
                  <td>
                    {
                      (
                        { mass: 'Masa', volume: 'Volumen', count: 'Conteo' } as Record<
                          string,
                          string
                        >
                      )[String(u.dimension)]
                    }
                  </td>
                  <td>{String(u.factor)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="client-page-note">
        Un litro equivale a 1.000 ml y un kilogramo a 1.000 g. No existe una conversión general
        entre g y ml.
      </p>
    </>
  );
}
