import { pageAccess } from '@/modules/usuarios/access';
import { databaseError } from '@/lib/errors';
import { UserManager } from '@/components/forms/user-manager';
export default async function Users() {
  const { db, access } = await pageAccess('usuarios.manage');
  const results = await Promise.all(
    [
      'profiles',
      'roles',
      'permissions',
      'warehouses',
      'user_roles',
      'user_permission_overrides',
      'user_warehouse_access',
      'role_permissions',
    ].map((t) => db.from(t).select('*').limit(1000)),
  );
  for (const r of results) if (r.error) databaseError(r.error);
  return (
    <UserManager
      users={results[0].data || []}
      roles={results[1].data || []}
      permissions={results[2].data || []}
      warehouses={results[3].data || []}
      assignments={results[4].data || []}
      overrides={results[5].data || []}
      locations={results[6].data || []}
      rolePermissions={results[7].data || []}
      currentId={access.id}
    />
  );
}
