import { redirect } from 'next/navigation';
import { pageAccess } from '@/modules/usuarios/access';
export default async function Operation() {
  await pageAccess();
  redirect('/admin/inicio');
}
