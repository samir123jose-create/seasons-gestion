import { AuthLayout } from '@/components/ui/auth-layout';
import { AuthForm } from '@/components/forms/auth-form';
export default function Password() {
  return (
    <AuthLayout>
      <div className="eyebrow">TU CUENTA</div>
      <h1>Una nueva contraseña.</h1>
      <p>Usa al menos 12 caracteres y evita contraseñas utilizadas en otros servicios.</p>
      <AuthForm mode="password" />
    </AuthLayout>
  );
}
