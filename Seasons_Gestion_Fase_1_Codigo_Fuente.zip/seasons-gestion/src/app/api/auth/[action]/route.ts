import { z } from 'zod';
import { createHash } from 'node:crypto';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { supabaseServer } from '@/lib/supabase/server';
import { appOrigin } from '@/lib/config';
import { AppError } from '@/lib/errors';
import { authenticate } from '@/modules/usuarios/access';
const attempts = new Map<string, { count: number; until: number }>();
function rateLimit(request: Request, action: string) {
  const trustedProxy = process.env.VERCEL === '1' || process.env.TRUST_PROXY_HEADERS === 'true';
  const address = trustedProxy
    ? request.headers.get('x-forwarded-for')?.split(',')[0]?.trim().slice(0, 80) || 'unknown'
    : 'local';
  const key = `${action}:${createHash('sha256').update(address).digest('hex')}`;
  const now = Date.now();
  for (const [id, entry] of attempts) if (entry.until < now) attempts.delete(id);
  if (attempts.size >= 2000 && !attempts.has(key))
    throw new AppError(429, 'RATE_LIMIT', 'Espera un minuto antes de volver a intentar.');
  const existing = attempts.get(key);
  if (!existing || existing.until < now) {
    attempts.set(key, { count: 1, until: now + 60_000 });
    return;
  }
  if (existing.count >= 30)
    throw new AppError(429, 'RATE_LIMIT', 'Espera un minuto antes de volver a intentar.');
  existing.count++;
}
export async function POST(request: Request, context: { params: Promise<{ action: string }> }) {
  return endpoint(async () => {
    checkOrigin(request);
    const action = (await context.params).action;
    if (['login', 'recover', 'password'].includes(action)) rateLimit(request, action);
    const db = await supabaseServer(true);
    if (action === 'logout') {
      const r = await db.auth.signOut();
      if (r.error)
        throw new AppError(
          503,
          'SIGNOUT_FAILED',
          'No se pudo cerrar la sesión. Intenta nuevamente.',
        );
      return json({ ok: true });
    }
    if (action === 'login') {
      const b = z
        .object({ email: z.email(), password: z.string().min(1).max(200) })
        .parse(await readJson(request));
      const r = await db.auth.signInWithPassword(b);
      if (r.error) throw new AppError(401, 'LOGIN_FAILED', 'Correo o contraseña no válidos.');
      return json({ redirect: '/admin/inicio' });
    }
    if (action === 'recover') {
      const b = z.object({ email: z.email() }).parse(await readJson(request));
      const r = await db.auth.resetPasswordForEmail(b.email, {
        redirectTo: `${appOrigin()}/auth/callback`,
      });
      if (r.error)
        throw new AppError(
          503,
          'RECOVERY_UNAVAILABLE',
          'No pudimos procesar la solicitud. Intenta nuevamente.',
        );
      return json({ ok: true });
    }
    if (action === 'password') {
      const { data, error } = await db.auth.getUser();
      if (error || !data.user)
        throw new AppError(401, 'UNAUTHENTICATED', 'Abre el enlace de recuperación nuevamente.');
      const b = z
        .object({ password: z.string().min(12, 'Usa al menos 12 caracteres.').max(200) })
        .parse(await readJson(request));
      const r = await db.auth.updateUser(b);
      if (r.error)
        throw new AppError(
          422,
          'PASSWORD_FAILED',
          'No pudimos actualizar la contraseña. Revisa los requisitos de tu cuenta.',
        );
      const revoked = await db.auth.signOut({ scope: 'global' });
      if (revoked.error)
        throw new AppError(
          503,
          'SESSION_REVOCATION_FAILED',
          'La contraseña cambió, pero no se pudieron cerrar todas las sesiones. Vuelve a intentar cerrar sesión.',
        );
      return json({ ok: true });
    }
    if (action === 'session') {
      return json((await authenticate(true)).access);
    }
    throw new AppError(404, 'NOT_FOUND', 'No encontrado.');
  });
}
