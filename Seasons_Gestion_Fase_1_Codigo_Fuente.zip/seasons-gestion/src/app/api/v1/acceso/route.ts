import { authenticate } from '@/modules/usuarios/access';
import { endpoint, json } from '@/lib/http';
export async function GET() {
  return endpoint(async () => json((await authenticate()).access));
}
