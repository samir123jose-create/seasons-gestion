import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { databaseError } from '@/lib/errors';
import { openingSchema } from '@/modules/catalogos/config';
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    const b = openingSchema.parse(await readJson(request, 256_000));
    authorize(access, 'inventario.opening', b.warehouse_id);
    authorize(access, 'costos.read');
    const key = z.uuid().parse(request.headers.get('Idempotency-Key'));
    const r = await db.rpc('confirm_inventory_opening', {
      p_warehouse: b.warehouse_id,
      p_key: key,
      p_lines: b.lines,
    });
    if (r.error) databaseError(r.error);
    return json({ operation_id: r.data }, 201);
  });
}
