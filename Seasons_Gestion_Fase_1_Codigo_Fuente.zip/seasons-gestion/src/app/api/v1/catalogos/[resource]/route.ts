import { z } from 'zod';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { resourceSchema, catalogConfig } from '@/modules/catalogos/config';
import { listCatalog, saveCatalog } from '@/modules/catalogos/repository';
export const dynamic = 'force-dynamic';
type Context = { params: Promise<{ resource: string }> };
export async function GET(request: Request, context: Context) {
  return endpoint(async () => {
    const resource = resourceSchema.parse((await context.params).resource);
    const { db, access } = await authenticate();
    const required = catalogConfig[resource].permission;
    if (!access.permissions.includes(required))
      authorize(
        access,
        resource === 'almacenes' || resource === 'sucursales'
          ? 'inventario.read'
          : 'catalogos.read',
      );
    const url = new URL(request.url);
    const page = z.coerce
      .number()
      .int()
      .min(1)
      .max(10000)
      .parse(url.searchParams.get('page') || 1);
    return json(await listCatalog(db, resource, url.searchParams.get('search') || '', page));
  });
}
export async function POST(request: Request, context: Context) {
  return endpoint(async () => {
    checkOrigin(request);
    const resource = resourceSchema.parse((await context.params).resource);
    const { db, access } = await authenticate(true);
    authorize(access, catalogConfig[resource].permission);
    const data = catalogConfig[resource].schema.parse(await readJson(request));
    return json(await saveCatalog(db, resource, null, data, null), 201);
  });
}
export async function PATCH(request: Request, context: Context) {
  return endpoint(async () => {
    checkOrigin(request);
    const resource = resourceSchema.parse((await context.params).resource);
    const { db, access } = await authenticate(true);
    authorize(access, catalogConfig[resource].permission);
    const body = z
      .object({ id: z.uuid(), lock_version: z.number().int().positive(), data: z.unknown() })
      .parse(await readJson(request));
    return json(
      await saveCatalog(
        db,
        resource,
        body.id,
        catalogConfig[resource].schema.parse(body.data),
        body.lock_version,
      ),
    );
  });
}
