import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json } from '@/lib/http';
import { databaseError } from '@/lib/errors';
export async function GET(request: Request) {
  return endpoint(async () => {
    const { db, access } = await authenticate();
    const id = z.uuid().parse(new URL(request.url).searchParams.get('warehouse_id'));
    authorize(access, 'inventario.read', id);
    const r = await db.rpc('inventory_balances', { p_warehouse: id });
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
