import { z } from 'zod';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { databaseError } from '@/lib/errors';
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'importaciones.manage');
    const b = z.object({ job_id: z.uuid() }).parse(await readJson(request));
    const r = await db.rpc('confirm_import', { p_job: b.job_id });
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
