import { NextResponse } from 'next/server';
import ExcelJS from 'exceljs';
import { z } from 'zod';
import { endpoint } from '@/lib/http';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { importResources, templateColumns } from '@/modules/importaciones/workbook';
import { catalogConfig } from '@/modules/catalogos/config';
export const runtime = 'nodejs';
export async function GET(request: Request) {
  return endpoint(async () => {
    const resource = z
      .enum(importResources)
      .parse(new URL(request.url).searchParams.get('resource'));
    const { access } = await authenticate();
    authorize(access, 'importaciones.manage');
    authorize(access, catalogConfig[resource].permission);
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Catálogo');
    sheet.addRow(templateColumns(resource));
    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF009A77' } };
    sheet.columns.forEach((c) => (c.width = 30));
    return new NextResponse((await workbook.xlsx.writeBuffer()) as ArrayBuffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="seasons-${resource}.xlsx"`,
        'Cache-Control': 'private, no-store',
      },
    });
  });
}
