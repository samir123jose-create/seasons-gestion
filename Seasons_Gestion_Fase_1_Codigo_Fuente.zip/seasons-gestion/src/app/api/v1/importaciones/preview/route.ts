import { z } from 'zod';
import { endpoint, json, checkOrigin } from '@/lib/http';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { importResources, parseWorkbook } from '@/modules/importaciones/workbook';
import { catalogConfig } from '@/modules/catalogos/config';
import { AppError, databaseError } from '@/lib/errors';
export const runtime = 'nodejs';
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'importaciones.manage');
    // Límite del cuerpo también durante streaming, antes del parser multipart.
    const reader = request.body?.getReader();
    if (!reader) throw new AppError(422, 'INVALID_FILE', 'Selecciona un Excel.');
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.length;
      if (total > 5 * 1024 * 1024 + 16_384) {
        await reader.cancel();
        throw new AppError(413, 'TOO_LARGE', 'Máximo 5 MB.');
      }
      chunks.push(value);
    }
    const bounded = new Request(request.url, {
      method: 'POST',
      headers: { 'Content-Type': request.headers.get('content-type') || '' },
      body: Buffer.concat(chunks),
    });
    let form: FormData;
    try {
      form = await bounded.formData();
    } catch {
      throw new AppError(422, 'INVALID_FILE', 'Formulario de archivo inválido.');
    }
    const resource = z.enum(importResources).parse(form.get('resource'));
    authorize(access, catalogConfig[resource].permission);
    const file = form.get('file');
    if (!(file instanceof File) || !file.name.toLowerCase().endsWith('.xlsx'))
      throw new AppError(422, 'INVALID_FILE', 'Selecciona un archivo .xlsx.');
    const codes = new Set<string>();
    let offset = 0;
    while (true) {
      const r = await db
        .from(catalogConfig[resource].table)
        .select('code')
        .order('code')
        .range(offset, offset + 999);
      if (r.error) databaseError(r.error);
      r.data?.forEach((x) => codes.add(x.code));
      if (!r.data || r.data.length < 1000) break;
      offset += 1000;
    }
    const references = { categories: new Map<string, string>(), units: new Map<string, string>() };
    if (resource === 'insumos') {
      let start = 0;
      while (true) {
        const r = await db
          .from('item_categories')
          .select('id,code')
          .eq('active', true)
          .order('code')
          .range(start, start + 999);
        if (r.error) databaseError(r.error);
        r.data?.forEach((x) => references.categories.set(x.code, x.id));
        if (!r.data || r.data.length < 1000) break;
        start += 1000;
      }
      const r = await db.from('units').select('id,code').eq('factor', 1);
      if (r.error) databaseError(r.error);
      r.data?.forEach((x) => references.units.set(x.code, x.id));
    }
    const parsed = await parseWorkbook(
      Buffer.from(await file.arrayBuffer()),
      resource,
      codes,
      references,
    );
    if (parsed.errors.length) return json({ ...parsed, job_id: null });
    const r = await db.rpc('preview_import', { p_resource: resource, p_rows: parsed.rows });
    if (r.error) databaseError(r.error);
    return json({ ...parsed, job_id: r.data });
  });
}
