import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { databaseError } from '@/lib/errors';
import { decimal } from '@/modules/catalogos/config';
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    const b = z
      .object({ item_id: z.uuid(), warehouse_id: z.uuid(), minimum_stock: decimal })
      .parse(await readJson(request));
    authorize(access, 'insumos.manage', b.warehouse_id);
    const r = await db.rpc('set_item_minimum', {
      p_item: b.item_id,
      p_warehouse: b.warehouse_id,
      p_minimum: b.minimum_stock,
    });
    if (r.error) databaseError(r.error);
    return json({ updated: true });
  });
}
