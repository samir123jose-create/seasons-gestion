import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { databaseError } from '@/lib/errors';
import { money } from '@/modules/catalogos/config';
export async function GET() {
  return endpoint(async () => {
    const { db, access } = await authenticate();
    authorize(access, 'costos.read');
    const r = await db.rpc('price_history');
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'costos.read');
    authorize(access, 'insumos.manage');
    const b = z
      .object({
        presentation_id: z.uuid(),
        amount: money,
        effective_date: z.iso.date(),
        source: z.string().trim().min(2).max(200),
      })
      .parse(await readJson(request));
    const r = await db.rpc('record_price', {
      p_presentation: b.presentation_id,
      p_amount: b.amount,
      p_date: b.effective_date,
      p_source: b.source,
    });
    if (r.error) databaseError(r.error);
    return json({ id: r.data }, 201);
  });
}
