import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { databaseError } from '@/lib/errors';
export async function PATCH(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'usuarios.manage');
    const b = z
      .object({
        id: z.uuid(),
        lock_version: z.number().int().positive(),
        permissions: z.array(z.string().min(2).max(80)).max(100),
      })
      .parse(await readJson(request));
    const r = await db.rpc('manage_role_permissions', {
      p_role: b.id,
      p_version: b.lock_version,
      p_codes: b.permissions,
    });
    if (r.error) databaseError(r.error);
    return json({ updated: true });
  });
}

export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'usuarios.manage');
    const b = z
      .object({
        code: z.string().regex(/^[a-z0-9_-]{2,32}$/),
        name: z.string().trim().min(2).max(120),
      })
      .parse(await readJson(request));
    const r = await db.rpc('create_role', { p_code: b.code, p_name: b.name });
    if (r.error) databaseError(r.error);
    return json({ id: r.data }, 201);
  });
}
export async function GET() {
  return endpoint(async () => {
    const { db, access } = await authenticate();
    authorize(access, 'usuarios.manage');
    const r = await db.from('roles').select('id,name,code,lock_version').order('name').limit(1000);
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
