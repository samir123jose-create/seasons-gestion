import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json } from '@/lib/http';
import { databaseError } from '@/lib/errors';
export async function GET() {
  return endpoint(async () => {
    const { db, access } = await authenticate();
    if (!access.permissions.includes('insumos.manage')) authorize(access, 'catalogos.read');
    const r = await db.from('api_units').select('*').order('name');
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
