import { z } from 'zod';
import { authenticate, authorize } from '@/modules/usuarios/access';
import { endpoint, json, checkOrigin, readJson } from '@/lib/http';
import { databaseError } from '@/lib/errors';
import { userAccessSchema } from '@/modules/usuarios/schemas';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { appOrigin } from '@/lib/config';
export async function PATCH(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { db, access } = await authenticate(true);
    authorize(access, 'usuarios.manage');
    const b = userAccessSchema.parse(await readJson(request));
    const r = await db.rpc('manage_user_access', {
      p_user: b.id,
      p_version: b.lock_version,
      p_active: b.active,
      p_roles: b.roles,
      p_warehouses: b.warehouses,
      p_overrides: b.overrides,
    });
    if (r.error) databaseError(r.error);
    return json({ updated: true });
  });
}
export async function POST(request: Request) {
  return endpoint(async () => {
    checkOrigin(request);
    const { access } = await authenticate(true);
    authorize(access, 'usuarios.manage');
    const b = z
      .object({ email: z.email(), full_name: z.string().trim().min(2).max(120) })
      .parse(await readJson(request));
    const r = await supabaseAdmin().auth.admin.inviteUserByEmail(b.email, {
      data: { full_name: b.full_name },
      redirectTo: `${appOrigin()}/auth/callback`,
    });
    if (r.error) databaseError(r.error);
    // Invitado inactivo y sin concesiones. Activación explícita en Permisos tras revisar rol/ubicación.
    return json({ invited: true }, 201);
  });
}
export async function GET() {
  return endpoint(async () => {
    const { db, access } = await authenticate();
    authorize(access, 'usuarios.manage');
    const r = await db
      .from('profiles')
      .select('id,full_name,active,lock_version')
      .order('full_name')
      .limit(1000);
    if (r.error) databaseError(r.error);
    return json(r.data);
  });
}
