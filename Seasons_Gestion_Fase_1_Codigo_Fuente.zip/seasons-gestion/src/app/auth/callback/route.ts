import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { appOrigin } from '@/lib/config';
export async function GET(request: Request) {
  const code = new URL(request.url).searchParams.get('code');
  if (code) {
    const db = await supabaseServer(true);
    const { error } = await db.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(new URL('/actualizar-clave', appOrigin()));
  }
  return NextResponse.redirect(new URL('/login?enlace=invalido', appOrigin()));
}
