import type { EmailOtpType } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { appOrigin } from '@/lib/config';
export async function GET(request: Request) {
  const url = new URL(request.url);
  const hash = url.searchParams.get('token_hash');
  const type = url.searchParams.get('type');
  if (hash && ['recovery', 'invite'].includes(type || '')) {
    const db = await supabaseServer(true);
    const { error } = await db.auth.verifyOtp({ token_hash: hash, type: type as EmailOtpType });
    if (!error) return NextResponse.redirect(new URL('/actualizar-clave', appOrigin()));
  }
  return NextResponse.redirect(new URL('/login?enlace=invalido', appOrigin()));
}
