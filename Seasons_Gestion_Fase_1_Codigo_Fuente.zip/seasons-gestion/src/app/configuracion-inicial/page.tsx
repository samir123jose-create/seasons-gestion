import Link from 'next/link';
import { Database, ShieldCheck, Users, ArrowRight } from 'lucide-react';
import { Brand } from '@/components/ui/brand';
import { getSupabaseConfig } from '@/lib/config';
export default function Setup() {
  const connected = !!getSupabaseConfig();
  return (
    <main id="contenido" className="setup-wrap">
      <Brand />
      <section className="panel setup-card">
        <div className="eyebrow">PREPARACIÓN DEL ESPACIO DE TRABAJO</div>
        <h1>
          La base de cada
          <br />
          buen momento.
        </h1>
        <p>
          Seasons Gestión reúne a tu equipo y tus insumos en un espacio seguro. Antes del primer
          ingreso, el administrador debe completar la conexión y los accesos.
        </p>
        <div className="setup-checklist">
          <div>
            <Database size={24} />
            <h3>Conectar los datos</h3>
            <p>
              Una base independiente para las operaciones de Seasons, con respaldo y acceso
              protegido.
            </p>
          </div>
          <div>
            <ShieldCheck size={24} />
            <h3>Preparar las ubicaciones</h3>
            <p>Depósito central, Mega Mall y Av. Murillo, con inventarios independientes.</p>
          </div>
          <div>
            <Users size={24} />
            <h3>Habilitar el equipo</h3>
            <p>Crear el primer administrador y asignar permisos y ubicaciones a cada persona.</p>
          </div>
        </div>
        <div className="setup-note">
          {connected
            ? 'La configuración de conexión está presente. El acceso quedará disponible cuando las migraciones y la cuenta administrativa estén listas.'
            : 'La conexión aún no está configurada. El administrador encontrará los pasos de preparación en la documentación del proyecto.'}
        </div>
        <Link href="/login" className="button primary">
          Ir a inicio de sesión <ArrowRight size={17} />
        </Link>
      </section>
    </main>
  );
}
