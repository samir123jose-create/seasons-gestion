'use client';
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main id="contenido" className="setup-wrap">
      <div className="panel setup-card">
        <h1>No pudimos cargar esta página.</h1>
        <p>Comprueba la conexión e intenta nuevamente. Tus datos confirmados se conservan.</p>
        <button onClick={reset} className="button primary">
          Volver a intentar
        </button>
      </div>
    </main>
  );
}
