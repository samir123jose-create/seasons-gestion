import type { Metadata } from 'next';
import './globals.css';
import { Pwa } from '@/components/ui/pwa';
export const metadata: Metadata = {
  title: { default: 'Seasons Gestión', template: '%s · Seasons Gestión' },
  description: 'Recetas, insumos y operaciones de Seasons. Siente cada momento.',
  applicationName: 'Seasons Gestión',
  icons: {icon:'/icon.svg',apple:'/icon-192.png'},
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'Seasons' },
  manifest: '/manifest.webmanifest',
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <a href="#contenido" className="skip-link">
          Ir al contenido
        </a>
        {children}
        <Pwa />
      </body>
    </html>
  );
}
