import Link from 'next/link';
import { AuthLayout } from '@/components/ui/auth-layout';
import { AuthForm } from '@/components/forms/auth-form';
import { getSupabaseConfig } from '@/lib/config';
import { Message } from '@/components/ui/message';
export default async function Login({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const configured = !!getSupabaseConfig();
  return (
    <AuthLayout>
      <div className="eyebrow">BIENVENIDO A SEASONS</div>
      <h1>Tu equipo, conectado.</h1>
      <p>Inicia sesión para acceder a tu espacio de trabajo.</p>
      {!configured && (
        <Message error="El administrador todavía debe conectar la base de datos para habilitar el acceso." />
      )}
      {params.enlace && (
        <Message error="Este enlace no es válido o ya venció. Solicita uno nuevo." />
      )}
      {params.clave && (
        <Message success="Tu contraseña se actualizó. Inicia sesión para continuar." />
      )}
      <AuthForm mode="login" configured={configured} />
      <div className="auth-links">
        <Link className="text-link" href={configured ? '/recuperar' : '/configuracion-inicial'}>
          {configured ? '¿Olvidaste tu contraseña?' : 'Ver preparación del acceso'}
        </Link>
      </div>
    </AuthLayout>
  );
}
