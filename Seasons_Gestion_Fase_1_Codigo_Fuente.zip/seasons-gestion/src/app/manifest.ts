import type { MetadataRoute } from 'next';
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Seasons Gestión',
    short_name: 'Seasons',
    description: 'Siente cada momento.',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    background_color: '#f7f8f5',
    theme_color: '#006b53',
    lang: 'es',
    icons: [
      { src: '/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
    ],
  };
}
