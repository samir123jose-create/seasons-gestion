import Link from 'next/link';
export default function NotFound() {
  return (
    <main id="contenido" className="setup-wrap">
      <div className="panel setup-card">
        <h1>Esta página no está disponible.</h1>
        <p>Comprueba la dirección o vuelve al inicio.</p>
        <Link href="/" className="button primary">
          Ir al inicio
        </Link>
      </div>
    </main>
  );
}
