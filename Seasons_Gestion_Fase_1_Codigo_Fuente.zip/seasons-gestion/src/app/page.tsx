import { redirect } from 'next/navigation';
import { getSupabaseConfig } from '@/lib/config';
export default function Page() {
  redirect(getSupabaseConfig() ? '/admin/inicio' : '/configuracion-inicial');
}
