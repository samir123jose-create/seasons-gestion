import Link from 'next/link';
import { AuthLayout } from '@/components/ui/auth-layout';
import { AuthForm } from '@/components/forms/auth-form';
import { getSupabaseConfig } from '@/lib/config';
export default function Recover() {
  return (
    <AuthLayout>
      <div className="eyebrow">RECUPERAR ACCESO</div>
      <h1>Volvamos a conectar.</h1>
      <p>
        Escribe el correo de tu cuenta. Te enviaremos un enlace para crear una nueva contraseña.
      </p>
      <AuthForm mode="recover" configured={!!getSupabaseConfig()} />
      <div className="auth-links">
        <Link className="text-link" href="/login">
          Volver a iniciar sesión
        </Link>
      </div>
    </AuthLayout>
  );
}
