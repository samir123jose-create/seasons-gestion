import { Brand } from '@/components/ui/brand';
import { Logout } from '@/components/ui/logout';
import Link from 'next/link';
export default function Denied() {
  return (
    <main id="contenido" className="setup-wrap">
      <Brand />
      <section className="panel setup-card">
        <h1>Tu acceso necesita revisión.</h1>
        <p>
          La cuenta está inactiva o no tiene permiso para esta sección. Solicita al administrador
          que revise tus roles y ubicaciones.
        </p>
        <Link href="/operacion/inicio" className="text-link">
          Volver a tu inicio
        </Link>
        <Logout />
      </section>
    </main>
  );
}
