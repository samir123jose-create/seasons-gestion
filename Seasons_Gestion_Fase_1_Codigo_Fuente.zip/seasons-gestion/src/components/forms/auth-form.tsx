'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowRight, LoaderCircle } from 'lucide-react';
import { api } from '@/lib/client';
import { Message } from '@/components/ui/message';
export function AuthForm({
  mode,
  configured = true,
}: {
  mode: 'login' | 'recover' | 'password';
  configured?: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || !configured) return;
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    const email = String(form.get('email') || '');
    const password = String(form.get('password') || '');
    if (mode === 'password' && password !== form.get('confirmation')) {
      setError('Las contraseñas no coinciden.');
      setBusy(false);
      return;
    }
    try {
      await api(
        `/api/auth/${mode}`,
        'POST',
        mode === 'recover' ? { email } : mode === 'password' ? { password } : { email, password },
      );
      if (mode === 'login') {
        router.push('/admin/inicio');
        router.refresh();
      } else if (mode === 'recover')
        setSuccess(
          'Si el correo corresponde a una cuenta, recibirás un enlace para recuperar el acceso.',
        );
      else {
        setSuccess('Contraseña actualizada. Inicia sesión con tu nueva contraseña.');
        router.push('/login?clave=actualizada');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ocurrió un error.');
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="form-stack">
      <Message error={error} success={success} />
      {mode !== 'password' && (
        <label>
          Correo electrónico
          <input
            name="email"
            type="email"
            autoComplete="email"
            placeholder="tu@correo.com"
            required
            disabled={busy || !configured}
          />
        </label>
      )}
      {mode !== 'recover' && (
        <label>
          Contraseña
          <input
            name="password"
            type="password"
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            minLength={mode === 'password' ? 12 : 1}
            maxLength={200}
            required
            disabled={busy || !configured}
          />
        </label>
      )}
      {mode === 'password' && (
        <label>
          Confirma tu contraseña
          <input
            name="confirmation"
            type="password"
            autoComplete="new-password"
            minLength={12}
            required
            disabled={busy || !configured}
          />
        </label>
      )}
      <button className="button primary" disabled={busy || !configured}>
        {busy ? <LoaderCircle className="spin" size={18} /> : <ArrowRight size={18} />}{' '}
        {mode === 'login'
          ? 'Iniciar sesión'
          : mode === 'recover'
            ? 'Enviar enlace'
            : 'Guardar contraseña'}
      </button>
    </form>
  );
}
