'use client';
import { useState, useRef } from 'react';
import {
  Plus,
  Search,
  Pencil,
  ChevronLeft,
  ChevronRight,
  PackageOpen,
  LoaderCircle,
} from 'lucide-react';
import { catalogConfig, type Resource, type CatalogRow } from '@/modules/catalogos/config';
import { api } from '@/lib/client';
import { Dialog } from '@/components/ui/dialog';
import { Message } from '@/components/ui/message';
type Result = { rows: CatalogRow[]; total: number; page: number; pageSize: number };
export function CatalogManager({
  resource,
  initial,
  lookups,
  canManage,
}: {
  resource: Resource;
  initial: Result;
  lookups: Record<string, CatalogRow[]>;
  canManage: boolean;
}) {
  const config = catalogConfig[resource];
  const feminine = ['categorias', 'sucursales', 'presentaciones'].includes(resource);
  const newWord = feminine ? 'Nueva' : 'Nuevo';
  const [result, setResult] = useState(initial);
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<CatalogRow | null | undefined>(undefined);
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  async function load(page: number, term = search) {
    setBusy(true);
    setError('');
    try {
      setResult(
        await api<Result>(
          `/api/v1/catalogos/${resource}?page=${page}&search=${encodeURIComponent(term)}`,
        ),
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudieron cargar los datos.');
    } finally {
      setBusy(false);
    }
  }
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError('');
    setSuccess('');
    const form = new FormData(e.currentTarget);
    const data: Record<string, string | boolean> = {
      code: String(form.get('code')),
      name: String(form.get('name')),
      active: form.get('active') === 'on',
    };
    config.fields.forEach((f) => (data[f.name] = String(form.get(f.name) || '')));
    try {
      await api(
        `/api/v1/catalogos/${resource}`,
        editing ? 'PATCH' : 'POST',
        editing ? { id: editing.id, lock_version: editing.lock_version, data } : data,
      );
      setEditing(undefined);
      setSuccess(editing ? 'Cambios guardados.' : 'Registro creado.');
      await load(editing ? result.page : 1);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo guardar.');
    } finally {
      setBusy(false);
      lock.current = false;
    }
  }
  const describe = (row: CatalogRow) =>
    resource === 'presentaciones'
      ? `${String(row.base_quantity)} ${String(lookups.unidades?.find((x) => x.id === lookups.insumos?.find((i) => i.id === row.item_id)?.unit_id)?.code || '')}`
      : resource === 'insumos'
        ? String(lookups.unidades?.find((x) => x.id === row.unit_id)?.code || '')
        : resource === 'proveedores'
          ? String(row.contact || row.email || '—')
          : null;
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CATÁLOGOS</div>
          <h1>{config.title}</h1>
          <p>{config.description}</p>
        </div>
        {canManage && (
          <button
            className="button primary"
            onClick={() => {
              setError('');
              setEditing(null);
            }}
          >
            <Plus size={18} />
            {newWord} {config.singular}
          </button>
        )}
      </div>
      <Message error={editing === undefined ? error : ''} success={success} />
      <section className="panel">
        <div className="table-toolbar">
          <form
            className="search-form"
            onSubmit={(e) => {
              e.preventDefault();
              setSearch(query);
              void load(1, query);
            }}
          >
            <Search size={17} />
            <input
              aria-label={`Buscar ${config.title.toLowerCase()}`}
              placeholder="Buscar por nombre o código…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button className="button subtle" disabled={busy}>
              Buscar
            </button>
          </form>
          <span className="small muted">{result.total} registros</span>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>
                  {resource === 'presentaciones'
                    ? 'Contenido base'
                    : resource === 'insumos'
                      ? 'Unidad base'
                      : resource === 'proveedores'
                        ? 'Contacto'
                        : 'Estado'}
                </th>
                {['presentaciones', 'insumos', 'proveedores'].includes(resource) && <th>Estado</th>}
                {canManage && (
                  <th>
                    <span className="sr-only">Acciones</span>
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {result.rows.map((row) => (
                <tr key={row.id}>
                  <td>
                    <span className="code-chip">{row.code}</span>
                  </td>
                  <td className="strong">{row.name}</td>
                  <td>
                    {describe(row) ?? (
                      <span className={`status ${row.active ? 'active' : 'inactive'}`}>
                        {row.active ? 'Activo' : 'Inactivo'}
                      </span>
                    )}
                  </td>
                  {['presentaciones', 'insumos', 'proveedores'].includes(resource) && (
                    <td>
                      <span className={`status ${row.active ? 'active' : 'inactive'}`}>
                        {row.active ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                  )}
                  {canManage && (
                    <td>
                      <button
                        className="icon-button"
                        aria-label={`Editar ${row.name}`}
                        onClick={() => {
                          setError('');
                          setEditing(row);
                        }}
                      >
                        <Pencil size={16} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!result.rows.length && (
            <div className="empty-state">
              <PackageOpen size={35} />
              <h3>
                {search ? 'No encontramos coincidencias' : 'Tu catálogo está listo para comenzar'}
              </h3>
              <p>
                {search
                  ? 'Prueba con otro nombre o código.'
                  : `Agrega ${feminine ? 'tu primera' : 'tu primer'} ${config.singular} con sus datos reales.`}
              </p>
            </div>
          )}
        </div>
        <div className="table-footer">
          <span>
            {busy
              ? 'Actualizando…'
              : `Página ${result.page} de ${Math.max(1, Math.ceil(result.total / result.pageSize))}`}
          </span>
          <div>
            <button
              className="icon-button"
              aria-label="Página anterior"
              disabled={busy || result.page === 1}
              onClick={() => void load(result.page - 1)}
            >
              <ChevronLeft size={18} />
            </button>
            <button
              className="icon-button"
              aria-label="Página siguiente"
              disabled={busy || result.page * result.pageSize >= result.total}
              onClick={() => void load(result.page + 1)}
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </section>
      {editing !== undefined && (
        <Dialog
          title={`${editing ? 'Editar' : newWord} ${config.singular}`}
          busy={busy}
          onClose={() => setEditing(undefined)}
        >
          <form onSubmit={save} className="form-stack">
            <Message error={error} />
            <div className="form-grid">
              <label>
                Código
                <input
                  name="code"
                  defaultValue={editing?.code || ''}
                  required
                  maxLength={32}
                  pattern="[A-Za-z0-9_-]{2,32}"
                  autoFocus
                  disabled={busy}
                />
              </label>
              <label>
                Nombre
                <input
                  name="name"
                  defaultValue={editing?.name || ''}
                  required
                  minLength={2}
                  maxLength={120}
                  disabled={busy}
                />
              </label>
              {config.fields.map((field) => {
                const values =
                  field.options ||
                  lookups[field.lookup || '']
                    ?.filter(
                      (x) =>
                        field.lookup !== 'unidades' ||
                        resource !== 'insumos' ||
                        String(x.factor) === '1.000000000000' ||
                        String(x.factor) === '1',
                    )
                    .map((x) => ({ value: x.id, label: `${x.name} (${x.code})` })) ||
                  [];
                const fixed = !!editing && field.immutable;
                return (
                  <label key={field.name}>
                    {field.label}
                    {field.optional && <span className="optional">Opcional</span>}
                    {field.type === 'select' ? (
                      <select
                        name={field.name}
                        defaultValue={String(editing?.[field.name] || '')}
                        required={!field.optional}
                        disabled={busy || fixed}
                      >
                        <option value="">{field.optional ? 'Sin asignar' : 'Seleccionar…'}</option>
                        {values.map((x) => (
                          <option key={x.value} value={x.value}>
                            {x.label}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        name={field.name}
                        type={field.type || 'text'}
                        defaultValue={String(editing?.[field.name] || '')}
                        readOnly={fixed}
                        required={!field.optional}
                        disabled={busy}
                      />
                    )}{' '}
                    {fixed && field.type === 'select' && (
                      <input
                        type="hidden"
                        name={field.name}
                        value={String(editing?.[field.name] || '')}
                      />
                    )}
                  </label>
                );
              })}
            </div>
            {resource === 'presentaciones' && (
              <p className="form-hint">
                El contenido y la unidad se conservan para proteger el historial. Para cambiarlos,
                desactiva esta presentación y crea otra.
              </p>
            )}
            <label className="checkbox-label">
              <input
                name="active"
                type="checkbox"
                defaultChecked={editing?.active ?? true}
                disabled={busy}
              />
              Registro activo
            </label>
            <div className="dialog-actions">
              <button
                type="button"
                className="button secondary"
                onClick={() => setEditing(undefined)}
                disabled={busy}
              >
                Cancelar
              </button>
              <button className="button primary" disabled={busy}>
                {busy && <LoaderCircle size={16} className="spin" />}Guardar
              </button>
            </div>
          </form>
        </Dialog>
      )}
    </>
  );
}
