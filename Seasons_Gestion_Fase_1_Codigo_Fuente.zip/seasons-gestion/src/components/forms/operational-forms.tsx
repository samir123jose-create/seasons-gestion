'use client';
import { useState, useRef } from 'react';
import { Plus, Trash2, FileSpreadsheet, Upload, Check, LoaderCircle } from 'lucide-react';
import { api } from '@/lib/client';
import { formatMoney } from '@/lib/format';
import { Message } from '@/components/ui/message';
import type { CatalogRow } from '@/modules/catalogos/config';
type Option = { id: string; name: string };
export function MinimumForm({ items, warehouses }: { items: CatalogRow[]; warehouses: Option[] }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  return (
    <form
      className="form-stack"
      onSubmit={async (e) => {
        e.preventDefault();
        if (busy) return;
        setBusy(true);
        setError('');
        setSuccess('');
        const f = new FormData(e.currentTarget);
        try {
          await api('/api/v1/minimos', 'POST', {
            item_id: f.get('item_id'),
            warehouse_id: f.get('warehouse_id'),
            minimum_stock: f.get('minimum_stock'),
          });
          setSuccess('Stock mínimo guardado para esta ubicación.');
        } catch (e) {
          setError(e instanceof Error ? e.message : 'No se pudo guardar.');
        } finally {
          setBusy(false);
        }
      }}
    >
      <Message error={error} success={success} />
      <div className="form-grid">
        <label>
          Ubicación
          <select name="warehouse_id" required disabled={busy}>
            <option value="">Seleccionar…</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Insumo
          <select name="item_id" required disabled={busy}>
            <option value="">Seleccionar…</option>
            {items
              .filter((x) => x.active)
              .map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                </option>
              ))}
          </select>
        </label>
        <label>
          Mínimo en unidad base
          <input
            name="minimum_stock"
            inputMode="decimal"
            pattern="[0-9]+(\.[0-9]{1,6})?"
            required
            disabled={busy}
          />
        </label>
      </div>
      <div>
        <button className="button primary" disabled={busy || !items.length || !warehouses.length}>
          Guardar mínimo
        </button>
      </div>
    </form>
  );
}
export function OpeningForm({ items, warehouses }: { items: CatalogRow[]; warehouses: Option[] }) {
  const [warehouse, setWarehouse] = useState('');
  const [lines, setLines] = useState([
    { row: crypto.randomUUID(), item_id: '', quantity: '', value: '' },
  ]);
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const key = useRef(crypto.randomUUID());
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  function edit(index: number, field: string, value: string) {
    key.current = crypto.randomUUID();
    setLines((current) => current.map((x, i) => (i === index ? { ...x, [field]: value } : x)));
    setSuccess('');
  }
  return (
    <form
      className="form-stack"
      onSubmit={async (e) => {
        e.preventDefault();
        if (lock.current) return;
        lock.current = true;
        setBusy(true);
        setError('');
        setSuccess('');
        try {
          const result = await api<{ operation_id: string }>(
            '/api/v1/aperturas',
            'POST',
            {
              warehouse_id: warehouse,
              lines: lines.map(({ item_id, quantity, value }) => ({ item_id, quantity, value })),
            },
            { 'Idempotency-Key': key.current },
          );
          setSuccess(`Apertura confirmada. Referencia: ${result.operation_id}`);
        } catch (e) {
          setError(e instanceof Error ? e.message : 'No se pudo confirmar.');
        } finally {
          setBusy(false);
          lock.current = false;
        }
      }}
    >
      <Message error={error} success={success} />
      <label>
        Almacén
        <select
          value={warehouse}
          onChange={(e) => {
            setWarehouse(e.target.value);
            key.current = crypto.randomUUID();
            setSuccess('');
          }}
          required
          disabled={busy}
        >
          <option value="">Seleccionar…</option>
          {warehouses.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </select>
      </label>
      <div className="stack">
        {lines.map((line, index) => (
          <div className="opening-line" key={line.row}>
            <label>
              Insumo
              <select
                required
                value={line.item_id}
                disabled={busy}
                onChange={(e) => edit(index, 'item_id', e.target.value)}
              >
                <option value="">Seleccionar…</option>
                {items
                  .filter((i) => i.active)
                  .map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} ({i.code})
                    </option>
                  ))}
              </select>
            </label>
            <label>
              Cantidad base
              <input
                inputMode="decimal"
                pattern="[0-9]+(\.[0-9]{1,6})?"
                required
                disabled={busy}
                value={line.quantity}
                onChange={(e) => edit(index, 'quantity', e.target.value)}
              />
            </label>
            <label>
              Valor total (Bs)
              <input
                inputMode="decimal"
                pattern="[0-9]+(\.[0-9]{1,6})?"
                required
                disabled={busy}
                value={line.value}
                onChange={(e) => edit(index, 'value', e.target.value)}
              />
            </label>
            <button
              type="button"
              className="icon-button"
              aria-label={`Eliminar línea ${index + 1}`}
              disabled={busy || lines.length === 1}
              onClick={() => {
                setLines((x) => x.filter((_, i) => i !== index));
                key.current = crypto.randomUUID();
                setSuccess('');
              }}
            >
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>
      <div>
        <button
          type="button"
          className="button secondary"
          disabled={busy || lines.length >= 1000}
          onClick={() => {
            setLines((x) => [
              ...x,
              { row: crypto.randomUUID(), item_id: '', quantity: '', value: '' },
            ]);
            key.current = crypto.randomUUID();
            setSuccess('');
          }}
        >
          <Plus size={17} />
          Agregar insumo
        </button>
      </div>
      <p className="form-hint">
        La apertura se realiza una sola vez por almacén. Usa cantidades verificadas y el valor total
        histórico de cada insumo, en bolivianos. No ingreses el precio por envase en la columna de
        valor total.
      </p>
      <label className="checkbox-label">
        <input type="checkbox" required disabled={busy} />
        Confirmo que revisé las cantidades y su valoración.
      </label>
      <div>
        <button
          className="button primary"
          disabled={busy || !items.length || !warehouses.length || !!success}
        >
          {busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}Confirmar
          apertura
        </button>
      </div>
    </form>
  );
}
type Price = {
  id: string;
  presentation_id: string;
  amount: string;
  unit_cost: string;
  effective_date: string;
  source: string;
};
export function PriceManager({
  presentations,
  initial,
  canManage,
}: {
  presentations: CatalogRow[];
  initial: Price[];
  canManage: boolean;
}) {
  const [rows, setRows] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  return (
    <div className="stack">
      <Message error={error} success={success} />
      {canManage && (
        <section className="panel panel-pad">
          <h2>Registrar precio de referencia</h2>
          <p className="client-page-note">
            Este precio conserva su fecha y fuente. No registra una compra ni modifica el stock.
          </p>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              setError('');
              const form = e.currentTarget;
              const f = new FormData(form);
              try {
                await api('/api/v1/precios', 'POST', {
                  presentation_id: f.get('presentation_id'),
                  amount: f.get('amount'),
                  effective_date: f.get('effective_date'),
                  source: f.get('source'),
                });
                setRows(await api<Price[]>('/api/v1/precios'));
                setSuccess('Precio registrado. El historial anterior se conserva.');
                form.reset();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'No se pudo guardar.');
              } finally {
                setBusy(false);
              }
            }}
          >
            <div className="form-grid">
              <label>
                Presentación
                <select name="presentation_id" required disabled={busy}>
                  <option value="">Seleccionar…</option>
                  {presentations
                    .filter((x) => x.active)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.code})
                      </option>
                    ))}
                </select>
              </label>
              <label>
                Precio de la presentación (Bs)
                <input
                  name="amount"
                  required
                  inputMode="decimal"
                  pattern="[0-9]+(\.[0-9]{1,6})?"
                  disabled={busy}
                />
              </label>
              <label>
                Fecha de vigencia
                <input name="effective_date" type="date" required disabled={busy} />
              </label>
              <label>
                Fuente
                <input
                  name="source"
                  required
                  minLength={2}
                  maxLength={200}
                  placeholder="Cotización, lista del proveedor…"
                  disabled={busy}
                />
              </label>
            </div>
            <div>
              <button className="button primary" disabled={busy || !presentations.length}>
                Guardar precio
              </button>
            </div>
          </form>
        </section>
      )}
      <section className="panel">
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Presentación</th>
                <th>Precio (Bs)</th>
                <th>Costo por unidad base</th>
                <th>Fuente</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id}>
                  <td>{p.effective_date}</td>
                  <td>
                    {presentations.find((x) => x.id === p.presentation_id)?.name ||
                      p.presentation_id}
                  </td>
                  <td>{formatMoney(p.amount)}</td>
                  <td>{p.unit_cost}</td>
                  <td>{p.source}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && (
            <div className="empty-state">
              <h3>Todavía no hay precios registrados.</h3>
              <p>Registra una fuente real para comenzar el historial.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
export function ImportManager() {
  const [resource, setResource] = useState('proveedores');
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<{
    rows: Record<string, unknown>[];
    errors: { row: number; message: string }[];
    job_id: string | null;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  return (
    <div className="stack">
      <Message error={error} success={success} />
      <section className="panel panel-pad">
        <form
          className="form-stack"
          onSubmit={async (e) => {
            e.preventDefault();
            if (lock.current || !file) return;
            lock.current = true;
            setBusy(true);
            setError('');
            setSuccess('');
            setPreview(null);
            const f = new FormData();
            f.set('resource', resource);
            f.set('file', file);
            try {
              setPreview(await api('/api/v1/importaciones/preview', 'POST', f));
            } catch (e) {
              setError(e instanceof Error ? e.message : 'No se pudo revisar el archivo.');
            } finally {
              setBusy(false);
              lock.current = false;
            }
          }}
        >
          <div className="form-grid">
            <label>
              Catálogo
              <select
                value={resource}
                disabled={busy}
                onChange={(e) => {
                  setResource(e.target.value);
                  setPreview(null);
                  setSuccess('');
                }}
              >
                <option value="proveedores">Proveedores</option>
                <option value="categorias">Categorías</option>
                <option value="insumos">Insumos</option>
              </select>
            </label>
            <label>
              Archivo Excel (.xlsx)
              <input
                type="file"
                accept=".xlsx"
                required
                disabled={busy}
                onChange={(e) => {
                  setFile(e.target.files?.[0] || null);
                  setPreview(null);
                  setSuccess('');
                }}
              />
            </label>
          </div>
          <p className="form-hint">
            Máximo 5 MB y 1.000 filas. Se validan columnas, códigos duplicados y referencias antes
            de confirmar. Para insumos, usa el código de categoría y g, ml o unidad.
          </p>
          <div className="inline-form">
            <a
              className="button secondary"
              href={`/api/v1/importaciones/plantilla?resource=${resource}`}
            >
              <FileSpreadsheet size={17} />
              Descargar plantilla
            </a>
            <button className="button primary" disabled={busy || !file}>
              <Upload size={17} />
              Revisar archivo
            </button>
          </div>
        </form>
      </section>
      {preview && (
        <section className="panel panel-pad">
          <h2>Previsualización</h2>
          <p className="client-page-note">
            {preview.rows.length} filas válidas · {preview.errors.length} errores. Aún no se
            modificó el catálogo.
          </p>
          {preview.errors.map((e) => (
            <Message key={e.row} error={`Fila ${e.row}: ${e.message}`} />
          ))}
          <div className="preview-table">
            <table>
              <thead>
                <tr>
                  <th>Código</th>
                  <th>Nombre</th>
                </tr>
              </thead>
              <tbody>
                {preview.rows.map((r, i) => (
                  <tr key={i}>
                    <td>{String(r.code)}</td>
                    <td>{String(r.name)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="dialog-actions">
            <button
              className="button primary"
              disabled={busy || !preview.job_id || preview.errors.length > 0}
              onClick={async () => {
                if (lock.current) return;
                lock.current = true;
                setBusy(true);
                setError('');
                try {
                  const r = await api<{ count: number }>(
                    '/api/v1/importaciones/confirmar',
                    'POST',
                    { job_id: preview.job_id },
                  );
                  setSuccess(
                    `Importación confirmada: ${r.count} ${r.count === 1 ? 'registro' : 'registros'}.`,
                  );
                  setPreview(null);
                } catch (e) {
                  setError(e instanceof Error ? e.message : 'No se pudo confirmar.');
                } finally {
                  setBusy(false);
                  lock.current = false;
                }
              }}
            >
              <Check size={17} />
              Confirmar importación
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
