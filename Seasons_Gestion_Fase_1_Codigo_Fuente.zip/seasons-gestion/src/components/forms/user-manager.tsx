'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, ShieldCheck, Pencil } from 'lucide-react';
import { Dialog } from '@/components/ui/dialog';
import { Message } from '@/components/ui/message';
import { api } from '@/lib/client';
type User = { id: string; full_name: string; active: boolean; lock_version: number };
type Role = { id: string; name: string; code: string; lock_version: number };
type Permission = { code: string; description: string };
type Assignment = {
  user_id: string;
  role_id?: string;
  warehouse_id?: string;
  permission_code?: string;
  effect?: string;
};
export function UserManager({
  users,
  roles,
  permissions,
  warehouses,
  assignments,
  overrides,
  locations,
  currentId,
  rolePermissions,
}: {
  users: User[];
  roles: Role[];
  permissions: Permission[];
  warehouses: { id: string; name: string }[];
  assignments: Assignment[];
  overrides: Assignment[];
  locations: Assignment[];
  currentId: string;
  rolePermissions: { role_id: string; permission_code: string }[];
}) {
  const router = useRouter();
  const [edit, setEdit] = useState<User | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [invite, setInvite] = useState(false);
  const [createRole, setCreateRole] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const assigned = (userId: string) =>
    assignments
      .filter((x) => x.user_id === userId)
      .map((x) => roles.find((r) => r.id === x.role_id)?.name)
      .filter(Boolean)
      .join(', ') || 'Sin rol asignado';
  function show() {
    setError('');
    setSuccess('');
  }
  return (
    <>
      <div className="page-header">
        <div>
          <div className="eyebrow">CONFIGURACIÓN</div>
          <h1>Equipo y permisos</h1>
          <p>Cada persona, con los accesos y ubicaciones que necesita.</p>
        </div>
        <button
          className="button primary"
          onClick={() => {
            show();
            setInvite(true);
          }}
        >
          <Plus size={17} />
          Invitar persona
        </button>
      </div>
      <Message error={!edit && !role && !invite && !createRole ? error : ''} success={success} />
      <div className="user-cards">
        {users.map((u) => (
          <section className="panel user-card" key={u.id}>
            <div className="user-card-head">
              <div>
                <h3>{u.full_name}</h3>
                <p className="small muted">{assigned(u.id)}</p>
              </div>
              <span className={`status ${u.active ? 'active' : 'inactive'}`}>
                {u.active ? 'Activo' : 'Inactivo'}
              </span>
            </div>
            <p className="small muted">
              {locations
                .filter((x) => x.user_id === u.id)
                .map((x) => warehouses.find((w) => w.id === x.warehouse_id)?.name)
                .filter(Boolean)
                .join(' · ') || 'Sin ubicaciones asignadas'}
            </p>
            <div className="dialog-actions">
              <button
                className="button secondary"
                disabled={u.id === currentId}
                onClick={() => {
                  show();
                  setEdit(u);
                }}
              >
                <ShieldCheck size={16} />
                {u.id === currentId ? 'Tu cuenta' : 'Revisar accesos'}
              </button>
            </div>
          </section>
        ))}
      </div>
      <div className="section-title">
        <h2>Roles configurables</h2>
        <button
          className="button secondary"
          onClick={() => {
            show();
            setCreateRole(true);
          }}
        >
          <Plus size={16} />
          Crear rol
        </button>
      </div>
      <div className="panel">
        <table>
          <thead>
            <tr>
              <th>Rol</th>
              <th>Permisos</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {roles.map((r) => (
              <tr key={r.id}>
                <td>{r.name}</td>
                <td>{rolePermissions.filter((x) => x.role_id === r.id).length} permisos</td>
                <td>
                  <button
                    className="button secondary"
                    disabled={assignments.some(
                      (x) => x.user_id === currentId && x.role_id === r.id,
                    )}
                    onClick={() => {
                      show();
                      setRole(r);
                    }}
                  >
                    <Pencil size={15} />
                    Editar permisos
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="client-page-note">
        Para evitar perder acceso, no puedes modificar tus propios permisos ni un rol asignado a tu
        cuenta. Las denegaciones individuales prevalecen sobre las concesiones del rol.
      </p>
      {edit && (
        <Dialog title={`Accesos de ${edit.full_name}`} busy={busy} onClose={() => setEdit(null)}>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              setError('');
              const f = new FormData(e.currentTarget);
              try {
                await api('/api/v1/usuarios', 'PATCH', {
                  id: edit.id,
                  lock_version: edit.lock_version,
                  active: f.get('active') === 'on',
                  roles: f.getAll('roles'),
                  warehouses: f.getAll('warehouses'),
                  overrides: permissions.flatMap((p) => {
                    const effect = String(f.get(`override:${p.code}`));
                    return effect === 'inherit' ? [] : [{ permission_code: p.code, effect }];
                  }),
                });
                setEdit(null);
                setSuccess(
                  'Accesos actualizados. El cambio se aplica a las siguientes operaciones.',
                );
                router.refresh();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'No se pudo guardar.');
              } finally {
                setBusy(false);
              }
            }}
          >
            <Message error={error} />
            <label className="checkbox-label">
              <input name="active" type="checkbox" defaultChecked={edit.active} disabled={busy} />
              Cuenta activa
            </label>
            <div className="form-section">
              <h3>Roles</h3>
              <div className="check-grid">
                {roles.map((r) => (
                  <label className="checkbox-label" key={r.id}>
                    <input
                      type="checkbox"
                      name="roles"
                      value={r.id}
                      disabled={busy}
                      defaultChecked={assignments.some(
                        (x) => x.user_id === edit.id && x.role_id === r.id,
                      )}
                    />
                    {r.name}
                  </label>
                ))}
              </div>
            </div>
            <div className="form-section">
              <h3>Ubicaciones asignadas</h3>
              <div className="check-grid">
                {warehouses.map((w) => (
                  <label className="checkbox-label" key={w.id}>
                    <input
                      type="checkbox"
                      name="warehouses"
                      value={w.id}
                      disabled={busy}
                      defaultChecked={locations.some(
                        (x) => x.user_id === edit.id && x.warehouse_id === w.id,
                      )}
                    />
                    {w.name}
                  </label>
                ))}
              </div>
            </div>
            <div className="form-section">
              <h3>Permisos individuales</h3>
              <div className="form-grid">
                {permissions.map((p) => (
                  <label key={p.code}>
                    {p.description}
                    <select
                      name={`override:${p.code}`}
                      disabled={busy}
                      defaultValue={
                        overrides.find((x) => x.user_id === edit.id && x.permission_code === p.code)
                          ?.effect || 'inherit'
                      }
                    >
                      <option value="inherit">Heredar del rol</option>
                      <option value="allow">Conceder</option>
                      <option value="deny">Denegar</option>
                    </select>
                  </label>
                ))}
              </div>
            </div>
            <div className="dialog-actions">
              <button className="button primary" disabled={busy}>
                Guardar accesos
              </button>
            </div>
          </form>
        </Dialog>
      )}
      {role && (
        <Dialog title={`Permisos: ${role.name}`} busy={busy} onClose={() => setRole(null)}>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              setError('');
              const f = new FormData(e.currentTarget);
              try {
                await api('/api/v1/roles', 'PATCH', {
                  id: role.id,
                  lock_version: role.lock_version,
                  permissions: f.getAll('permissions'),
                });
                setRole(null);
                setSuccess('Permisos del rol actualizados.');
                router.refresh();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'No se pudo guardar.');
              } finally {
                setBusy(false);
              }
            }}
          >
            <Message error={error} />
            <div className="check-grid">
              {permissions.map((p) => (
                <label className="checkbox-label" key={p.code}>
                  <input
                    name="permissions"
                    type="checkbox"
                    value={p.code}
                    disabled={busy}
                    defaultChecked={rolePermissions.some(
                      (x) => x.role_id === role.id && x.permission_code === p.code,
                    )}
                  />
                  {p.description}
                </label>
              ))}
            </div>
            <div className="dialog-actions">
              <button className="button primary" disabled={busy}>
                Guardar permisos
              </button>
            </div>
          </form>
        </Dialog>
      )}
      {invite && (
        <Dialog title="Invitar al equipo" busy={busy} onClose={() => setInvite(false)}>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              setError('');
              const f = new FormData(e.currentTarget);
              try {
                await api('/api/v1/usuarios', 'POST', {
                  full_name: f.get('full_name'),
                  email: f.get('email'),
                });
                setInvite(false);
                setSuccess(
                  'Invitación enviada. Revisa sus roles y ubicaciones antes de activar la cuenta.',
                );
                router.refresh();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'No se pudo invitar.');
              } finally {
                setBusy(false);
              }
            }}
          >
            <Message error={error} />
            <label>
              Nombre completo
              <input name="full_name" required minLength={2} maxLength={120} disabled={busy} />
            </label>
            <label>
              Correo
              <input name="email" type="email" required disabled={busy} />
            </label>
            <p className="form-hint">
              Recibirá un enlace para establecer su contraseña. La cuenta se crea inactiva y sin
              permisos hasta tu revisión.
            </p>
            <button className="button primary" disabled={busy}>
              Enviar invitación
            </button>
          </form>
        </Dialog>
      )}
      {createRole && (
        <Dialog title="Crear rol" busy={busy} onClose={() => setCreateRole(false)}>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              setError('');
              const f = new FormData(e.currentTarget);
              try {
                await api('/api/v1/roles', 'POST', { code: f.get('code'), name: f.get('name') });
                setCreateRole(false);
                setSuccess('Rol creado. Configura sus permisos antes de asignarlo.');
                router.refresh();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'No se pudo crear.');
              } finally {
                setBusy(false);
              }
            }}
          >
            <Message error={error} />
            <label>
              Código
              <input name="code" required pattern="[a-z0-9_-]{2,32}" disabled={busy} />
            </label>
            <label>
              Nombre
              <input name="name" required minLength={2} maxLength={120} disabled={busy} />
            </label>
            <button className="button primary" disabled={busy}>
              Crear rol
            </button>
          </form>
        </Dialog>
      )}
    </>
  );
}
