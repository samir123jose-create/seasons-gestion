import { Brand } from './brand';
export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main id="contenido" className="auth-page">
      <section className="auth-story">
        <Brand light />
        <div className="auth-story-content">
          <div className="eyebrow">CADA DETALLE CUENTA</div>
          <h1>
            Más orden.
            <br />
            Más tiempo para
            <br />
            <em>cada momento.</em>
          </h1>
          <p>
            Un espacio compartido para cuidar los ingredientes, las recetas y el equipo de Seasons.
          </p>
        </div>
        <div className="auth-story-footer">Siente cada momento.</div>
      </section>
      <section className="auth-form-side">
        <div className="auth-card">
          <div className="auth-mobile-brand">
            <Brand />
          </div>
          {children}
        </div>
      </section>
    </main>
  );
}
