import { Leaf } from 'lucide-react';
export function Brand({ light = false }: { light?: boolean }) {
  return (
    <div className={`brand ${light ? 'brand-light' : ''}`}>
      <span className="brand-icon">
        <Leaf size={21} />
      </span>
      <div>
        <span className="brand-name">
          seasons<span className="brand-dot">.</span>
        </span>
        <span className="brand-caption">GESTIÓN</span>
      </div>
    </div>
  );
}
