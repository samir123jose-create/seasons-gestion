'use client';
import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
export function Dialog({
  title,
  onClose,
  children,
  busy = false,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  busy?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    // En móviles, el viewport de layout puede ampliarse por contenido mínimo. Usar
    // el ancho visible del documento evita diálogos fuera de pantalla y toques desplazados.
    const fit = () => {
      const available = document.documentElement.clientWidth || window.innerWidth;
      const width = Math.min(640, available - 32);
      dialog.style.width = `${width}px`;
      dialog.style.maxWidth = `${width}px`;
      dialog.style.left = `${Math.max(16, (available - width) / 2)}px`;
      dialog.style.right = 'auto';
      dialog.style.marginLeft = '0';
      dialog.style.marginRight = '0';
    };
    fit();
    dialog.showModal();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <dialog
      ref={ref}
      className="dialog"
      aria-labelledby="dialog-title"
      onCancel={(e) => {
        if (busy) e.preventDefault();
        else onClose();
      }}
    >
      <div className="dialog-head">
        <h2 id="dialog-title">{title}</h2>
        <button
          type="button"
          className="icon-button"
          onClick={onClose}
          disabled={busy}
          aria-label="Cerrar formulario"
        >
          <X size={20} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
