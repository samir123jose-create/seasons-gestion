'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';
import { api } from '@/lib/client';
export function Logout() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  return (
    <>
      <button
        className="logout"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError('');
          try {
            await api('/api/auth/logout', 'POST');
            router.push('/login');
            router.refresh();
          } catch (e) {
            setError(e instanceof Error ? e.message : 'No se pudo cerrar sesión.');
            setBusy(false);
          }
        }}
      >
        <LogOut size={17} />
        {busy ? 'Cerrando…' : 'Cerrar sesión'}
      </button>
      {error && (
        <span role="alert" className="small error-text">
          {error}
        </span>
      )}
    </>
  );
}
