import { AlertCircle, CheckCircle2 } from 'lucide-react';
export function Message({ error, success }: { error?: string; success?: string }) {
  if (!error && !success) return null;
  return (
    <div
      role={error ? 'alert' : 'status'}
      className={`message ${error ? 'message-error' : 'message-success'}`}
    >
      {error ? <AlertCircle size={18} /> : <CheckCircle2 size={18} />}
      <span>{error || success}</span>
    </div>
  );
}
