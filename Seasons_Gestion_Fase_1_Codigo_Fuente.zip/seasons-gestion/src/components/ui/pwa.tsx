'use client';
import { useEffect } from 'react';
export function Pwa() {
  useEffect(() => {
    if ('serviceWorker' in navigator)
      void navigator.serviceWorker.register('/sw.js').catch(() => {
        /* La aplicación sigue disponible en línea si la instalación no es compatible. */
      });
  }, []);
  return null;
}
