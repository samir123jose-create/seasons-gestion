'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import {
  LayoutGrid,
  Package,
  Truck,
  Shapes,
  Ruler,
  Boxes,
  MapPin,
  Users,
  FileSpreadsheet,
  History,
  Menu,
  X,
  ArrowUpRight,
  Tags,
  SlidersHorizontal,
  ClipboardCheck,
} from 'lucide-react';
import { Brand } from './brand';
import { Logout } from './logout';
import type { Access } from '@/modules/usuarios/access';
const links = [
  { href: '/admin/inicio', label: 'Inicio', icon: LayoutGrid, permission: '' },
  {
    href: '/admin/catalogos/insumos',
    label: 'Insumos',
    icon: Package,
    permission: 'catalogos.read',
    alternative: 'insumos.manage',
  },
  {
    href: '/admin/catalogos/proveedores',
    label: 'Proveedores',
    icon: Truck,
    permission: 'catalogos.read',
    alternative: 'proveedores.manage',
  },
  {
    href: '/admin/catalogos/categorias',
    label: 'Categorías',
    icon: Shapes,
    permission: 'catalogos.read',
    alternative: 'insumos.manage',
  },
  {
    href: '/admin/catalogos/presentaciones',
    label: 'Presentaciones',
    icon: Boxes,
    permission: 'catalogos.read',
    alternative: 'insumos.manage',
  },
  {
    href: '/admin/unidades',
    label: 'Unidades',
    icon: Ruler,
    permission: 'catalogos.read',
    alternative: 'insumos.manage',
  },
  { href: '/admin/precios', label: 'Precios', icon: Tags, permission: 'costos.read' },
  {
    href: '/admin/minimos',
    label: 'Stock mínimo',
    icon: SlidersHorizontal,
    permission: 'insumos.manage',
  },
  {
    href: '/admin/importaciones',
    label: 'Importar Excel',
    icon: FileSpreadsheet,
    permission: 'importaciones.manage',
  },
  {
    href: '/admin/catalogos/sucursales',
    label: 'Sucursales',
    icon: MapPin,
    permission: 'ubicaciones.manage',
  },
  {
    href: '/admin/catalogos/almacenes',
    label: 'Almacenes',
    icon: Boxes,
    permission: 'ubicaciones.manage',
  },
  {
    href: '/admin/usuarios',
    label: 'Equipo y permisos',
    icon: Users,
    permission: 'usuarios.manage',
  },
  {
    href: '/admin/aperturas',
    label: 'Apertura de inventario',
    icon: ClipboardCheck,
    permission: 'inventario.opening',
  },
  {
    href: '/admin/auditoria',
    label: 'Historial de acciones',
    icon: History,
    permission: 'usuarios.manage',
  },
];
export function Shell({
  access,
  children,
  isTest = false,
}: {
  access: Access;
  children: React.ReactNode;
  isTest?: boolean;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
        <Link href="/admin/inicio" aria-label="Seasons Gestión, inicio">
          <Brand />
        </Link>
        <div className="nav-label">TU ESPACIO DE TRABAJO</div>
        <nav aria-label="Navegación principal">
          {links
            .filter(
              (x) =>
                !x.permission ||
                access.permissions.includes(x.permission) ||
                (!!x.alternative && access.permissions.includes(x.alternative)),
            )
            .map((x) => (
              <Link
                href={x.href}
                key={x.href}
                onClick={() => setOpen(false)}
                className={`nav-item ${pathname === x.href ? 'selected' : ''}`}
                aria-current={pathname === x.href ? 'page' : undefined}
              >
                <x.icon size={18} />
                <span>{x.label}</span>
                {pathname === x.href && <span className="nav-dot" />}
              </Link>
            ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="brand-promise">
            <LeafMark />
            Siente cada momento.
          </div>
          <Logout />
        </div>
      </aside>
      {open && (
        <button className="mobile-scrim" onClick={() => setOpen(false)} aria-label="Cerrar menú" />
      )}
      <div className="main-shell">
        <header className="topbar">
          <div className="topbar-left">
            <button
              className="icon-button menu-toggle"
              onClick={() => setOpen(!open)}
              aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
              aria-expanded={open}
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
            <span className="topbar-context">
              {isTest && <span className="pill">Datos de prueba</span>}Seasons <span>/</span>{' '}
              Gestión
            </span>
          </div>
          <div className="topbar-user">
            <span className="location-chip">
              <MapPin size={14} />
              {access.warehouses.length === 1
                ? access.warehouses[0].name
                : `${access.warehouses.length} ubicaciones asignadas`}
            </span>
            <span className="avatar" aria-hidden="true">
              {access.full_name.trim().slice(0, 2).toUpperCase()}
            </span>
            <span className="user-name">{access.full_name}</span>
          </div>
        </header>
        <main id="contenido" className="main-content">
          {children}
        </main>
        <footer className="app-footer">
          <span>Seasons Gestión</span>
          <span>
            Siente cada momento. <ArrowUpRight size={13} />
          </span>
        </footer>
      </div>
    </div>
  );
}
function LeafMark() {
  return <span className="leaf-mark">✦</span>;
}
