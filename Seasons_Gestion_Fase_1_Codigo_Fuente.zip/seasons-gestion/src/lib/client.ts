export async function api<T>(
  url: string,
  method = 'GET',
  body?: unknown,
  extraHeaders: Record<string, string> = {},
): Promise<T> {
  const isForm = body instanceof FormData;
  const response = await fetch(url, {
    method,
    headers: {
      ...(!isForm && body ? { 'Content-Type': 'application/json' } : {}),
      ...extraHeaders,
    },
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
    cache: 'no-store',
  }).catch(() => {
    throw new Error('No hay conexión. Revisa el estado de la operación antes de reintentar.');
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok)
    throw new Error(
      payload?.error?.message || 'No pudimos completar la operación. Revisa la conexión.',
    );
  return payload.data as T;
}
