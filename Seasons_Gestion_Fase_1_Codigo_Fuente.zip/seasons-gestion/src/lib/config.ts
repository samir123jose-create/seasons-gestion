import { z } from 'zod';
const publicConfig = z.object({ url: z.url(), key: z.string().min(10) });
export function getSupabaseConfig() {
  const result = publicConfig.safeParse({
    url: process.env.NEXT_PUBLIC_SUPABASE_URL,
    key: process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
  });
  return result.success ? result.data : null;
}
export function appOrigin() {
  return new URL(process.env.APP_URL || 'http://localhost:3000').origin;
}
