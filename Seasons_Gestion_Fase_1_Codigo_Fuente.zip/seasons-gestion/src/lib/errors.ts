export class AppError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}
export function databaseError(error: { code?: string; message?: string }): never {
  const messages: Record<string, [number, string, string]> = {
    '22003': [422, 'NUMERIC_RANGE', 'La cantidad o el importe supera la precisión admitida.'],
    '23502': [422, 'VALIDATION', 'Faltan campos obligatorios.'],
    '42501': [403, 'FORBIDDEN', 'No tienes permiso para esta operación.'],
    '23505': [409, 'DUPLICATE', 'El código o registro ya existe.'],
    '40001': [
      409,
      'CONFLICT',
      'Los datos cambiaron o la clave ya se utilizó. Actualiza y revisa antes de guardar.',
    ],
    '23503': [422, 'REFERENCE', 'Una referencia no existe o sigue siendo utilizada.'],
    '23514': [
      422,
      'BUSINESS_RULE',
      'La operación no cumple las reglas: verifica unidades, cantidades, apertura y disponibilidad.',
    ],
    '22023': [422, 'VALIDATION', 'Los datos no son válidos.'],
    '22P02': [422, 'VALIDATION', 'Formato de datos no válido.'],
    P0002: [404, 'NOT_FOUND', 'No se encontró el registro.'],
  };
  const value = messages[error.code || ''];
  if (value) throw new AppError(...value);
  console.error('Database operation failed', { code: error.code });
  throw new AppError(
    503,
    'DATABASE_UNAVAILABLE',
    'No pudimos completar la operación. Intenta nuevamente.',
  );
}
