import { scaledDecimal } from '@/modules/insumos/domain/units';
/** Presentación monetaria exacta; no convierte el importe a Number. */
export function formatMoney(amount: string, locale = 'es-BO') {
  const negative = amount.startsWith('-');
  const units = scaledDecimal(negative ? amount.slice(1) : amount, 6);
  const cents = (units + 5000n) / 10000n;
  const whole = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(cents / 100n);
  const separator =
    new Intl.NumberFormat(locale).formatToParts(1.1).find((part) => part.type === 'decimal')
      ?.value || '.';
  return `${negative && cents !== 0n ? '-' : ''}${whole}${separator}${(cents % 100n).toString().padStart(2, '0')}`;
}
