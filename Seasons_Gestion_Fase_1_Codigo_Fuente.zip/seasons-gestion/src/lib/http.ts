import { NextResponse } from 'next/server';
import { z } from 'zod';
import { AppError } from './errors';
import { appOrigin } from './config';
export function checkOrigin(request: Request) {
  if (request.headers.get('origin') !== appOrigin())
    throw new AppError(403, 'INVALID_ORIGIN', 'Origen de la operación no permitido.');
}
export async function readJson(request: Request, maxBytes = 32_768): Promise<unknown> {
  if (!request.headers.get('content-type')?.includes('application/json'))
    throw new AppError(415, 'CONTENT_TYPE', 'Envía datos JSON.');
  const reader = request.body?.getReader();
  if (!reader) throw new AppError(422, 'VALIDATION', 'Faltan los datos.');
  let size = 0;
  const chunks: Uint8Array[] = [];
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > maxBytes) {
      await reader.cancel();
      throw new AppError(413, 'TOO_LARGE', 'El archivo o formulario supera el límite.');
    }
    chunks.push(value);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new AppError(422, 'VALIDATION', 'JSON inválido.');
  }
}
export function json(data: unknown, status = 200) {
  return NextResponse.json({ data }, { status, headers: { 'Cache-Control': 'private, no-store' } });
}
export async function endpoint(run: () => Promise<NextResponse>) {
  const requestId = crypto.randomUUID();
  try {
    const response = await run();
    response.headers.set('X-Request-Id', requestId);
    return response;
  } catch (error) {
    const known =
      error instanceof AppError
        ? error
        : error instanceof z.ZodError
          ? new AppError(
              422,
              'VALIDATION',
              error.issues.map((x) => `${x.path.join('.') || 'Datos'}: ${x.message}`).join('; '),
            )
          : new AppError(500, 'INTERNAL', 'No pudimos completar la operación.');
    if (known.status >= 500) console.error('Request failed', { requestId, code: known.code });
    return NextResponse.json(
      { error: { code: known.code, message: known.message, request_id: requestId } },
      {
        status: known.status,
        headers: { 'Cache-Control': 'private, no-store', 'X-Request-Id': requestId },
      },
    );
  }
}
