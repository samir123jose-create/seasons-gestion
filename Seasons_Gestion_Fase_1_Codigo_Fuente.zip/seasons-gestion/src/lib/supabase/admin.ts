import 'server-only';
import { createClient } from '@supabase/supabase-js';
import { getSupabaseConfig } from '../config';
import { AppError } from '../errors';
export function supabaseAdmin() {
  const config = getSupabaseConfig();
  const secret = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!config || !secret)
    throw new AppError(
      503,
      'INVITATIONS_UNAVAILABLE',
      'Las invitaciones aún no están habilitadas.',
    );
  return createClient(config.url, secret, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
