import 'server-only';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { getSupabaseConfig } from '../config';
import { AppError } from '../errors';
export async function supabaseServer(writable = false) {
  const config = getSupabaseConfig();
  if (!config)
    throw new AppError(503, 'SETUP_REQUIRED', 'La conexión segura todavía no está configurada.');
  const store = await cookies();
  return createServerClient(config.url, config.key, {
    cookies: {
      getAll: () => store.getAll(),
      setAll(values) {
        if (writable) values.forEach(({ name, value, options }) => store.set(name, value, options));
      },
    },
    cookieOptions: { sameSite: 'lax', secure: process.env.NODE_ENV === 'production' },
  });
}
