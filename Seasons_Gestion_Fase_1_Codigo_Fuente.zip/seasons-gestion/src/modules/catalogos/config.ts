import { z } from 'zod';
const code = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z0-9_-]{2,32}$/, 'Usa 2–32 letras, números, guion o guion bajo.');
const base = z.object({
  code,
  name: z.string().trim().min(2).max(120),
  active: z.boolean().default(true),
});
export const decimal = z
  .string()
  .regex(/^[0-9]{1,14}(\.[0-9]{1,6})?$/, 'Hasta 6 decimales, con punto decimal.');
export const money = z
  .string()
  .regex(/^[0-9]{1,18}(\.[0-9]{1,6})?$/, 'Importe positivo, con hasta 6 decimales.');
const positiveDecimal = decimal.refine((s) => /[1-9]/.test(s), 'Debe ser mayor que cero.');
const optionalId = z
  .union([z.uuid(), z.literal('')])
  .optional()
  .default('');
export const resources = [
  'insumos',
  'proveedores',
  'categorias',
  'sucursales',
  'almacenes',
  'presentaciones',
] as const;
export const resourceSchema = z.enum(resources);
export type Resource = z.infer<typeof resourceSchema>;
export type Field = {
  name: string;
  label: string;
  type?: 'text' | 'email' | 'select';
  options?: { value: string; label: string }[];
  lookup?: Resource | 'unidades';
  optional?: boolean;
  immutable?: boolean;
};
export const catalogConfig: Record<
  Resource,
  {
    title: string;
    singular: string;
    description: string;
    table: string;
    permission: string;
    schema: z.ZodType;
    fields: Field[];
  }
> = {
  insumos: {
    title: 'Insumos',
    singular: 'insumo',
    description: 'Ingredientes, materiales y empaques con una unidad base clara.',
    table: 'items',
    permission: 'insumos.manage',
    schema: base.extend({
      category_id: z.uuid(),
      unit_id: z.uuid(),
      item_type: z.enum(['ingredient', 'material', 'packaging']),
    }),
    fields: [
      { name: 'category_id', label: 'Categoría', type: 'select', lookup: 'categorias' },
      {
        name: 'unit_id',
        label: 'Unidad base',
        type: 'select',
        lookup: 'unidades',
        immutable: true,
      },
      {
        name: 'item_type',
        label: 'Tipo',
        type: 'select',
        options: [
          { value: 'ingredient', label: 'Ingrediente' },
          { value: 'material', label: 'Material' },
          { value: 'packaging', label: 'Empaque' },
        ],
      },
    ],
  },
  proveedores: {
    title: 'Proveedores',
    singular: 'proveedor',
    description: 'Contactos y datos comerciales en un solo lugar.',
    table: 'suppliers',
    permission: 'proveedores.manage',
    schema: base.extend({
      contact: z.string().max(160).default(''),
      phone: z.string().max(40).default(''),
      email: z.union([z.email(), z.literal('')]).default(''),
      tax_id: z.string().max(40).default(''),
    }),
    fields: [
      { name: 'contact', label: 'Contacto', optional: true },
      { name: 'phone', label: 'Teléfono', optional: true },
      { name: 'email', label: 'Correo', type: 'email', optional: true },
      { name: 'tax_id', label: 'NIT / identificación tributaria', optional: true },
    ],
  },
  categorias: {
    title: 'Categorías',
    singular: 'categoría',
    description: 'Organiza los insumos para encontrar lo que necesitas.',
    table: 'item_categories',
    permission: 'insumos.manage',
    schema: base,
    fields: [],
  },
  sucursales: {
    title: 'Sucursales',
    singular: 'sucursal',
    description: 'Puntos de operación de Seasons.',
    table: 'branches',
    permission: 'ubicaciones.manage',
    schema: base,
    fields: [],
  },
  almacenes: {
    title: 'Almacenes',
    singular: 'almacén',
    description: 'Ubicaciones independientes; el depósito puede existir sin sucursal.',
    table: 'warehouses',
    permission: 'ubicaciones.manage',
    schema: base.extend({ branch_id: optionalId }),
    fields: [
      {
        name: 'branch_id',
        label: 'Sucursal',
        type: 'select',
        lookup: 'sucursales',
        optional: true,
      },
    ],
  },
  presentaciones: {
    title: 'Presentaciones',
    singular: 'presentación',
    description: 'Convierte cada compra a la unidad base del insumo.',
    table: 'api_presentations',
    permission: 'insumos.manage',
    schema: base.extend({
      item_id: z.uuid(),
      unit_id: z.uuid(),
      quantity: positiveDecimal,
      supplier_id: optionalId,
    }),
    fields: [
      { name: 'item_id', label: 'Insumo', type: 'select', lookup: 'insumos', immutable: true },
      { name: 'quantity', label: 'Contenido por presentación', immutable: true },
      {
        name: 'unit_id',
        label: 'Unidad del contenido',
        type: 'select',
        lookup: 'unidades',
        immutable: true,
      },
      {
        name: 'supplier_id',
        label: 'Proveedor',
        type: 'select',
        lookup: 'proveedores',
        optional: true,
        immutable: true,
      },
    ],
  },
};
export type CatalogRow = {
  id: string;
  code: string;
  name: string;
  active: boolean;
  lock_version: number;
  [key: string]: unknown;
};
export const openingSchema = z.object({
  warehouse_id: z.uuid(),
  lines: z
    .array(z.object({ item_id: z.uuid(), quantity: positiveDecimal, value: money }))
    .min(1)
    .max(1000),
});
