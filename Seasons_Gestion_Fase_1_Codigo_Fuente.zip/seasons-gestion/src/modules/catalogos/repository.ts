import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { catalogConfig, type Resource, type CatalogRow } from './config';
import { databaseError } from '@/lib/errors';
export async function listCatalog(
  db: SupabaseClient,
  resource: Resource,
  search = '',
  page = 1,
  pageSize = 25,
) {
  let query = db
    .from(catalogConfig[resource].table)
    .select('*', { count: 'exact' })
    .order('name')
    .range((page - 1) * pageSize, page * pageSize - 1);
  const term = search.trim().slice(0, 80);
  if (term) {
    // Escapar LIKE y luego el valor citado de la gramática PostgREST.
    const literal = term.replace(/\\/g, '\\\\').replace(/[%_]/g, (char) => '\\' + char);
    const quoted = literal.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    query = query.or(`name.ilike."%${quoted}%",code.ilike."%${quoted}%"`);
  }
  const result = await query;
  if (result.error) databaseError(result.error);
  return { rows: (result.data || []) as CatalogRow[], total: result.count || 0, page, pageSize };
}
export async function lookupRows(db: SupabaseClient, resource: Resource | 'unidades') {
  const result = await db
    .from(resource === 'unidades' ? 'api_units' : catalogConfig[resource].table)
    .select('*')
    .order('name')
    .limit(1000);
  if (result.error) databaseError(result.error);
  return (result.data || []) as CatalogRow[];
}
export async function saveCatalog(
  db: SupabaseClient,
  resource: Resource,
  id: string | null,
  data: unknown,
  version: number | null,
) {
  const result = await db.rpc('manage_catalog', {
    p_resource: resource,
    p_id: id,
    p_data: data,
    p_version: version,
  });
  if (result.error) databaseError(result.error);
  return result.data;
}
