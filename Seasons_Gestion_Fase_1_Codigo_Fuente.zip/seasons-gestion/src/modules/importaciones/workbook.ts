import ExcelJS from 'exceljs';
import { inflateRawSync } from 'node:zlib';
import { AppError } from '@/lib/errors';
import { catalogConfig, type Resource } from '@/modules/catalogos/config';
export const importResources = ['proveedores', 'categorias', 'insumos'] as const;
export type ImportResource = (typeof importResources)[number];
export function validateArchive(bytes: Buffer) {
  if (bytes.length > 5 * 1024 * 1024)
    throw new AppError(413, 'TOO_LARGE', 'Máximo 5 MB por archivo.');
  const signature = Buffer.from([0x50, 0x4b, 0x05, 0x06]);
  const end = bytes.lastIndexOf(signature);
  if (end < 0 || end + 22 > bytes.length)
    throw new AppError(422, 'INVALID_FILE', 'Selecciona un archivo Excel .xlsx válido.');
  const count = bytes.readUInt16LE(end + 10);
  let offset = bytes.readUInt32LE(end + 16);
  let uncompressed = 0;
  if (count > 200 || count === 0)
    throw new AppError(422, 'INVALID_FILE', 'El archivo contiene demasiadas partes.');
  for (let i = 0; i < count; i++) {
    if (offset + 46 > bytes.length || bytes.readUInt32LE(offset) !== 0x02014b50)
      throw new AppError(422, 'INVALID_FILE', 'Estructura Excel inválida.');
    const flags = bytes.readUInt16LE(offset + 8);
    const size = bytes.readUInt32LE(offset + 24);
    const name = bytes.readUInt16LE(offset + 28);
    const extra = bytes.readUInt16LE(offset + 30);
    const comment = bytes.readUInt16LE(offset + 32);
    uncompressed += size;
    if (flags & 1 || uncompressed > 20 * 1024 * 1024)
      throw new AppError(413, 'TOO_LARGE', 'Contenido expandido supera 20 MB o está cifrado.');
    const compressedSize = bytes.readUInt32LE(offset + 20);
    const method = bytes.readUInt16LE(offset + 10);
    const local = bytes.readUInt32LE(offset + 42);
    if (local + 30 > bytes.length || bytes.readUInt32LE(local) !== 0x04034b50)
      throw new AppError(422, 'INVALID_FILE', 'Entrada Excel inválida.');
    const start = local + 30 + bytes.readUInt16LE(local + 26) + bytes.readUInt16LE(local + 28);
    if (start + compressedSize > bytes.length || ![0, 8].includes(method))
      throw new AppError(422, 'INVALID_FILE', 'Compresión Excel no válida.');
    try {
      const data =
        method === 0
          ? bytes.subarray(start, start + compressedSize)
          : inflateRawSync(bytes.subarray(start, start + compressedSize), {
              maxOutputLength: 20 * 1024 * 1024,
            });
      if (data.length !== size) throw new Error('size');
    } catch {
      throw new AppError(422, 'INVALID_FILE', 'Contenido comprimido inválido o excesivo.');
    }
    offset += 46 + name + extra + comment;
    if (offset > bytes.length) throw new AppError(422, 'INVALID_FILE', 'Archivo truncado.');
  }
}
export function templateColumns(resource: ImportResource) {
  return resource === 'insumos'
    ? ['code', 'name', 'category_code', 'unit_code', 'item_type']
    : ['code', 'name', ...catalogConfig[resource].fields.map((f) => f.name)];
}
export async function parseWorkbook(
  bytes: Buffer,
  resource: ImportResource,
  existingCodes: Set<string>,
  references?: { categories: Map<string, string>; units: Map<string, string> },
) {
  validateArchive(bytes);
  const workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.load(Uint8Array.from(bytes).buffer);
  } catch {
    throw new AppError(422, 'INVALID_FILE', 'No pudimos leer este Excel.');
  }
  const sheet = workbook.worksheets[0];
  if (!sheet || sheet.actualRowCount < 2 || sheet.rowCount > 1001 || sheet.columnCount > 20)
    throw new AppError(422, 'INVALID_FILE', 'Usa entre 1 y 1.000 filas y hasta 20 columnas.');
  const headers: string[] = [];
  sheet.getRow(1).eachCell({ includeEmpty: true }, (cell, index) => {
    headers[index - 1] = cell.text.trim();
  });
  const expected = templateColumns(resource);
  if (expected.some((h) => !headers.includes(h)) || new Set(headers).size !== headers.length)
    throw new AppError(422, 'INVALID_HEADERS', `Usa estas columnas: ${expected.join(', ')}.`);
  const seen = new Set<string>();
  const rows: Record<string, unknown>[] = [];
  const errors: { row: number; message: string }[] = [];
  for (let index = 2; index <= sheet.rowCount; index++) {
    const row = sheet.getRow(index);
    if (!row.hasValues) continue;
    const input: Record<string, string | boolean> = { active: true };
    let invalid = false;
    headers.forEach((header, column) => {
      const cell = row.getCell(column + 1);
      if (cell.type === ExcelJS.ValueType.Formula || cell.type === ExcelJS.ValueType.Error) {
        invalid = true;
        return;
      }
      input[header] = cell.text.trim();
    });
    if (invalid) {
      errors.push({ row: index, message: 'No se admiten fórmulas ni celdas con errores.' });
      continue;
    }
    if (resource === 'insumos') {
      input.category_id =
        references?.categories.get(String(input.category_code).toUpperCase()) || '';
      input.unit_id = references?.units.get(String(input.unit_code).toLowerCase()) || '';
      if (!input.category_id || !input.unit_id) {
        errors.push({
          row: index,
          message: 'Categoría o unidad base no encontrada: revisa category_code y unit_code.',
        });
        continue;
      }
    }
    const parsed = catalogConfig[resource as Resource].schema.safeParse(input);
    if (!parsed.success) {
      errors.push({
        row: index,
        message: parsed.error.issues.map((x) => `${x.path.join('.')}: ${x.message}`).join('; '),
      });
      continue;
    }
    const data = parsed.data as Record<string, unknown>;
    const code = String(data.code);
    if (seen.has(code) || existingCodes.has(code)) {
      errors.push({ row: index, message: `Código duplicado: ${code}` });
      continue;
    }
    seen.add(code);
    rows.push(data);
  }
  if (!rows.length && !errors.length)
    throw new AppError(422, 'INVALID_FILE', 'No hay filas para importar.');
  return { rows, errors };
}
