export type Unit = { dimension: 'mass' | 'volume' | 'count'; factor: string };
export function scaledDecimal(value: string, scale: number): bigint {
  if (!/^[0-9]+(?:\.[0-9]+)?$/.test(value)) throw new Error('Cantidad no válida');
  const [whole, fraction = ''] = value.split('.');
  if (fraction.length > scale) throw new Error('Precisión no válida');
  return BigInt(whole + fraction.padEnd(scale, '0'));
}
function formatDecimal(value: bigint, scale: number) {
  const s = value.toString().padStart(scale + 1, '0');
  return `${s.slice(0, -scale)}.${s.slice(-scale)}`.replace(/\.?0+$/, '') || '0';
}
export function convertToBase(quantity: string, from: Unit, to: Unit) {
  if (from.dimension !== to.dimension || scaledDecimal(to.factor, 12) !== 10n ** 12n)
    throw new Error('Unidades incompatibles');
  const q = scaledDecimal(quantity, 6);
  if (q <= 0n) throw new Error('Cantidad debe ser positiva');
  const product = q * scaledDecimal(from.factor, 12);
  const divisor = 10n ** 12n;
  if (product % divisor !== 0n) throw new Error('Conversión supera seis decimales');
  const result = product / divisor;
  if (to.dimension === 'count' && result % 10n ** 6n !== 0n)
    throw new Error('La unidad requiere enteros');
  return formatDecimal(result, 6);
}
export function presentationQuantity(packages: string, content: string) {
  const product = scaledDecimal(packages, 6) * scaledDecimal(content, 6);
  const divisor = 10n ** 6n;
  if (product % divisor !== 0n) throw new Error('Precisión excedida');
  return formatDecimal(product / divisor, 6);
}
