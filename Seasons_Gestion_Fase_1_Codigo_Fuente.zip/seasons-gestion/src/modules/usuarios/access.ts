import 'server-only';
import { redirect } from 'next/navigation';
import { supabaseServer } from '@/lib/supabase/server';
import { getSupabaseConfig } from '@/lib/config';
import { AppError, databaseError } from '@/lib/errors';
import { z } from 'zod';
export const accessSchema = z.object({
  id: z.uuid(),
  full_name: z.string(),
  permissions: z.array(z.string()),
  warehouses: z.array(z.object({ id: z.uuid(), name: z.string(), code: z.string() })),
});
export type Access = z.infer<typeof accessSchema>;
export async function authenticate(writable = false) {
  const db = await supabaseServer(writable);
  const { data, error } = await db.auth.getUser();
  if (error || !data.user)
    throw new AppError(401, 'UNAUTHENTICATED', 'Inicia sesión para continuar.');
  const result = await db.rpc('current_access');
  if (result.error) databaseError(result.error);
  return { db, access: accessSchema.parse(result.data), email: data.user.email || '' };
}
export function authorize(access: Access, permission: string, warehouse?: string) {
  if (
    !access.permissions.includes(permission) ||
    (warehouse && !access.warehouses.some((w) => w.id === warehouse))
  )
    throw new AppError(403, 'FORBIDDEN', 'No tienes permiso para esta operación.');
}
export async function pageAccess(permission?: string) {
  if (!getSupabaseConfig()) redirect('/configuracion-inicial');
  try {
    const context = await authenticate();
    if (permission) authorize(context.access, permission);
    return context;
  } catch (e) {
    if (e instanceof AppError && (e.status === 401 || e.status === 403))
      redirect(e.status === 401 ? '/login' : '/sin-acceso');
    throw e;
  }
}
