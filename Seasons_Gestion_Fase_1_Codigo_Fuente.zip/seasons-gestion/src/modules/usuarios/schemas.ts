import { z } from 'zod';

export const userAccessSchema = z.object({
  id: z.uuid(),
  lock_version: z.number().int().positive(),
  active: z.boolean(),
  roles: z.array(z.uuid()).max(30),
  warehouses: z.array(z.uuid()).max(100),
  overrides: z
    .array(
      z.object({ permission_code: z.string().min(2).max(80), effect: z.enum(['allow', 'deny']) }),
    )
    .max(100),
});
