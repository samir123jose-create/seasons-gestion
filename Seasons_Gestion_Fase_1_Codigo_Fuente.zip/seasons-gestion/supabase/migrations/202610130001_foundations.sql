-- Fase 1. PostgreSQL >= 15 / Supabase. Ejecutar con dueño de migraciones.
begin;
create schema if not exists app_private;
revoke all on schema app_private from public;
grant usage on schema app_private to authenticated;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete restrict,
 full_name text not null check (length(trim(full_name)) between 2 and 120),
 active boolean not null default false,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 lock_version integer not null default 1
);
create table public.roles (id uuid primary key default gen_random_uuid(), code text not null unique, name text not null);
create table public.permissions (code text primary key, description text not null);
create table public.user_roles (user_id uuid references public.profiles(id) on delete restrict, role_id uuid references public.roles(id) on delete restrict, primary key(user_id,role_id));
create table public.role_permissions (role_id uuid references public.roles(id) on delete restrict, permission_code text references public.permissions(code) on delete restrict, primary key(role_id,permission_code));
create table public.user_permission_overrides (user_id uuid references public.profiles(id) on delete restrict, permission_code text references public.permissions(code) on delete restrict, effect text not null check(effect in ('allow','deny')), primary key(user_id,permission_code));
create table public.branches (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.warehouses (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), branch_id uuid references public.branches(id) on delete restrict, active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.user_warehouse_access (user_id uuid references public.profiles(id) on delete restrict, warehouse_id uuid references public.warehouses(id) on delete restrict, primary key(user_id,warehouse_id));
create table public.units (id uuid primary key default gen_random_uuid(), code text not null unique, name text not null, dimension text not null check(dimension in ('mass','volume','count')), factor numeric(24,12) not null check(factor > 0 and factor <> 'NaN'::numeric));
create table public.item_categories (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.suppliers (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), contact text not null default '' check(length(contact)<=160), phone text not null default '' check(length(phone)<=40), email text not null default '' check(length(email)<=254), tax_id text not null default '' check(length(tax_id)<=40), active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.items (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), category_id uuid not null references public.item_categories(id) on delete restrict, unit_id uuid not null references public.units(id) on delete restrict, item_type text not null default 'ingredient' check(item_type in ('ingredient','material','packaging')), active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.purchase_presentations (id uuid primary key default gen_random_uuid(), code text not null unique check(code ~ '^[A-Z0-9_-]{2,32}$'), name text not null check(length(trim(name)) between 2 and 120), item_id uuid not null references public.items(id) on delete restrict, unit_id uuid not null references public.units(id) on delete restrict, quantity numeric(20,6) not null check(quantity>0 and quantity<>'NaN'::numeric), base_quantity numeric(20,6) not null check(base_quantity>0 and base_quantity<>'NaN'::numeric), supplier_id uuid references public.suppliers(id) on delete restrict, active boolean not null default true, lock_version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.item_location_policies (item_id uuid references public.items(id) on delete restrict, warehouse_id uuid references public.warehouses(id) on delete restrict, minimum_stock numeric(20,6) not null default 0 check(minimum_stock>=0 and minimum_stock<>'NaN'::numeric), lot_required boolean not null default false, primary key(item_id,warehouse_id));
create table app_private.item_price_history (id uuid primary key default gen_random_uuid(), item_id uuid not null references public.items(id), presentation_id uuid not null references public.purchase_presentations(id), supplier_id uuid references public.suppliers(id), amount numeric(24,6) not null check(amount>=0 and amount<>'NaN'::numeric), base_quantity numeric(20,6) not null check(base_quantity>0), unit_cost numeric(24,10) not null, currency text not null default 'BOB' check(currency='BOB'), source text not null check(length(trim(source)) between 2 and 200), effective_date date not null, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now());
create table app_private.audit_logs (id bigint generated always as identity primary key, actor_id uuid references public.profiles(id), action text not null, entity text not null, entity_id uuid, before_data jsonb, after_data jsonb, created_at timestamptz not null default now());
create table public.import_jobs (id uuid primary key default gen_random_uuid(), created_by uuid not null references public.profiles(id), resource text not null check(resource in ('proveedores','categorias','insumos')), rows jsonb not null check(jsonb_typeof(rows)='array'), status text not null default 'preview' check(status in ('preview','confirmed')), created_at timestamptz not null default now(), confirmed_at timestamptz);

create function app_private.active_user() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.profiles where id=auth.uid() and active) $$;
create function app_private.has_permission(p_code text, p_warehouse uuid default null) returns boolean language sql stable security definer set search_path='' as $$
 select app_private.active_user()
 and not exists(select 1 from public.user_permission_overrides where user_id=auth.uid() and permission_code=p_code and effect='deny')
 and (exists(select 1 from public.user_permission_overrides where user_id=auth.uid() and permission_code=p_code and effect='allow') or exists(select 1 from public.user_roles ur join public.role_permissions rp on rp.role_id=ur.role_id where ur.user_id=auth.uid() and rp.permission_code=p_code))
 and (p_warehouse is null or exists(select 1 from public.user_warehouse_access where user_id=auth.uid() and warehouse_id=p_warehouse));
$$;
create function app_private.assert_permission(p_code text,p_warehouse uuid default null) returns void language plpgsql stable security definer set search_path='' as $$ begin
 if not app_private.has_permission(p_code,p_warehouse) then raise exception using errcode='42501',message='Acceso no autorizado'; end if;
end $$;
create function app_private.audit(p_action text,p_entity text,p_id uuid,p_before jsonb,p_after jsonb) returns void language sql security definer set search_path='' as $$ insert into app_private.audit_logs(actor_id,action,entity,entity_id,before_data,after_data) values(auth.uid(),p_action,p_entity,p_id,p_before,p_after) $$;
create function app_private.handle_auth_user() returns trigger language plpgsql security definer set search_path='' as $$ begin
 insert into public.profiles(id,full_name) values(new.id,coalesce(nullif(left(trim(new.raw_user_meta_data->>'full_name'),120),''),'Usuario Seasons')); return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function app_private.handle_auth_user();

create function app_private.validate_item() returns trigger language plpgsql set search_path='' as $$ begin
 if not exists(select 1 from public.units where id=new.unit_id and factor=1) then raise exception using errcode='23514',message='Usar g, ml o unidad como unidad base'; end if;
 if TG_OP='UPDATE' and new.unit_id<>old.unit_id then raise exception using errcode='23514',message='La unidad base es inmutable: crear otro insumo'; end if;
 return new;
end $$;
create trigger validate_item before insert or update on public.items for each row execute function app_private.validate_item();
create function app_private.validate_presentation() returns trigger language plpgsql set search_path='' as $$ declare dim text; base_dim text; multiplier numeric; begin
 select dimension,factor into dim,multiplier from public.units where id=new.unit_id;
 select u.dimension into base_dim from public.items i join public.units u on u.id=i.unit_id where i.id=new.item_id;
 if dim is distinct from base_dim then raise exception using errcode='23514',message='Unidades incompatibles'; end if;
 if TG_OP='UPDATE' and (new.item_id<>old.item_id or new.unit_id<>old.unit_id or new.quantity<>old.quantity or new.supplier_id is distinct from old.supplier_id) then raise exception using errcode='23514',message='Presentación inmutable: desactivar y crear otra'; end if;
 new.base_quantity:=new.quantity*multiplier; return new;
end $$;
create trigger validate_presentation before insert or update on public.purchase_presentations for each row execute function app_private.validate_presentation();

-- Lectura protegida; mutaciones exclusivamente por funciones con validación y auditoría.
alter table public.profiles enable row level security;
create policy profile_read on public.profiles for select to authenticated using (app_private.active_user() and (id=auth.uid() or app_private.has_permission('usuarios.manage')));
DO $$ declare t text; begin
 foreach t in array array['roles','permissions','user_roles','role_permissions','user_permission_overrides','user_warehouse_access'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('create policy admin_read on public.%I for select to authenticated using (app_private.has_permission(''usuarios.manage''))',t);
 end loop;
 foreach t in array array['units','item_categories','items','purchase_presentations'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('create policy catalog_read on public.%I for select to authenticated using (app_private.has_permission(''catalogos.read'') or app_private.has_permission(''insumos.manage''))',t);
 end loop;
end $$;
alter table public.suppliers enable row level security;
create policy supplier_read on public.suppliers for select to authenticated using(app_private.has_permission('catalogos.read') or app_private.has_permission('proveedores.manage'));
alter table public.warehouses enable row level security;
create policy warehouse_read on public.warehouses for select to authenticated using(app_private.has_permission('ubicaciones.manage') or (app_private.active_user() and exists(select 1 from public.user_warehouse_access where user_id=auth.uid() and warehouse_id=warehouses.id)));
-- La subconsulta de acceso usa función definer para evitar RLS recursiva.
drop policy warehouse_read on public.warehouses;
create function app_private.can_access_warehouse(p_id uuid) returns boolean language sql stable security definer set search_path='' as $$ select app_private.active_user() and exists(select 1 from public.user_warehouse_access where user_id=auth.uid() and warehouse_id=p_id) $$;
create policy warehouse_read on public.warehouses for select to authenticated using(app_private.has_permission('ubicaciones.manage') or app_private.can_access_warehouse(id));
alter table public.branches enable row level security;
create policy branch_read on public.branches for select to authenticated using(app_private.has_permission('ubicaciones.manage') or exists(select 1 from public.warehouses where branch_id=branches.id));
alter table public.item_location_policies enable row level security;
create policy item_policy_read on public.item_location_policies for select to authenticated using(app_private.has_permission('inventario.read',warehouse_id));
alter table public.import_jobs enable row level security;
create policy import_read on public.import_jobs for select to authenticated using(created_by=auth.uid() and app_private.has_permission('importaciones.manage'));

create view public.api_units with (security_invoker=true) as select id,code,name,dimension,factor::text from public.units;
create view public.api_presentations with (security_invoker=true) as select id,code,name,item_id,unit_id,quantity::text,base_quantity::text,supplier_id,active,lock_version,created_at,updated_at from public.purchase_presentations;

grant select on public.profiles,public.roles,public.permissions,public.user_roles,public.role_permissions,public.user_permission_overrides,public.user_warehouse_access,public.branches,public.warehouses,public.units,public.item_categories,public.items,public.purchase_presentations,public.item_location_policies,public.import_jobs,public.api_units,public.api_presentations to authenticated;
revoke insert,update,delete on public.profiles,public.roles,public.permissions,public.user_roles,public.role_permissions,public.user_permission_overrides,public.user_warehouse_access,public.branches,public.warehouses,public.units,public.item_categories,public.items,public.purchase_presentations,public.item_location_policies,public.import_jobs from anon,authenticated;
revoke all on all tables in schema app_private from anon,authenticated;
revoke all on all functions in schema app_private from public,anon,authenticated;
grant execute on function app_private.active_user(),app_private.has_permission(text,uuid),app_private.can_access_warehouse(uuid) to authenticated;

create function public.current_access() returns jsonb language plpgsql stable security definer set search_path='' as $$ declare result jsonb; begin
 if not app_private.active_user() then raise exception using errcode='42501',message='Cuenta inactiva'; end if;
 select jsonb_build_object('id',p.id,'full_name',p.full_name,'permissions',(select coalesce(jsonb_agg(code),'[]') from public.permissions where app_private.has_permission(code)),'warehouses',(select coalesce(jsonb_agg(jsonb_build_object('id',w.id,'name',w.name,'code',w.code)),'[]') from public.warehouses w join public.user_warehouse_access a on a.warehouse_id=w.id where a.user_id=p.id and w.active)) into result from public.profiles p where id=auth.uid();
 return result;
end $$;

create function public.manage_catalog(p_resource text,p_id uuid,p_data jsonb,p_version integer default null) returns jsonb language plpgsql security definer set search_path='' as $$
declare target text; required text; before_row jsonb; after_row jsonb; result_id uuid; column_list text; value_list text;
begin
 case p_resource
 when 'sucursales' then target:='branches';required:='ubicaciones.manage';
 when 'almacenes' then target:='warehouses';required:='ubicaciones.manage';
 when 'proveedores' then target:='suppliers';required:='proveedores.manage';
 when 'categorias' then target:='item_categories';required:='insumos.manage';
 when 'insumos' then target:='items';required:='insumos.manage';
 when 'presentaciones' then target:='purchase_presentations';required:='insumos.manage';
 else raise exception using errcode='22023',message='Recurso inválido'; end case;
 perform app_private.assert_permission(required);
 if p_data is null or jsonb_typeof(p_data)<>'object' then raise exception using errcode='22023',message='Datos inválidos'; end if;
 if p_resource='presentaciones' and (p_data->>'quantity' is null or p_data->>'quantity' !~ '^[0-9]{1,14}(\.[0-9]{1,6})?$') then raise exception using errcode='22023',message='Contenido inválido'; end if;
 if p_id is not null then
 execute format('select to_jsonb(t) from public.%I t where id=$1 for update',target) into before_row using p_id;
 if before_row is null then raise exception using errcode='P0002',message='No encontrado'; end if;
 if p_version is null or (before_row->>'lock_version')::int<>p_version then raise exception using errcode='40001',message='El registro cambió; actualiza la página'; end if;
 -- Solo desactivación/edición de atributos seguros; DTO completo necesario.
 end if;
 result_id:=coalesce(p_id,gen_random_uuid());
 -- Nombres SQL y columnas proceden exclusivamente de esta lista fija.
 column_list:='code,name,active';value_list:='upper(trim($2->>''code'')),trim($2->>''name''),coalesce(($2->>''active'')::boolean,true)';
 case p_resource
 when 'almacenes' then column_list:=column_list||',branch_id';value_list:=value_list||',nullif($2->>''branch_id'','''')::uuid';
 when 'proveedores' then column_list:=column_list||',contact,phone,email,tax_id';value_list:=value_list||',coalesce($2->>''contact'',''''),coalesce($2->>''phone'',''''),coalesce($2->>''email'',''''),coalesce($2->>''tax_id'','''')';
 when 'insumos' then column_list:=column_list||',category_id,unit_id,item_type';value_list:=value_list||',($2->>''category_id'')::uuid,($2->>''unit_id'')::uuid,coalesce($2->>''item_type'',''ingredient'')';
 when 'presentaciones' then column_list:=column_list||',item_id,unit_id,quantity,base_quantity,supplier_id';value_list:=value_list||',($2->>''item_id'')::uuid,($2->>''unit_id'')::uuid,($2->>''quantity'')::numeric,1,nullif($2->>''supplier_id'','''')::uuid';
 else null; end case;
 if p_id is null then
 execute format('insert into public.%I(id,%s) select $1,%s returning to_jsonb(%I.*)',target,column_list,value_list,target) into after_row using result_id,p_data;
 else
 execute format('update public.%I set (%s)=(select %s),lock_version=lock_version+1,updated_at=now() where id=$1 returning to_jsonb(%I.*)',target,column_list,value_list,target) into after_row using result_id,p_data;
 end if;
 if p_resource='almacenes' and p_id is null then insert into public.user_warehouse_access(user_id,warehouse_id) values(auth.uid(),result_id) on conflict do nothing; end if;
 perform app_private.audit(case when p_id is null then 'create' else 'update' end,p_resource,result_id,before_row,after_row);
 if p_resource='presentaciones' then after_row:=after_row||jsonb_build_object('quantity',after_row->>'quantity','base_quantity',after_row->>'base_quantity'); end if;
 return after_row;
end $$;

create function public.manage_user_access(p_user uuid,p_version integer,p_active boolean,p_roles uuid[],p_warehouses uuid[],p_overrides jsonb default '[]') returns void language plpgsql security definer set search_path='' as $$ declare before_row jsonb; o jsonb; begin
 perform app_private.assert_permission('usuarios.manage');
 if p_user=auth.uid() then raise exception using errcode='23514',message='No modificar tus propios permisos'; end if;
 select to_jsonb(p) into before_row from public.profiles p where id=p_user for update;
 if before_row is null then raise exception using errcode='P0002',message='No encontrado'; end if;
 if (before_row->>'lock_version')::int<>p_version then raise exception using errcode='40001',message='El usuario cambió'; end if;
 if p_roles is null or p_warehouses is null or jsonb_typeof(p_overrides)<>'array' then raise exception using errcode='22023',message='Asignación inválida'; end if;
 before_row:=before_row||jsonb_build_object('roles',(select coalesce(jsonb_agg(role_id),'[]') from public.user_roles where user_id=p_user),'warehouses',(select coalesce(jsonb_agg(warehouse_id),'[]') from public.user_warehouse_access where user_id=p_user),'overrides',(select coalesce(jsonb_agg(jsonb_build_object('permission_code',permission_code,'effect',effect)),'[]') from public.user_permission_overrides where user_id=p_user));
 update public.profiles set active=p_active,lock_version=lock_version+1,updated_at=now() where id=p_user;
 delete from public.user_roles where user_id=p_user; insert into public.user_roles select p_user,x from unnest(p_roles) x;
 delete from public.user_warehouse_access where user_id=p_user; insert into public.user_warehouse_access select p_user,x from unnest(p_warehouses) x;
 delete from public.user_permission_overrides where user_id=p_user;
 for o in select value from jsonb_array_elements(p_overrides) loop insert into public.user_permission_overrides values(p_user,o->>'permission_code',o->>'effect'); end loop;
 perform app_private.audit('access.update','usuarios',p_user,before_row,jsonb_build_object('active',p_active,'roles',p_roles,'warehouses',p_warehouses,'overrides',p_overrides));
end $$;
create function public.manage_role_permissions(p_role uuid,p_codes text[]) returns void language plpgsql security definer set search_path='' as $$ begin
 perform app_private.assert_permission('usuarios.manage');
 if exists(select 1 from public.user_roles where user_id=auth.uid() and role_id=p_role) then raise exception using errcode='23514',message='No modificar un rol asignado a tu propia cuenta'; end if;
 perform 1 from public.roles where id=p_role for update; if not found then raise exception using errcode='P0002',message='Rol no encontrado'; end if;
 if p_codes is null then raise exception using errcode='22023',message='Permisos inválidos'; end if;
 delete from public.role_permissions where role_id=p_role;
 insert into public.role_permissions select p_role,x from unnest(p_codes) x;
 perform app_private.audit('role.permissions','roles',p_role,null,to_jsonb(p_codes));
end $$;
create function public.record_price(p_presentation uuid,p_amount text,p_date date,p_source text) returns uuid language plpgsql security definer set search_path='' as $$ declare pres public.purchase_presentations; r uuid; amount numeric; begin
 perform app_private.assert_permission('insumos.manage'); perform app_private.assert_permission('costos.read');
 select * into pres from public.purchase_presentations where id=p_presentation and active;
 if not found then raise exception using errcode='P0002',message='Presentación no disponible'; end if;
 if p_amount !~ '^[0-9]{1,18}(\.[0-9]{1,6})?$' then raise exception using errcode='22023',message='Importe inválido'; end if; amount:=p_amount::numeric;
 insert into app_private.item_price_history(item_id,presentation_id,supplier_id,amount,base_quantity,unit_cost,source,effective_date,created_by) values(pres.item_id,pres.id,pres.supplier_id,amount,pres.base_quantity,round(amount/pres.base_quantity,10),p_source,p_date,auth.uid()) returning id into r;
 perform app_private.audit('price.record','precios',r,null,jsonb_build_object('amount',p_amount,'source',p_source,'date',p_date,'presentation_id',pres.id)); return r;
end $$;
create function public.price_history() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin
 perform app_private.assert_permission('costos.read');
 return (select coalesce(jsonb_agg(t),'[]') from (select id,item_id,presentation_id,supplier_id,amount::text,base_quantity::text,unit_cost::text,currency,source,effective_date from app_private.item_price_history order by effective_date desc,created_at desc limit 500) t);
end $$;
create function public.audit_history() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin
 perform app_private.assert_permission('usuarios.manage');
 -- No exponer payloads monetarios a un administrador sin costos.read.
 return (select coalesce(jsonb_agg(t),'[]') from (select id::text,actor_id,action,entity,entity_id,created_at from app_private.audit_logs order by id desc limit 200) t);
end $$;
create function public.preview_import(p_resource text,p_rows jsonb) returns uuid language plpgsql security definer set search_path='' as $$ declare r uuid; begin
 perform app_private.assert_permission('importaciones.manage');
 perform app_private.assert_permission(case when p_resource='proveedores' then 'proveedores.manage' else 'insumos.manage' end);
 if p_rows is null or jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows) not between 1 and 1000 then raise exception using errcode='22023',message='Importación inválida'; end if;
 insert into public.import_jobs(created_by,resource,rows) values(auth.uid(),p_resource,p_rows) returning id into r;return r;
end $$;
create function public.confirm_import(p_job uuid) returns jsonb language plpgsql security definer set search_path='' as $$ declare job public.import_jobs; row jsonb; n integer:=0; begin
 perform app_private.assert_permission('importaciones.manage');
 select * into job from public.import_jobs where id=p_job and created_by=auth.uid() for update;
 if not found then raise exception using errcode='P0002',message='Importación no encontrada'; end if;
 perform app_private.assert_permission(case when job.resource='proveedores' then 'proveedores.manage' else 'insumos.manage' end);
 if job.status='confirmed' then return jsonb_build_object('id',p_job,'count',jsonb_array_length(job.rows),'status','confirmed'); end if;
 for row in select value from jsonb_array_elements(job.rows) loop perform public.manage_catalog(job.resource,null,row,null); n:=n+1; end loop;
 update public.import_jobs set status='confirmed',confirmed_at=now() where id=p_job;
 perform app_private.audit('import.confirm','importaciones',p_job,null,jsonb_build_object('count',n));return jsonb_build_object('id',p_job,'count',n,'status','confirmed');
end $$;

-- Catálogos iniciales reales de ubicaciones y unidades; no contienen stock o precios ficticios.
insert into public.branches(code,name) values ('MEGA-MALL','Seasons Mega Mall'),('MURILLO','Seasons Av. Murillo');
insert into public.warehouses(code,name,branch_id) select code,name,id from public.branches;
insert into public.warehouses(code,name) values('CENTRAL','Depósito central');
insert into public.units(code,name,dimension,factor) values('g','Gramo','mass',1),('kg','Kilogramo','mass',1000),('ml','Mililitro','volume',1),('l','Litro','volume',1000),('unidad','Unidad','count',1);
insert into public.permissions(code,description) values
('catalogos.read','Consultar catálogos'),('insumos.manage','Gestionar insumos, categorías, presentaciones y precios'),('proveedores.manage','Gestionar proveedores'),('ubicaciones.manage','Gestionar sucursales y almacenes'),('usuarios.manage','Gestionar usuarios, roles y permisos'),('inventario.read','Ver stock de ubicaciones asignadas'),('inventario.opening','Confirmar apertura de inventario'),('costos.read','Consultar costos y precios'),('importaciones.manage','Importar catálogos Excel'),('recetas.read','Consultar recetas publicadas'),('recetas.manage','Editar/publicar recetas'),('inventario.count','Registrar conteos'),('inventario.adjust','Autorizar ajustes'),('solicitudes.create','Solicitar insumos'),('solicitudes.approve','Aprobar solicitudes'),('reportes.read','Descargar reportes'),('produccion.confirm','Confirmar producción');
insert into public.roles(code,name) values('administrador','Administrador'),('deposito','Encargado de depósito'),('sucursal','Encargado de sucursal'),('colaborador','Colaborador');
insert into public.role_permissions select r.id,p.code from public.roles r cross join public.permissions p where r.code='administrador';
-- Solo permisos mínimos explícitos de recetas/solicitudes; stock/costos/conteos requieren asignación.
insert into public.role_permissions select r.id,p.code from public.roles r cross join public.permissions p where r.code<>'administrador' and p.code in ('recetas.read','solicitudes.create');

create function public.bootstrap_admin(p_user uuid) returns void language plpgsql security definer set search_path='' as $$ begin
 if current_setting('request.jwt.claim.role',true) is distinct from 'service_role' and coalesce(current_setting('request.jwt.claims',true),'{}')::jsonb->>'role' is distinct from 'service_role' then raise exception using errcode='42501',message='Solo provisión administrativa'; end if;
 perform pg_advisory_xact_lock(hashtextextended('seasons:bootstrap-admin',0));
 if exists(select 1 from public.profiles p join public.user_roles ur on ur.user_id=p.id join public.role_permissions rp on rp.role_id=ur.role_id where p.active and rp.permission_code='usuarios.manage') then raise exception using errcode='23514',message='El administrador inicial ya existe'; end if;
 update public.profiles set active=true where id=p_user; if not found then raise exception using errcode='P0002',message='Crear primero usuario en Auth'; end if;
 insert into public.user_roles select p_user,id from public.roles where code='administrador';
 insert into public.user_warehouse_access select p_user,id from public.warehouses;
 insert into app_private.audit_logs(actor_id,action,entity,entity_id) values(p_user,'bootstrap','usuarios',p_user);
end $$;
revoke all on function public.current_access(),public.manage_catalog(text,uuid,jsonb,integer),public.manage_user_access(uuid,integer,boolean,uuid[],uuid[],jsonb),public.manage_role_permissions(uuid,text[]),public.record_price(uuid,text,date,text),public.price_history(),public.audit_history(),public.preview_import(text,jsonb),public.confirm_import(uuid),public.bootstrap_admin(uuid) from public,anon,authenticated;
grant execute on function public.current_access(),public.manage_catalog(text,uuid,jsonb,integer),public.manage_user_access(uuid,integer,boolean,uuid[],uuid[],jsonb),public.manage_role_permissions(uuid,text[]),public.record_price(uuid,text,date,text),public.price_history(),public.audit_history(),public.preview_import(text,jsonb),public.confirm_import(uuid) to authenticated;
grant execute on function public.bootstrap_admin(uuid) to service_role;

create index items_category on public.items(category_id);
create index warehouses_branch on public.warehouses(branch_id);
create index warehouse_users on public.user_warehouse_access(warehouse_id,user_id);
create index user_role_roles on public.user_roles(role_id,user_id);
create index role_permission_code on public.role_permissions(permission_code,role_id);
create index prices_item_date on app_private.item_price_history(item_id,effective_date desc);
create index audit_date on app_private.audit_logs(created_at desc);
commit;
