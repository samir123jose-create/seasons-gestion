begin;
create table app_private.inventory_operations(id uuid primary key default gen_random_uuid(), kind text not null check(kind in ('opening','consumption','production','receipt','transfer','adjustment')), actor_id uuid not null references public.profiles(id), idempotency_key uuid not null, payload_hash text not null, created_at timestamptz not null default now(), unique(actor_id,idempotency_key));
create table app_private.inventory_movements(id uuid primary key default gen_random_uuid(), operation_id uuid not null references app_private.inventory_operations(id), warehouse_id uuid not null references public.warehouses(id), item_id uuid not null references public.items(id), quantity numeric(20,6) not null check(quantity<>0 and quantity<>'NaN'::numeric), value numeric(24,6) not null check(value<>'NaN'::numeric), unit_cost numeric(24,10) not null check(unit_cost>=0 and unit_cost<>'NaN'::numeric), created_at timestamptz not null default now());
create table app_private.stock_balances(warehouse_id uuid references public.warehouses(id), item_id uuid references public.items(id), quantity numeric(20,6) not null default 0 check(quantity>=0 and quantity<>'NaN'::numeric), value numeric(24,6) not null default 0 check(value>=0 and value<>'NaN'::numeric), average_cost numeric(24,10) not null default 0 check(average_cost>=0 and average_cost<>'NaN'::numeric), primary key(warehouse_id,item_id));
create table app_private.inventory_opening_documents(id uuid primary key default gen_random_uuid(), warehouse_id uuid not null unique references public.warehouses(id), operation_id uuid not null unique references app_private.inventory_operations(id), created_by uuid not null references public.profiles(id), created_at timestamptz not null default now());
create index movements_lookup on app_private.inventory_movements(warehouse_id,item_id,created_at);
create index movements_operation on app_private.inventory_movements(operation_id);
revoke all on all tables in schema app_private from anon,authenticated;

-- Puerto interno: no se concede ejecución a clientes. Casos de uso posteriores lo invocarán
-- tras comprobar permiso, documento fuente y transición. Todas las líneas son atómicas.
create function app_private.apply_inventory(p_kind text,p_key uuid,p_lines jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare op uuid; old_op app_private.inventory_operations; line jsonb; q numeric; delta_value numeric; b app_private.stock_balances; w uuid; item uuid; h text;
begin
 if not app_private.active_user() then raise exception using errcode='42501',message='Cuenta inactiva'; end if;
 if p_key is null or p_lines is null or jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines) not between 1 and 1000 then raise exception using errcode='22023',message='Operación inválida'; end if;
 if exists(select 1 from jsonb_array_elements(p_lines) l group by l->>'warehouse_id',l->>'item_id' having count(*)>1) then raise exception using errcode='22023',message='Líneas duplicadas'; end if;
 h:=encode(sha256(convert_to(jsonb_build_object('kind',p_kind,'lines',p_lines)::text,'UTF8')),'hex');
 -- Serializa reintentos por actor/clave antes de comprobar estado; lock de transacción.
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text||':'||p_key::text,0));
 select * into old_op from app_private.inventory_operations where actor_id=auth.uid() and idempotency_key=p_key;
 if found then
 if old_op.payload_hash<>h then raise exception using errcode='40001',message='Clave reutilizada con datos diferentes'; end if;return old_op.id;
 end if;
 insert into app_private.inventory_operations(kind,actor_id,idempotency_key,payload_hash) values(p_kind,auth.uid(),p_key,h) returning id into op;
 for line in select l from jsonb_array_elements(p_lines) l order by l->>'warehouse_id',l->>'item_id' loop
 w:=(line->>'warehouse_id')::uuid;item:=(line->>'item_id')::uuid;
 if line->>'quantity' is null or line->>'quantity' !~ '^-?[0-9]{1,14}(\.[0-9]{1,6})?$' then raise exception using errcode='22023',message='Cantidad inválida'; end if;
 q:=(line->>'quantity')::numeric;
 if q=0 then raise exception using errcode='23514',message='Cantidad cero'; end if;
 if not exists(select 1 from public.items where id=item and active) or not exists(select 1 from public.warehouses where id=w and active) then raise exception using errcode='23514',message='Insumo/almacén inactivo'; end if;
 if not app_private.can_access_warehouse(w) then raise exception using errcode='42501',message='Ubicación no asignada'; end if;
 -- Unidades discretas no admiten fracciones.
 if exists(select 1 from public.items i join public.units u on u.id=i.unit_id where i.id=item and u.dimension='count') and q<>trunc(q) then raise exception using errcode='23514',message='La unidad requiere cantidades enteras'; end if;
 insert into app_private.stock_balances(warehouse_id,item_id) values(w,item) on conflict do nothing;
 select * into b from app_private.stock_balances where warehouse_id=w and item_id=item for update;
 if b.quantity+q<0 then raise exception using errcode='23514',message='Stock insuficiente'; end if;
 if q>0 then
 if line->>'value' is null or line->>'value' !~ '^[0-9]{1,18}(\.[0-9]{1,6})?$' then raise exception using errcode='22023',message='Valor de entrada requerido'; end if;
 delta_value:=(line->>'value')::numeric;
 else
 -- La última salida absorbe el residuo decimal y deja cantidad y valor en cero.
 delta_value:=case when b.quantity+q=0 then -b.value else round(q*b.average_cost,6) end;
 end if;
 update app_private.stock_balances set quantity=b.quantity+q,value=b.value+delta_value,average_cost=case when b.quantity+q=0 then 0 when q>0 then round((b.value+delta_value)/(b.quantity+q),10) else b.average_cost end where warehouse_id=w and item_id=item;
 insert into app_private.inventory_movements(operation_id,warehouse_id,item_id,quantity,value,unit_cost) values(op,w,item,q,delta_value,case when q>0 then round(delta_value/q,10) else b.average_cost end);
 end loop;
 perform app_private.audit('inventory.confirm',p_kind,op,null,jsonb_build_object('line_count',jsonb_array_length(p_lines)));
 return op;
end $$;
revoke all on function app_private.apply_inventory(text,uuid,jsonb) from public,anon,authenticated;

create function public.confirm_inventory_opening(p_warehouse uuid,p_key uuid,p_lines jsonb) returns uuid language plpgsql security definer set search_path='' as $$ declare normalized jsonb; op uuid; existing app_private.inventory_opening_documents; begin
 perform app_private.assert_permission('inventario.opening',p_warehouse); perform app_private.assert_permission('costos.read');
 -- Evita que dos aperturas distintas se confirmen para el mismo almacén.
 perform pg_advisory_xact_lock(hashtextextended('opening:'||p_warehouse::text,0));
 if p_lines is null or jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines) not between 1 and 1000 then raise exception using errcode='22023',message='Apertura inválida'; end if;
 if exists(select 1 from jsonb_array_elements(p_lines) l where l->>'quantity' is null or l->>'quantity' !~ '^[0-9]{1,14}(\.[0-9]{1,6})?$' or (l->>'quantity')::numeric<=0) then raise exception using errcode='23514',message='Apertura requiere cantidades positivas'; end if;
 if exists(select 1 from app_private.inventory_opening_documents where warehouse_id=p_warehouse) and not exists(select 1 from app_private.inventory_opening_documents d join app_private.inventory_operations o on o.id=d.operation_id where d.warehouse_id=p_warehouse and o.actor_id=auth.uid() and o.idempotency_key=p_key) then raise exception using errcode='23514',message='El almacén ya tiene apertura'; end if;
 if not exists(select 1 from app_private.inventory_opening_documents where warehouse_id=p_warehouse) and exists(select 1 from app_private.stock_balances where warehouse_id=p_warehouse and quantity<>0) then raise exception using errcode='23514',message='Almacén con movimientos previos'; end if;
 select jsonb_agg(l||jsonb_build_object('warehouse_id',p_warehouse) order by l->>'item_id') into normalized from jsonb_array_elements(p_lines) l;
 op:=app_private.apply_inventory('opening',p_key,normalized);
 insert into app_private.inventory_opening_documents(warehouse_id,operation_id,created_by) values(p_warehouse,op,auth.uid()) on conflict(warehouse_id) do nothing;
 return op;
end $$;
create function public.inventory_balances(p_warehouse uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$ begin
 perform app_private.assert_permission('inventario.read',p_warehouse);
 return (select coalesce(jsonb_agg(jsonb_build_object('item_id',b.item_id,'quantity',b.quantity::text)||case when app_private.has_permission('costos.read',p_warehouse) then jsonb_build_object('value',b.value::text,'average_cost',b.average_cost::text,'currency','BOB') else '{}'::jsonb end),'[]') from app_private.stock_balances b where warehouse_id=p_warehouse);
end $$;
create function public.set_item_minimum(p_item uuid,p_warehouse uuid,p_minimum text) returns void language plpgsql security definer set search_path='' as $$ begin
 perform app_private.assert_permission('insumos.manage',p_warehouse);
 if p_minimum !~ '^[0-9]{1,14}(\.[0-9]{1,6})?$' then raise exception using errcode='22023',message='Mínimo inválido'; end if;
 insert into public.item_location_policies(item_id,warehouse_id,minimum_stock) values(p_item,p_warehouse,p_minimum::numeric) on conflict(item_id,warehouse_id) do update set minimum_stock=excluded.minimum_stock;
 perform app_private.audit('minimum.set','insumos',p_item,null,jsonb_build_object('warehouse_id',p_warehouse,'minimum',p_minimum));
end $$;
revoke all on function public.confirm_inventory_opening(uuid,uuid,jsonb),public.inventory_balances(uuid),public.set_item_minimum(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.confirm_inventory_opening(uuid,uuid,jsonb),public.inventory_balances(uuid),public.set_item_minimum(uuid,uuid,text) to authenticated;
commit;
