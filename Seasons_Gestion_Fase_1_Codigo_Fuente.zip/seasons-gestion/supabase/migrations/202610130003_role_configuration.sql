begin;
alter table public.roles add column lock_version integer not null default 1;
drop function public.manage_role_permissions(uuid,text[]);
create function public.manage_role_permissions(p_role uuid,p_version integer,p_codes text[]) returns void language plpgsql security definer set search_path='' as $$ begin
 perform app_private.assert_permission('usuarios.manage');
 if exists(select 1 from public.user_roles where user_id=auth.uid() and role_id=p_role) then raise exception using errcode='23514',message='No modificar un rol asignado a tu propia cuenta'; end if;
 perform 1 from public.roles where id=p_role and lock_version=p_version for update; if not found then raise exception using errcode='40001',message='El rol cambió'; end if;
 if p_codes is null then raise exception using errcode='22023',message='Permisos inválidos'; end if;
 perform app_private.audit('role.permissions','roles',p_role,(select coalesce(jsonb_agg(permission_code),'[]') from public.role_permissions where role_id=p_role),to_jsonb(p_codes));
 delete from public.role_permissions where role_id=p_role;
 insert into public.role_permissions select p_role,x from unnest(p_codes) x;
 update public.roles set lock_version=lock_version+1 where id=p_role;
end $$;
create function public.create_role(p_code text,p_name text) returns uuid language plpgsql security definer set search_path='' as $$ declare r uuid; begin
 perform app_private.assert_permission('usuarios.manage');
 if p_code !~ '^[a-z0-9_-]{2,32}$' or length(trim(p_name)) not between 2 and 120 then raise exception using errcode='22023',message='Datos de rol inválidos'; end if;
 insert into public.roles(code,name) values(p_code,trim(p_name)) returning id into r;
 perform app_private.audit('role.create','roles',r,null,jsonb_build_object('name',p_name,'code',p_code));return r;
end $$;
revoke all on function public.manage_role_permissions(uuid,integer,text[]),public.create_role(text,text) from public,anon,authenticated;
grant execute on function public.manage_role_permissions(uuid,integer,text[]),public.create_role(text,text) to authenticated;
-- Bucket privado; los permisos de archivos se añadirán con los vínculos a documentos en F2/F3.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('seasons-assets','seasons-assets',false,5242880,array['image/jpeg','image/png','image/webp','application/pdf']) on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
commit;
