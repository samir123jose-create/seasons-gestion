import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { CatalogManager } from '../../src/components/forms/catalog-manager';
import { AuthForm } from '../../src/components/forms/auth-form';
vi.mock('next/navigation', () => ({ useRouter: () => ({ push: vi.fn(), refresh: vi.fn() }) }));
HTMLDialogElement.prototype.showModal = function () {
  this.setAttribute('open', '');
};
const initial = { rows: [], total: 0, page: 1, pageSize: 25 };
describe('Formularios y permisos de interfaz', () => {
  it('ofrece vacío honesto y oculta creación al lector', () => {
    render(
      <CatalogManager resource="categorias" initial={initial} lookups={{}} canManage={false} />,
    );
    expect(screen.getByText('Tu catálogo está listo para comenzar')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Nueva categoría' })).not.toBeInTheDocument();
  });
  it('muestra error de persistencia y conserva el formulario', async () => {
    vi.stubGlobal(
      'fetch',
      vi
        .fn()
        .mockResolvedValue({
          ok: false,
          json: async () => ({ error: { message: 'El código ya existe.' } }),
        }),
    );
    render(<CatalogManager resource="categorias" initial={initial} lookups={{}} canManage />);
    fireEvent.click(screen.getByRole('button', { name: 'Nueva categoría' }));
    fireEvent.change(screen.getByLabelText('Código'), { target: { value: 'CAFE' } });
    fireEvent.change(screen.getByLabelText('Nombre'), { target: { value: 'Café' } });
    fireEvent.submit(screen.getByRole('button', { name: 'Guardar' }).closest('form')!);
    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('ya existe'));
    expect(screen.getByLabelText('Nombre')).toHaveValue('Café');
    vi.unstubAllGlobals();
  });
  it('deshabilita autenticación cuando no hay conexión configurada', () => {
    render(<AuthForm mode="login" configured={false} />);
    expect(screen.getByRole('button', { name: 'Iniciar sesión' })).toBeDisabled();
    expect(screen.getByLabelText('Correo electrónico')).toBeDisabled();
  });
});
