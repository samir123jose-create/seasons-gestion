create role anon nologin;
create role authenticated nologin;
create role service_role nologin bypassrls;
create role supabase_auth_admin login password 'seasons-e2e-test';
create schema auth authorization supabase_auth_admin;
alter role supabase_auth_admin set search_path=auth,public;
grant create on database seasons_e2e to supabase_auth_admin;
grant usage on schema public,auth to authenticated,anon,service_role;
create function auth.uid() returns uuid language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb->>'sub')::uuid $$;
alter function auth.uid() owner to supabase_auth_admin;
grant execute on function auth.uid() to authenticated,anon,service_role;
-- Solo metadata del bucket: el servicio Storage no está en este harness Auth/API.
create schema storage;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
