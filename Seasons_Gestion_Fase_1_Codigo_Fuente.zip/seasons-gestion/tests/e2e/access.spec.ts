import { test, expect } from '@playwright/test';
test('inicio responde sin fingir conexión y tiene navegación accesible', async ({ page }) => {
  await page.goto('/');
  if (process.env.NEXT_PUBLIC_SUPABASE_URL) {
    await expect(page).toHaveURL(/login/);
    await expect(page.getByRole('button', { name: 'Iniciar sesión' })).toBeEnabled();
  } else {
    await expect(page.getByRole('heading', { name: /La base de cada/ })).toBeVisible();
    await page.getByRole('link', { name: 'Ir a inicio de sesión' }).click();
    await expect(page.getByRole('button', { name: 'Iniciar sesión' })).toBeDisabled();
  }
  await expect(page.locator('html')).toHaveAttribute('lang', 'es');
  await expect(page.locator('body')).toHaveJSProperty(
    'scrollWidth',
    await page.locator('body').evaluate((e) => e.clientWidth),
  );
});
test('rutas administrativas y API requieren acceso real', async ({ page, request }) => {
  await page.goto('/admin/catalogos/insumos');
  await expect(page).toHaveURL(
    process.env.NEXT_PUBLIC_SUPABASE_URL ? /login/ : /configuracion-inicial/,
  );
  const r = await request.get('/api/v1/catalogos/insumos');
  expect(r.status()).toBe(process.env.NEXT_PUBLIC_SUPABASE_URL ? 401 : 503);
  expect((await r.json()).error.code).toBe(
    process.env.NEXT_PUBLIC_SUPABASE_URL ? 'UNAUTHENTICATED' : 'SETUP_REQUIRED',
  );
});
test('mutaciones de origen ajeno se rechazan antes de autenticación', async ({ request }) => {
  const r = await request.post('/api/v1/aperturas', {
    headers: { Origin: 'https://evil.example' },
    data: {},
  });
  expect(r.status()).toBe(403);
  expect((await r.json()).error.code).toBe('INVALID_ORIGIN');
});
test('manifest y fallback sin conexión contienen solo recursos públicos', async ({ request }) => {
  const manifest = await request.get('/manifest.webmanifest');
  expect(manifest.ok()).toBe(true);
  expect((await manifest.json()).display).toBe('standalone');
  const worker = await request.get('/sw.js');
  expect(await worker.text()).not.toContain('cache.put');
  const fallback = await request.get('/sin-conexion.html');
  expect(fallback.ok()).toBe(true);
});
