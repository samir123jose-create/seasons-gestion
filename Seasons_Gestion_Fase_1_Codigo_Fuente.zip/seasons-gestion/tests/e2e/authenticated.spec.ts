import { test, expect, type Page } from '@playwright/test';
import ExcelJS from 'exceljs';
import { createClient } from '@supabase/supabase-js';
const origin = 'http://127.0.0.1:3000';
const password = 'Seasons-test-password-2026!';
const nonce = crypto.randomUUID().slice(0, 6);
test.skip(
  !process.env.NEXT_PUBLIC_SUPABASE_URL,
  'Requiere GoTrue/PostgREST locales preparados; no se simula Auth.',
);
async function login(page: Page, email = 'admin@seasons.test.invalid', pass = password) {
  await page.goto('/login');
  await page.getByLabel('Correo electrónico').fill(email);
  await page.getByLabel('Contraseña', { exact: true }).fill(pass);
  await page.getByRole('button', { name: 'Iniciar sesión' }).click();
  await expect(page).toHaveURL(/admin\/inicio/);
}
async function post(page: Page, url: string, data: unknown) {
  const r = await page.request.post(url, { headers: { Origin: origin }, data });
  expect(r.ok(), JSON.stringify(await r.json())).toBe(true);
  return (await r.json()).data;
}
async function get(page: Page, url: string) {
  const r = await page.request.get(url);
  expect(r.ok()).toBe(true);
  return (await r.json()).data;
}
test('autenticación real, creación/edición de categoría y persistencia tras recargar', async ({
  page,
}, info) => {
  await login(page);
  await page.goto('/admin/catalogos/categorias');
  await page.getByRole('button', { name: 'Nueva categoría' }).click();
  const code = `E2E-CAT-${info.project.name.toUpperCase()}-${nonce}`;
  await page.getByLabel('Código').fill(code);
  await page.getByLabel('Nombre', { exact: true }).fill(`Categoría ${info.project.name} ${nonce}`);
  if (info.project.name === 'mobile')
    expect(
      await page
        .locator('dialog')
        .evaluate((d) => d.getBoundingClientRect().right <= document.documentElement.clientWidth),
    ).toBe(true);
  await page.getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Registro creado');
  await page.reload();
  await expect(
    page.getByText(`Categoría ${info.project.name} ${nonce}`, { exact: true }),
  ).toBeVisible();
  await page
    .getByRole('button', { name: `Editar Categoría ${info.project.name} ${nonce}` })
    .click();
  await page.getByLabel('Nombre', { exact: true }).fill(`Editada ${info.project.name} ${nonce}`);
  await page.getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Cambios guardados');
  await page.reload();
  await expect(
    page.getByText(`Editada ${info.project.name} ${nonce}`, { exact: true }),
  ).toBeVisible();
  if (info.project.name === 'mobile') {
    await page.getByRole('button', { name: 'Abrir menú' }).click();
    await expect(page.getByRole('navigation', { name: 'Navegación principal' })).toBeVisible();
  }
  await page.screenshot({
    path: `test-results/seasons-catalogo-${info.project.name}.png`,
    fullPage: true,
  });
});
test('catálogos, presentación 900 ml y costo histórico funcionan con API/RLS reales', async ({
  page,
}, info) => {
  await login(page);
  const tag = `${info.project.name.toUpperCase()}-${nonce}`;
  const categories = await get(page, '/api/v1/catalogos/categorias');
  const units = await get(page, '/api/v1/unidades');
  const ml = units.find((x: { code: string }) => x.code === 'ml');
  const item = await post(page, '/api/v1/catalogos/insumos', {
    code: `E2E-MILK-${tag}`,
    name: `Leche ${tag}`,
    category_id: categories.rows[0].id,
    unit_id: ml.id,
    item_type: 'ingredient',
    active: true,
  });
  const supplier = await post(page, '/api/v1/catalogos/proveedores', {
    code: `E2E-SUP-${tag}`,
    name: `Proveedor ${tag}`,
    contact: 'Contacto de prueba',
    email: 'supplier@test.invalid',
    active: true,
  });
  const presentation = await post(page, '/api/v1/catalogos/presentaciones', {
    code: `E2E-PRES-${tag}`,
    name: `Envase 900 ${tag}`,
    item_id: item.id,
    unit_id: ml.id,
    quantity: '900',
    supplier_id: supplier.id,
    active: true,
  });
  expect(presentation.base_quantity).toBe('900.000000');
  await post(page, '/api/v1/precios', {
    presentation_id: presentation.id,
    amount: '9',
    effective_date: '2026-10-12',
    source: 'Cotización exclusiva de prueba',
  });
  const history = await get(page, '/api/v1/precios');
  expect(
    history.find((p: { presentation_id: string }) => p.presentation_id === presentation.id)
      .unit_cost,
  ).toBe('0.0100000000');
  await page.goto('/admin/precios');
  await expect(page.getByText(`Envase 900 ${tag}`, { exact: true })).toBeVisible();
});
test('apertura repetida conserva una sola operación y cantidades exactas', async ({
  page,
}, info) => {
  await login(page);
  const w = await post(page, '/api/v1/catalogos/almacenes', {
    code: `E2E-OPEN-${info.project.name.toUpperCase()}-${nonce}`,
    name: `Almacén de prueba ${info.project.name} ${nonce}`,
    branch_id: '',
    active: true,
  });
  const items = await get(page, '/api/v1/catalogos/insumos');
  const key = crypto.randomUUID();
  const body = {
    warehouse_id: w.id,
    lines: [{ item_id: items.rows[0].id, quantity: '1800', value: '18' }],
  };
  const a = await page.request.post('/api/v1/aperturas', {
    headers: { Origin: origin, 'Idempotency-Key': key },
    data: body,
  });
  expect(a.status()).toBe(201);
  const b = await page.request.post('/api/v1/aperturas', {
    headers: { Origin: origin, 'Idempotency-Key': key },
    data: body,
  });
  expect(b.status()).toBe(201);
  expect((await a.json()).data.operation_id).toBe((await b.json()).data.operation_id);
  const stock = await get(page, `/api/v1/existencias?warehouse_id=${w.id}`);
  expect(stock[0].quantity).toBe('1800.000000');
  expect(stock[0].value).toBe('18.000000');
});
test('Excel se previsualiza antes de confirmar, persiste y no duplica reintento', async ({
  page,
}, info) => {
  await login(page);
  await page.goto('/admin/importaciones');
  await page.getByRole('combobox', { name: 'Catálogo', exact: true }).selectOption('categorias');
  const w = new ExcelJS.Workbook();
  const sheet = w.addWorksheet('Categorías');
  sheet.addRow(['code', 'name']);
  sheet.addRow([
    `E2E-IMPORT-${info.project.name.toUpperCase()}-${nonce}`,
    `Importado ${info.project.name} ${nonce}`,
  ]);
  const bytes = Buffer.from(await w.xlsx.writeBuffer());
  await page
    .getByLabel('Archivo Excel (.xlsx)')
    .setInputFiles({
      name: 'categorias.xlsx',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      buffer: bytes,
    });
  const responsePromise = page.waitForResponse((r) =>
    r.url().endsWith('/api/v1/importaciones/preview'),
  );
  await page.getByRole('button', { name: 'Revisar archivo' }).click();
  const preview = (await (await responsePromise).json()).data;
  await expect(page.getByRole('heading', { name: 'Previsualización' })).toBeVisible();
  await expect(page.getByText('Aún no se modificó el catálogo.', { exact: false })).toBeVisible();
  await page.getByRole('button', { name: 'Confirmar importación' }).click();
  await expect(page.getByRole('status')).toContainText('Importación confirmada: 1 registro');
  const repeat = await post(page, '/api/v1/importaciones/confirmar', { job_id: preview.job_id });
  expect(repeat.count).toBe(1);
  await page.goto('/admin/catalogos/categorias');
  await page
    .getByRole('textbox', { name: 'Buscar categorías' })
    .fill(`E2E-IMPORT-${info.project.name.toUpperCase()}-${nonce}`);
  await page.getByRole('button', { name: 'Buscar', exact: true }).click();
  await expect(
    page.getByText(`Importado ${info.project.name} ${nonce}`, { exact: true }),
  ).toBeVisible();
});
test('colaborador no recibe costos, no escribe catálogos ni consulta otra ubicación', async ({
  page,
}) => {
  await login(page, 'worker@seasons.test.invalid');
  const access = await get(page, '/api/v1/acceso');
  expect(access.warehouses).toHaveLength(1);
  expect(access.warehouses[0].code).toBe('MEGA-MALL');
  const costs = await page.request.get('/api/v1/precios');
  expect(costs.status()).toBe(403);
  const mutation = await page.request.post('/api/v1/catalogos/categorias', {
    headers: { Origin: origin },
    data: { code: 'NOT-ALLOWED', name: 'No autorizado' },
  });
  expect(mutation.status()).toBe(403);
  const cross = await page.request.get(`/api/v1/existencias?warehouse_id=${crypto.randomUUID()}`);
  expect(cross.status()).toBe(403);
  await page.goto('/admin/catalogos/insumos');
  await expect(page.getByRole('button', { name: 'Nuevo insumo' })).toHaveCount(0);
  await page.goto('/admin/precios');
  await expect(page).toHaveURL(/sin-acceso/);
});
test('recuperación verifica OTP de GoTrue y permite establecer nueva contraseña', async ({
  page,
}, info) => {
  test.skip(
    info.project.name !== 'desktop',
    'Flujo de proveedor se verifica una vez, sin duplicar recuperación.',
  );
  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
  const email = `recovery-${Date.now()}@test.invalid`;
  const created = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: 'Recuperación de prueba' },
  });
  expect(created.error).toBeNull();
  const link = await admin.auth.admin.generateLink({ type: 'recovery', email });
  expect(link.error).toBeNull();
  if (!link.data.properties) throw new Error('Falta enlace de recuperación de prueba');
  const hash = link.data.properties.hashed_token;
  await page.goto(`/auth/confirm?token_hash=${encodeURIComponent(hash)}&type=recovery`);
  await expect(page).toHaveURL(/actualizar-clave/);
  await page.getByLabel('Contraseña', { exact: true }).fill('Updated-local-test-password-2026!');
  await page.getByLabel('Confirma tu contraseña').fill('Updated-local-test-password-2026!');
  await page.getByRole('button', { name: 'Guardar contraseña' }).click();
  await expect(page).toHaveURL(/login/);
  const client = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
  const r = await client.auth.signInWithPassword({
    email,
    password: 'Updated-local-test-password-2026!',
  });
  expect(r.error).toBeNull(); // La cuenta de prueba queda inactiva y aislada en el harness.
});
test('cerrar sesión revoca acceso al API y a páginas protegidas', async ({ page }, info) => {
  await login(page);
  if (info.project.name === 'mobile')
    await page.getByRole('button', { name: 'Abrir menú' }).click();
  await page.getByRole('button', { name: 'Cerrar sesión' }).click();
  await expect(page).toHaveURL(/login/);
  expect((await page.request.get('/api/v1/acceso')).status()).toBe(401);
});
test('desactivación y revocación se aplican a una sesión Auth ya iniciada', async ({
  page,
  browser,
}, info) => {
  await login(page);
  const profiles = await get(page, '/api/v1/usuarios');
  const target = profiles.find((x: { full_name: string }) => x.full_name === 'Colaborador E2E');
  const roles = await get(page, '/api/v1/roles');
  const roleId = roles.find((x: { code: string }) => x.code === 'colaborador').id;
  const context = await browser.newContext({
    viewport:
      info.project.name === 'mobile' ? { width: 393, height: 851 } : { width: 1280, height: 800 },
  });
  const workerPage = await context.newPage();
  await login(workerPage, 'worker@seasons.test.invalid');
  const access = await get(workerPage, '/api/v1/acceso');
  const assigned = access.warehouses.map((w: { id: string }) => w.id);
  const baseline = {
    id: target.id,
    lock_version: target.lock_version,
    active: true,
    roles: [roleId],
    warehouses: assigned,
    overrides: [
      { permission_code: 'catalogos.read', effect: 'allow' },
      { permission_code: 'inventario.read', effect: 'allow' },
    ],
  };
  try {
    const revoke = await page.request.patch('/api/v1/usuarios', {
      headers: { Origin: origin },
      data: { ...baseline, overrides: [{ permission_code: 'catalogos.read', effect: 'deny' }] },
    });
    expect(revoke.ok()).toBe(true);
    expect((await workerPage.request.get('/api/v1/catalogos/insumos')).status()).toBe(403);
    const disable = await page.request.patch('/api/v1/usuarios', {
      headers: { Origin: origin },
      data: { ...baseline, lock_version: target.lock_version + 1, active: false },
    });
    expect(disable.ok()).toBe(true);
    expect((await workerPage.request.get('/api/v1/acceso')).status()).toBe(403);
    await workerPage.goto('/admin/inicio');
    await expect(workerPage).toHaveURL(/sin-acceso/);
  } finally {
    const current = (await get(page, '/api/v1/usuarios')).find(
      (x: { id: string }) => x.id === target.id,
    );
    const restored = await page.request.patch('/api/v1/usuarios', {
      headers: { Origin: origin },
      data: { ...baseline, lock_version: current.lock_version },
    });
    expect(restored.ok()).toBe(true);
    await context.close();
  }
});

test('la búsqueda conserva códigos con guion bajo y nombres con puntuación', async ({page}, info) => {
  await login(page);
  const code = `E2E_FILTER_${info.project.name.toUpperCase()}_${nonce}`;
  const name = `Leche, "especial" 2.5% ${info.project.name} ${nonce}`;
  const created = await post(page, '/api/v1/catalogos/categorias', {code, name, active:true});
  for (const search of [code, name]) {
    const result = await get(page, `/api/v1/catalogos/categorias?search=${encodeURIComponent(search)}`);
    expect(result.total).toBe(1);
    expect(result.rows[0].id).toBe(created.id);
  }
  const malicious = await get(page, `/api/v1/catalogos/categorias?search=${encodeURIComponent('"),active.eq.true,code.ilike.*')}`);
  expect(malicious.total).toBe(0);
});
