import { beforeAll, beforeEach, afterAll, describe, it, expect } from 'vitest';
import { Client } from 'pg';
const admin = '10000000-0000-4000-8000-000000000001';
const worker = '10000000-0000-4000-8000-000000000002';
const item = '30000000-0000-4000-8000-000000000001';
const output = '30000000-0000-4000-8000-000000000002';
const connectionString = process.env.TEST_DATABASE_URL;
let owner: Client;
let central: string;
let mega: string;
let murillo: string;
async function userQuery(user: string, sql: string, values: unknown[] = []) {
  const c = new Client({ connectionString });
  await c.connect();
  try {
    await c.query('begin');
    await c.query('set local role authenticated');
    await c.query("select set_config('request.jwt.claim.sub',$1,true)", [user]);
    const r = await c.query(sql, values);
    await c.query('commit');
    return r;
  } catch (e) {
    await c.query('rollback');
    throw e;
  } finally {
    await c.end();
  }
}
async function internal(sql: string, values: unknown[] = []) {
  const c = new Client({ connectionString });
  await c.connect();
  try {
    await c.query('begin');
    await c.query("select set_config('request.jwt.claim.sub',$1,true)", [admin]);
    const r = await c.query(sql, values);
    await c.query('commit');
    return r;
  } catch (e) {
    await c.query('rollback');
    throw e;
  } finally {
    await c.end();
  }
}
const input = (warehouse: string, q: string, value?: string) => ({
  warehouse_id: warehouse,
  item_id: item,
  quantity: q,
  ...(value !== undefined ? { value } : {}),
});
async function apply(lines: unknown[], kind = 'consumption', key = crypto.randomUUID()) {
  return internal('select app_private.apply_inventory($1,$2,$3::jsonb) id', [
    kind,
    key,
    JSON.stringify(lines),
  ]);
}
async function open(warehouse = central, key = crypto.randomUUID(), quantity = '10', value = '25') {
  return userQuery(admin, 'select public.confirm_inventory_opening($1,$2,$3::jsonb) id', [
    warehouse,
    key,
    JSON.stringify([{ item_id: item, quantity, value }]),
  ]);
}
beforeAll(async () => {
  owner = new Client({ connectionString });
  await owner.connect();
  const rows = (await owner.query('select id,code from public.warehouses')).rows;
  central = rows.find((x) => x.code === 'CENTRAL').id;
  mega = rows.find((x) => x.code === 'MEGA-MALL').id;
  murillo = rows.find((x) => x.code === 'MURILLO').id;
});
afterAll(async () => {
  await owner?.end();
});
beforeEach(async () => {
  await owner.query(
    'truncate app_private.inventory_opening_documents,app_private.inventory_movements,app_private.inventory_operations,app_private.stock_balances,app_private.item_price_history,app_private.audit_logs,public.import_jobs cascade',
  );
  await owner.query('delete from public.user_permission_overrides where user_id=$1', [admin]);
  await owner.query('update public.profiles set active=true where id=$1', [worker]);
});
describe('Migraciones, permisos y trazabilidad PostgreSQL', () => {
  it('siembra 3 ubicaciones y 4 roles, sin inventario ficticio', async () => {
    expect((await owner.query('select count(*)::int n from public.warehouses')).rows[0].n).toBe(3);
    expect((await owner.query('select count(*)::int n from public.roles')).rows[0].n).toBe(4);
    expect(
      (await owner.query('select count(*)::int n from app_private.stock_balances')).rows[0].n,
    ).toBe(0);
  });
  it('RLS limita lectura directa a ubicación asignada', async () => {
    const r = await userQuery(worker, 'select code from public.warehouses');
    expect(r.rows.map((x) => x.code)).toEqual(['MEGA-MALL']);
    await expect(
      userQuery(worker, 'select public.inventory_balances($1)', [murillo]),
    ).rejects.toMatchObject({ code: '42501' });
  });
  it('escritura directa y RPC administrativa quedan prohibidas al colaborador', async () => {
    await expect(
      userQuery(worker, "update public.items set name='Manipulado' where id=$1", [item]),
    ).rejects.toMatchObject({ code: '42501' });
    await expect(
      userQuery(worker, "select public.manage_catalog('categorias',null,$1::jsonb,null)", [
        JSON.stringify({ code: 'ILEGAL', name: 'Prueba' }),
      ]),
    ).rejects.toMatchObject({ code: '42501' });
  });
  it('oculta costos y RPC de precios a quien solo ve existencias', async () => {
    await open(mega);
    const r = await userQuery(worker, 'select public.inventory_balances($1) data', [mega]);
    expect(r.rows[0].data[0]).toEqual({ item_id: item, quantity: '10.000000' });
    await expect(userQuery(worker, 'select public.price_history()')).rejects.toMatchObject({
      code: '42501',
    });
    await expect(
      userQuery(worker, 'select * from app_private.stock_balances'),
    ).rejects.toMatchObject({ code: '42501' });
  });
  it('denegación individual prevalece sobre rol y revocación es inmediata', async () => {
    await owner.query(
      "insert into public.user_permission_overrides values($1,'costos.read','deny')",
      [admin],
    );
    await expect(userQuery(admin, 'select public.price_history()')).rejects.toMatchObject({
      code: '42501',
    });
  });
  it('cuenta desactivada no opera con identidad anterior', async () => {
    await owner.query('update public.profiles set active=false where id=$1', [worker]);
    await expect(userQuery(worker, 'select public.current_access()')).rejects.toMatchObject({
      code: '42501',
    });
    expect((await userQuery(worker, 'select * from public.warehouses')).rows).toHaveLength(0);
  });
  it('edición concurrente detecta versión obsoleta y audita autor', async () => {
    const data = { code: 'VERSION-TEST', name: 'Inicial', active: true };
    const created = (
      await userQuery(
        admin,
        "select public.manage_catalog('categorias',null,$1::jsonb,null) data",
        [JSON.stringify(data)],
      )
    ).rows[0].data;
    await userQuery(admin, "select public.manage_catalog('categorias',$1,$2::jsonb,1)", [
      created.id,
      JSON.stringify({ ...data, name: 'Actualizado' }),
    ]);
    await expect(
      userQuery(admin, "select public.manage_catalog('categorias',$1,$2::jsonb,1)", [
        created.id,
        JSON.stringify(data),
      ]),
    ).rejects.toMatchObject({ code: '40001' });
    expect(
      (
        await owner.query('select actor_id from app_private.audit_logs where entity_id=$1', [
          created.id,
        ])
      ).rows.every((x) => x.actor_id === admin),
    ).toBe(true);
  });
  it('presentación 900 ml conserva contenido y bloquea g→ml', async () => {
    const volume = (await owner.query("select id from public.units where code='ml'")).rows[0].id;
    const grams = (await owner.query("select id from public.units where code='g'")).rows[0].id;
    const milk = (
      await userQuery(admin, "select public.manage_catalog('insumos',null,$1::jsonb,null) data", [
        JSON.stringify({
          code: 'LECHE-TEST',
          name: 'Leche de prueba',
          category_id: '20000000-0000-4000-8000-000000000001',
          unit_id: volume,
        }),
      ])
    ).rows[0].data;
    const data = {
      code: 'LECHE900-TEST',
      name: 'Envase 900',
      item_id: milk.id,
      unit_id: volume,
      quantity: '900',
    };
    const presentation = (
      await userQuery(
        admin,
        "select public.manage_catalog('presentaciones',null,$1::jsonb,null) data",
        [JSON.stringify(data)],
      )
    ).rows[0].data;
    expect(presentation.base_quantity).toBe('900.000000');
    await expect(
      userQuery(admin, "select public.manage_catalog('presentaciones',null,$1::jsonb,null)", [
        JSON.stringify({ ...data, code: 'LECHEG-TEST', unit_id: grams }),
      ]),
    ).rejects.toMatchObject({ code: '23514' });
    await expect(
      userQuery(admin, "select public.manage_catalog('presentaciones',$1,$2::jsonb,1)", [
        presentation.id,
        JSON.stringify({ ...data, quantity: '1000' }),
      ]),
    ).rejects.toMatchObject({ code: '23514' });
  });
  it('historial de precio permanece separado del stock', async () => {
    const volume = (await owner.query("select id from public.units where code='ml'")).rows[0].id;
    const milk = (
      await userQuery(admin, "select public.manage_catalog('insumos',null,$1::jsonb,null) data", [
        JSON.stringify({
          code: 'PRICE-MILK-TEST',
          name: 'Leche para cotización de prueba',
          category_id: '20000000-0000-4000-8000-000000000001',
          unit_id: volume,
        }),
      ])
    ).rows[0].data;
    const p = (
      await userQuery(
        admin,
        "select public.manage_catalog('presentaciones',null,$1::jsonb,null) data",
        [
          JSON.stringify({
            code: 'PRICE-PRES-TEST',
            name: 'Presentación de cotización',
            item_id: milk.id,
            unit_id: volume,
            quantity: '900',
          }),
        ],
      )
    ).rows[0].data.id;
    await userQuery(admin, 'select public.record_price($1,$2,$3,$4)', [
      p,
      '9',
      '2026-10-12',
      'Cotización de prueba',
    ]);
    const history = (await userQuery(admin, 'select public.price_history() data')).rows[0].data;
    expect(history[0].unit_cost).toBe('0.0100000000');
    expect(
      (await owner.query('select count(*)::int n from app_private.inventory_movements')).rows[0].n,
    ).toBe(0);
  });
  it('roles tienen bloqueo optimista y no se puede modificar rol propio', async () => {
    const role = (await owner.query("select * from public.roles where code='colaborador'")).rows[0];
    await userQuery(admin, 'select public.manage_role_permissions($1,$2,$3::text[])', [
      role.id,
      role.lock_version,
      ['recetas.read', 'solicitudes.create'],
    ]);
    await expect(
      userQuery(admin, 'select public.manage_role_permissions($1,$2,$3::text[])', [
        role.id,
        role.lock_version,
        [],
      ]),
    ).rejects.toMatchObject({ code: '40001' });
    const own = (await owner.query("select id from public.roles where code='administrador'"))
      .rows[0].id;
    await expect(
      userQuery(admin, 'select public.manage_role_permissions($1,1,$2::text[])', [own, []]),
    ).rejects.toMatchObject({ code: '23514' });
  });
  it('no hay ejecución pública/anon de funciones operativas', async () => {
    const r = await owner.query(
      "select has_function_privilege('anon','public.confirm_inventory_opening(uuid,uuid,jsonb)','EXECUTE') ok",
    );
    expect(r.rows[0].ok).toBe(false);
    await expect(
      userQuery(admin, "select app_private.apply_inventory('consumption',$1,$2::jsonb)", [
        crypto.randomUUID(),
        JSON.stringify([input(central, '-1')]),
      ]),
    ).rejects.toMatchObject({ code: '42501' });
  });
});
describe('Atomicidad, precisión, idempotencia y concurrencia', () => {
  it('doble clic/reintento de apertura genera una sola operación', async () => {
    const key = crypto.randomUUID();
    const results = await Promise.all([open(central, key), open(central, key)]);
    expect(results[0].rows[0].id).toBe(results[1].rows[0].id);
    expect(
      (await owner.query('select count(*)::int n from app_private.inventory_movements')).rows[0].n,
    ).toBe(1);
    await expect(open(central, key, '11')).rejects.toMatchObject({ code: '40001' });
  });
  it('una segunda apertura distinta se rechaza', async () => {
    await open();
    await expect(open()).rejects.toMatchObject({ code: '23514' });
  });
  it('dos salidas de 7 sobre stock 10: una confirma y saldo queda 3', async () => {
    await open();
    const results = await Promise.allSettled([
      apply([input(central, '-7')]),
      apply([input(central, '-7')]),
    ]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(
      (
        await owner.query(
          'select quantity::text,value::text from app_private.stock_balances where item_id=$1',
          [item],
        )
      ).rows[0],
    ).toEqual({ quantity: '3.000000', value: '7.500000' });
  });
  it('promedio ponderado conserva costo de salidas históricas', async () => {
    await open();
    await apply([input(central, '-2')]);
    await apply([input(central, '2', '10')], 'receipt');
    const balance = (
      await owner.query(
        'select quantity::text,value::text,average_cost::text from app_private.stock_balances',
      )
    ).rows[0];
    expect(balance).toEqual({
      quantity: '10.000000',
      value: '30.000000',
      average_cost: '3.0000000000',
    });
    expect(
      (
        await owner.query(
          'select unit_cost::text from app_private.inventory_movements where quantity<0',
        )
      ).rows[0].unit_cost,
    ).toBe('2.5000000000');
  });
  it('fallo tras consumo revierte todo el lote y su idempotencia', async () => {
    await open();
    await owner.query(
      `create function app_private.test_fail_output() returns trigger language plpgsql as $$ begin if new.item_id='${output}' then raise exception 'Fallo inducido de prueba'; end if; return new; end $$; create trigger test_fail_output before insert on app_private.inventory_movements for each row execute function app_private.test_fail_output();`,
    );
    try {
      await expect(
        apply(
          [
            input(central, '-4'),
            { warehouse_id: central, item_id: output, quantity: '100', value: '10' },
          ],
          'production',
        ),
      ).rejects.toThrow('Fallo inducido');
      expect(
        (
          await owner.query(
            'select quantity::text from app_private.stock_balances where item_id=$1',
            [item],
          )
        ).rows[0].quantity,
      ).toBe('10.000000');
      expect(
        (await owner.query('select count(*)::int n from app_private.inventory_operations')).rows[0]
          .n,
      ).toBe(1);
    } finally {
      await owner.query(
        'drop trigger test_fail_output on app_private.inventory_movements;drop function app_private.test_fail_output();',
      );
    }
  });
  it('rechaza negativos, cero, precisión excedida, unidades fraccionarias y valores desconocidos', async () => {
    await expect(open(central, crypto.randomUUID(), '-1')).rejects.toMatchObject({ code: '23514' });
    await expect(apply([input(central, '0')])).rejects.toMatchObject({ code: '23514' });
    await expect(apply([input(central, '0.0000001', '1')], 'receipt')).rejects.toMatchObject({
      code: '22023',
    });
    await expect(apply([input(central, '1.5', '1')], 'receipt')).rejects.toMatchObject({
      code: '23514',
    });
    await expect(apply([input(central, '1')], 'receipt')).rejects.toMatchObject({ code: '22023' });
  });
  it('redondeo half-away y última salida absorben residuo', async () => {
    expect(
      (
        await owner.query(
          'select round(1.234565::numeric,5)::text p,round(-1.234565::numeric,5)::text n',
        )
      ).rows[0],
    ).toEqual({ p: '1.23457', n: '-1.23457' });
    await open(central, crypto.randomUUID(), '3', '1');
    await apply([input(central, '-1')]);
    await apply([input(central, '-2')]);
    expect(
      (
        await owner.query(
          'select quantity::text,value::text,average_cost::text from app_private.stock_balances',
        )
      ).rows[0],
    ).toEqual({ quantity: '0.000000', value: '0.000000', average_cost: '0.0000000000' });
  });
  it('saldos son reconstruibles desde movimientos', async () => {
    await open();
    await apply([input(central, '-3')]);
    const r = await owner.query(
      'select b.quantity=sum(m.quantity) and b.value=sum(m.value) ok from app_private.stock_balances b join app_private.inventory_movements m using(warehouse_id,item_id) group by b.quantity,b.value',
    );
    expect(r.rows[0].ok).toBe(true);
  });
});
describe('Importaciones transaccionales', () => {
  it('confirmación repetida no duplica registros', async () => {
    const rows = [
      { code: 'IMPORT-ONE', name: 'Importado uno' },
      { code: 'IMPORT-TWO', name: 'Importado dos' },
    ];
    const id = (
      await userQuery(admin, "select public.preview_import('categorias',$1::jsonb) id", [
        JSON.stringify(rows),
      ])
    ).rows[0].id;
    const first = await userQuery(admin, 'select public.confirm_import($1) data', [id]);
    const second = await userQuery(admin, 'select public.confirm_import($1) data', [id]);
    expect(first.rows[0].data).toEqual(second.rows[0].data);
    expect(
      (
        await owner.query(
          "select count(*)::int n from public.item_categories where code like 'IMPORT-%'",
        )
      ).rows[0].n,
    ).toBe(2);
  });
  it('conflicto al confirmar revierte todas las filas nuevas', async () => {
    const rows = [
      { code: 'ROLLBACK-NEW', name: 'Debe revertirse' },
      { code: 'PRUEBA', name: 'Código ya existente' },
    ];
    const id = (
      await userQuery(admin, "select public.preview_import('categorias',$1::jsonb) id", [
        JSON.stringify(rows),
      ])
    ).rows[0].id;
    await expect(userQuery(admin, 'select public.confirm_import($1)', [id])).rejects.toMatchObject({
      code: '23505',
    });
    expect(
      (
        await owner.query(
          "select count(*)::int n from public.item_categories where code='ROLLBACK-NEW'",
        )
      ).rows[0].n,
    ).toBe(0);
    expect(
      (await owner.query('select status from public.import_jobs where id=$1', [id])).rows[0].status,
    ).toBe('preview');
  });
  it('revocar permiso tras previsualización impide confirmación', async () => {
    const id = (
      await userQuery(admin, "select public.preview_import('categorias',$1::jsonb) id", [
        JSON.stringify([{ code: 'REVOKED', name: 'Sin permiso' }]),
      ])
    ).rows[0].id;
    await owner.query(
      "insert into public.user_permission_overrides values($1,'insumos.manage','deny')",
      [admin],
    );
    await expect(userQuery(admin, 'select public.confirm_import($1)', [id])).rejects.toMatchObject({
      code: '42501',
    });
  });
});
