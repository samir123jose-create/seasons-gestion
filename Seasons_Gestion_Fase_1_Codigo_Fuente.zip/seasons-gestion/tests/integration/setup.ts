import { Client } from 'pg';
import fs from 'node:fs/promises';
export default async function setup() {
  const raw = process.env.TEST_DATABASE_URL;
  if (!raw)
    throw new Error('TEST_DATABASE_URL requerida; usar PostgreSQL local aislado seasons_test.');
  const url = new URL(raw);
  if (!['127.0.0.1', 'localhost'].includes(url.hostname) || !url.pathname.endsWith('/seasons_test'))
    throw new Error('Integración solo admite BD local seasons_test; nunca producción.');
  const db = new Client({ connectionString: raw });
  await db.connect();
  await db.query(`drop schema if exists public cascade; drop schema if exists app_private cascade; drop schema if exists auth cascade; drop schema if exists storage cascade; create schema public; create schema auth; create schema storage;
 do $$ begin if not exists(select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if; if not exists(select 1 from pg_roles where rolname='anon') then create role anon nologin; end if; if not exists(select 1 from pg_roles where rolname='service_role') then create role service_role nologin bypassrls; end if; end $$;
 grant usage on schema public,auth to authenticated,anon,service_role;
 create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb not null default '{}');
 create function auth.uid() returns uuid language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb->>'sub')::uuid $$;
 grant execute on function auth.uid() to authenticated,anon,service_role;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 `);
  for (const file of (await fs.readdir('supabase/migrations'))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    await db.query(await fs.readFile(`supabase/migrations/${file}`, 'utf8'));
  // Adaptador de identidad SQL de prueba: no es Supabase Auth ni valida JWT.
  await db.query(`insert into auth.users(id,email,raw_user_meta_data) values
 ('10000000-0000-4000-8000-000000000001','admin@test.invalid','{"full_name":"Administrador de prueba"}'),
 ('10000000-0000-4000-8000-000000000002','worker@test.invalid','{"full_name":"Colaborador de prueba"}');
 select set_config('request.jwt.claim.role','service_role',false);
 select public.bootstrap_admin('10000000-0000-4000-8000-000000000001');
 update public.profiles set active=true where id='10000000-0000-4000-8000-000000000002';
 insert into public.user_roles select '10000000-0000-4000-8000-000000000002',id from public.roles where code='colaborador';
 insert into public.user_warehouse_access select '10000000-0000-4000-8000-000000000002',id from public.warehouses where code='MEGA-MALL';
 insert into public.user_permission_overrides values ('10000000-0000-4000-8000-000000000002','inventario.read','allow');
 insert into public.item_categories(id,code,name) values('20000000-0000-4000-8000-000000000001','PRUEBA','Categoría de prueba');
 insert into public.items(id,code,name,category_id,unit_id,item_type) select '30000000-0000-4000-8000-000000000001','PRUEBA-INPUT','Entrada de prueba','20000000-0000-4000-8000-000000000001',id,'material' from public.units where code='unidad';
 insert into public.items(id,code,name,category_id,unit_id,item_type) select '30000000-0000-4000-8000-000000000002','PRUEBA-OUTPUT','Salida de prueba','20000000-0000-4000-8000-000000000001',id,'ingredient' from public.units where code='g';
 `);
  await db.end();
}
