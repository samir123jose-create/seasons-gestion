import { describe, it, expect } from 'vitest';
import { formatMoney } from '../../src/lib/format';
describe('Presentación monetaria sin pérdida decimal', () => {
  it('muestra exactamente dos decimales', () => expect(formatMoney('9', 'en-US')).toBe('9.00'));
  it('aplica empate alejándose de cero', () => {
    expect(formatMoney('0.005', 'en-US')).toBe('0.01');
    expect(formatMoney('-0.005', 'en-US')).toBe('-0.01');
  });
  it('conserva importes superiores a la precisión segura de Number', () =>
    expect(formatMoney('999999999999999999.995001', 'en-US')).toBe('1,000,000,000,000,000,000.00'));
  it('no muestra cero negativo después de redondear', () =>
    expect(formatMoney('-0.000001', 'en-US')).toBe('0.00'));
});
