import { describe, it, expect } from 'vitest';
import { checkOrigin, readJson, endpoint } from '../../src/lib/http';
import { AppError } from '../../src/lib/errors';
describe('Protección y contrato HTTP', () => {
  it('rechaza peticiones de otro origen o sin origen en mutaciones', () => {
    expect(() =>
      checkOrigin(
        new Request('http://localhost:3000/api', { headers: { origin: 'https://evil.example' } }),
      ),
    ).toThrow();
    expect(() => checkOrigin(new Request('http://localhost:3000/api'))).toThrow();
  });
  it('admite el origen configurado', () =>
    expect(() =>
      checkOrigin(
        new Request('http://localhost:3000/api', { headers: { origin: 'http://localhost:3000' } }),
      ),
    ).not.toThrow());
  it('limita realmente el cuerpo y rechaza JSON malformado', async () => {
    await expect(
      readJson(
        new Request('http://localhost', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: 'x'.repeat(100),
        }),
        20,
      ),
    ).rejects.toMatchObject({ status: 413 });
    await expect(
      readJson(
        new Request('http://localhost', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: '{',
        }),
      ),
    ).rejects.toMatchObject({ status: 422 });
  });
  it('devuelve error uniforme con correlación y sin caché', async () => {
    const r = await endpoint(async () => {
      throw new AppError(403, 'FORBIDDEN', 'Sin permiso');
    });
    expect(r.status).toBe(403);
    expect(r.headers.get('Cache-Control')).toContain('no-store');
    expect((await r.json()).error.request_id).toBe(r.headers.get('X-Request-Id'));
  });
});
