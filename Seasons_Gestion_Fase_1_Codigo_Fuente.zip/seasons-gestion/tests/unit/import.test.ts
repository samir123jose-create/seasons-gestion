import { describe, it, expect } from 'vitest';
import ExcelJS from 'exceljs';
import { parseWorkbook, validateArchive } from '../../src/modules/importaciones/workbook';
async function workbook(rows: unknown[][]) {
  const w = new ExcelJS.Workbook();
  const sheet = w.addWorksheet('Datos');
  rows.forEach((r) => sheet.addRow(r));
  return Buffer.from(await w.xlsx.writeBuffer());
}
describe('Importación segura con previsualización', () => {
  it('acepta datos y separa errores sin confirmar filas', async () => {
    const r = await parseWorkbook(
      await workbook([
        ['code', 'name'],
        ['CAFE', 'Café'],
        ['CAFE', 'Repetido'],
        ['EXISTE', 'Existente'],
      ]),
      'categorias',
      new Set(['EXISTE']),
    );
    expect(r.rows).toHaveLength(1);
    expect(r.errors.map((x) => x.row)).toEqual([3, 4]);
  });
  it('detecta columnas ausentes', async () =>
    await expect(
      parseWorkbook(await workbook([['name'], ['Café']]), 'categorias', new Set()),
    ).rejects.toThrow('columnas'));
  it('rechaza fórmulas en lugar de ejecutarlas o confiar en el resultado', async () => {
    const r = await parseWorkbook(
      await workbook([
        ['code', 'name'],
        ['CAFE', { formula: '1+1', result: 'Café' }],
      ]),
      'categorias',
      new Set(),
    );
    expect(r.errors[0].message).toContain('fórmulas');
  });
  it('rechaza archivo disfrazado, vacío y exceso de tamaño', () => {
    expect(() => validateArchive(Buffer.from('not excel'))).toThrow();
    expect(() => validateArchive(Buffer.alloc(6 * 1024 * 1024))).toThrow('5 MB');
  });
  it('rechaza contenido expandido que miente en el encabezado', async () => {
    const data = await workbook([
      ['code', 'name'],
      ['CAFE', 'Café'],
    ]);
    const at = data.indexOf(Buffer.from([0x50, 0x4b, 0x01, 0x02]));
    data.writeUInt32LE(1, at + 24);
    expect(() => validateArchive(data)).toThrow('comprimido');
  });
});
it('resuelve códigos de categoría y unidad a referencias sin pedir UUID al operador', async () => {
  const category = crypto.randomUUID(),
    unit = crypto.randomUUID();
  const r = await parseWorkbook(
    await workbook([
      ['code', 'name', 'category_code', 'unit_code', 'item_type'],
      ['LECHE', 'Leche', 'LACTEOS', 'ml', 'ingredient'],
    ]),
    'insumos',
    new Set(),
    { categories: new Map([['LACTEOS', category]]), units: new Map([['ml', unit]]) },
  );
  expect(r.errors).toHaveLength(0);
  expect(r.rows[0]).toMatchObject({ category_id: category, unit_id: unit });
});
