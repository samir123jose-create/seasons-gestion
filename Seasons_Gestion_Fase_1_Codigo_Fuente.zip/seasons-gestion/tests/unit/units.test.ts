import { describe, it, expect } from 'vitest';
import { convertToBase, presentationQuantity } from '../../src/modules/insumos/domain/units';
import { catalogConfig, openingSchema } from '../../src/modules/catalogos/config';
const ml = { dimension: 'volume' as const, factor: '1' };
const g = { dimension: 'mass' as const, factor: '1' };
describe('Conversiones y cantidades reales', () => {
  it('dos envases de 900 ml son exactamente 1.800 ml', () =>
    expect(presentationQuantity('2', '900')).toBe('1800'));
  it('convierte kg y litros conservando fracciones', () => {
    expect(convertToBase('1.25', { dimension: 'mass', factor: '1000' }, g)).toBe('1250');
    expect(convertToBase('0.9', { dimension: 'volume', factor: '1000' }, ml)).toBe('900');
  });
  it('no asume equivalencia masa/volumen', () =>
    expect(() => convertToBase('100', g, ml)).toThrow('incompatibles'));
  it.each(['0', '-1', 'NaN', '1e3', '0.0000001'])('rechaza cantidad inválida %s', (q) =>
    expect(() => convertToBase(q, ml, ml)).toThrow(),
  );
  it('rechaza unidades fraccionarias', () =>
    expect(() =>
      convertToBase(
        '1.5',
        { dimension: 'count', factor: '1' },
        { dimension: 'count', factor: '1' },
      ),
    ).toThrow('enteros'));
  it('no utiliza flotantes para productos decimales', () =>
    expect(presentationQuantity('0.1', '0.2')).toBe('0.02'));
  it('la API rechaza cantidades cero o negativas en apertura', () => {
    const line = { item_id: crypto.randomUUID(), quantity: '0', value: '10' };
    expect(
      openingSchema.safeParse({ warehouse_id: crypto.randomUUID(), lines: [line] }).success,
    ).toBe(false);
  });
  it('normaliza códigos e impide referencias incompletas', () => {
    expect(
      (
        catalogConfig.categorias.schema.parse({ code: ' leche ', name: 'Lácteos' }) as {
          code: string;
        }
      ).code,
    ).toBe('LECHE');
    expect(catalogConfig.insumos.schema.safeParse({ code: 'LECHE', name: 'Leche' }).success).toBe(
      false,
    );
  });
});
